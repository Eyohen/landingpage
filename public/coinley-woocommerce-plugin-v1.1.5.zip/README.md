# Coinley WooCommerce Payment Gateway

![Version](https://img.shields.io/badge/version-1.0.0-7042D2.svg?style=flat-square)
![WordPress](https://img.shields.io/badge/WordPress-5.4+-0073aa.svg?style=flat-square)
![WooCommerce](https://img.shields.io/badge/WooCommerce-4.0+-a46497.svg?style=flat-square)
![PHP](https://img.shields.io/badge/PHP-7.2+-8892BF.svg?style=flat-square)
![License](https://img.shields.io/badge/license-GPL--2.0%2B-green.svg?style=flat-square)

Accept cryptocurrency payments on your WooCommerce store with Coinley's blockchain-powered payment gateway. Lower fees, instant settlements, and no chargebacks.

## Description

Coinley is a modern payment solution built on blockchain technology, designed to eliminate intermediaries, reduce transaction fees, and enable instant settlements for e-commerce businesses.

### Key Features

- **Low Transaction Fees**: Save up to 80% compared to traditional payment processors
- **Instant Settlements**: No more waiting days for funds to clear
- **No Chargebacks**: Eliminate fraud risk with irreversible transactions
- **Global Accessibility**: Accept payments from customers worldwide
- **Multiple Cryptocurrencies**: Support for Bitcoin, Ethereum, and other major cryptocurrencies
- **Fiat Conversion**: Automatic conversion to your local currency
- **Mobile Friendly**: Responsive design works on all devices
- **Customizable**: Easy to configure and customize to match your store

## Installation

### Automatic Installation

1. Go to WordPress Dashboard > Plugins > Add New
2. Search for "Coinley WooCommerce Payment Gateway"
3. Click "Install Now" and then "Activate"

### Manual Installation

1. Download the plugin ZIP file
2. Go to WordPress Dashboard > Plugins > Add New > Upload Plugin
3. Upload the ZIP file and click "Install Now"
4. Activate the plugin

## Configuration

After installation:

1. Go to WooCommerce > Settings > Payments
2. Find "Cryptocurrency Payment (Coinley)" and click "Manage"
3. Configure your API credentials and settings
4. Save changes

See the [Installation Guide](docs/installation-guide.md) for detailed instructions.

## Screenshots

![Checkout Page](assets/images/screenshot-1.png)
![Settings Page](assets/images/screenshot-2.png)

## Frequently Asked Questions

**Do I need a Coinley account?**  
Yes, you need to create an account at [Coinley.io](https://coinley.io) to get your API credentials.

**Which cryptocurrencies are supported?**  
Coinley supports Bitcoin, Ethereum, and other major cryptocurrencies. The full list is available in your Coinley dashboard.

**Can I receive payments in my local currency?**  
Yes, Coinley can automatically convert cryptocurrency payments to your preferred fiat currency.

## Support

For support, please visit [Coinley Support](https://coinley.io/support) or email us at support@coinley.io.

## License

This plugin is licensed under the GNU General Public License v2.0 or later.

## Connect with Coinley

- [Website](https://coinley.io)
- [Twitter](https://twitter.com/coinleyio)
- [LinkedIn](https://linkedin.com/company/coinley)
- [GitHub](https://github.com/coinley) 