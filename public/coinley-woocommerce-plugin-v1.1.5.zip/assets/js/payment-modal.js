/**
 * Coinley Payment Modal JavaScript - Refactored to use CoinleyVanilla SDK
 *
 * Handles the payment modal functionality using the loaded CoinleyVanilla script.
 */
(function($) {
    'use strict';

    let orderData = {};
    let coinleyPayment = null;

    // Merchant wallet configuration - dynamically loaded from backend
    // This will be populated from coinleyParams.merchantWallets after script loads
    let merchantWallets = {};

    // Main CoinleyPaymentModal Class - Refactored for CoinleyVanilla SDK
    class CoinleyPaymentModal {
        constructor() {
            this.modal = $('#coinley-payment-modal');
            this.modalOverlay = $('.coinley-modal-overlay');
            this.closeBtn = $('.coinley-modal-close');
            this.cancelBtns = $('.coinley-btn-cancel');
            this.loadingOverlay = $('.coinley-loading-overlay');
            
            this.init();
        }

        init() {
            // Load merchant wallets from PHP-localized data
            this.loadMerchantWallets();
            this.bindEvents();
            this.initCoinleyPaymentGateway();
        }

        // Load merchant wallet addresses from backend configuration
        loadMerchantWallets() {
            if (typeof coinleyParams !== 'undefined' && coinleyParams.merchantWallets) {
                merchantWallets = coinleyParams.merchantWallets;

                // Log which networks are configured
                const networks = Object.keys(merchantWallets);
                if (networks.length > 0) {
                } else {
                }
            } else {
                merchantWallets = {};
            }
        }

        // Initialize Coinley Payment Gateway using CoinleyVanilla SDK
        initCoinleyPaymentGateway() {
            // Wait for CoinleyVanilla SDK to load if not immediately available
            const initWithRetry = (attempts = 0, maxAttempts = 10) => {
                if (typeof CoinleyVanilla !== "undefined") {
                    try {
                        const sdkConfig = {
                            apiKey: coinleyParams.apiKey,
                            apiSecret: coinleyParams.apiSecret,
                            apiUrl: coinleyParams.apiUrl,
                            theme: "light",
                            debug: coinleyParams.debug || false,
                        };
                        
                        
                        coinleyPayment = new CoinleyVanilla(sdkConfig);
                        
                        // Make coinleyPayment globally accessible for Blocks integration
                        window.coinleyPayment = coinleyPayment;
                        
                        return true;
                    } catch (error) {
                        this.showNotice('Payment system initialization failed.', 'error');
                        return false;
                    }
                } else if (attempts < maxAttempts) {
                    setTimeout(() => initWithRetry(attempts + 1, maxAttempts), 500);
                    return false;
                } else {
                    this.showNotice('Payment system not available. Please refresh the page.', 'error');
                    return false;
                }
            };
            
            initWithRetry();
        }

        bindEvents() {
            const self = this;

            // Close modal events
            this.closeBtn.on('click', function() {
                if (!$(this).prop('disabled')) {
                    self.closeModal();
                }
            });

            this.modalOverlay.on('click', function() {
                self.closeModal();
            });

            this.cancelBtns.on('click', function() {
                if (!$(this).prop('disabled')) {
                    self.closeModal();
                }
            });

            // Listen for form submission on checkout - with higher priority
            $(document.body).on('click', '#place_order', function(e) {
                const paymentMethod = $('input[name="payment_method"]:checked').val();
                
                if (paymentMethod === 'coinleywp') {
                    e.preventDefault();
                    e.stopImmediatePropagation(); // Prevent other handlers from running
                    
                    
                    // Close any existing old modals
                    $('.coinley-modal').hide();
                    
                    self.populateOrderData();
                    self.processCheckout();
                    return false;
                }
            });
        }

        // Open the payment modal
        openModal() {
            this.modal.show();
            $('body').addClass('coinley-modal-open');
        }

        // Close the payment modal
        closeModal() {
            this.modal.hide();
            $('body').removeClass('coinley-modal-open');
        }

        // Show loading overlay
        showLoading() {
            this.loadingOverlay.show();
        }

        // Hide loading overlay
        hideLoading() {
            this.loadingOverlay.hide();
        }

        // Populate order data from the form
        populateOrderData() {
            const billingFirstName = $('#billing_first_name').val();
            const billingLastName = $('#billing_last_name').val();
            const billingEmail = $('#billing_email').val();
            
            // Use converted USD amount if available, otherwise use original
            const amount = coinleyParams.total ? parseFloat(coinleyParams.total) : 100.00;
            const currency = coinleyParams.currency || 'USD';
            
            orderData = {
                customerName: billingFirstName + ' ' + billingLastName,
                customerEmail: billingEmail,
                amount: amount,
                currency: currency,
                orderId: coinleyParams.orderId || 'temp-' + Date.now()
            };

        }

        // COINLEY VANILLA SDK PAYMENT PROCESSING
        async processCheckout() {
            try {
                if (!coinleyPayment) {
                    throw new Error(
                        "CoinleyVanilla payment gateway not initialized. Please refresh the page and try again."
                    );
                }

                // Show processing state
                this.showLoading();


                // Prepare payment configuration
                const paymentConfig = {
                    amount: orderData.amount,
                    customerEmail: orderData.customerEmail,
                    merchantName: coinleyParams.merchantName || "WooCommerce Store",
                    callbackUrl: coinleyParams.callbackUrl || `${window.location.origin}/wp-json/coinleywp/v1/webhook`,
                    merchantWalletAddresses: merchantWallets,
                    preferredNetwork: 'ethereum', // Set default network to Ethereum
                    preferredCurrency: 'USDT', // Set default currency to USDT
                    metadata: {
                        orderId: orderData.orderId,
                        customerName: orderData.customerName,
                        customerEmail: orderData.customerEmail,
                        source: "woocommerce-plugin",
                    },
                };

                const callbacks = {
                    onSuccess: (paymentId, transactionHash, paymentDetails) => {
                            paymentId,
                            transactionHash,
                            paymentDetails,
                        });

                        // SDK returns nested structure - extract actual values
                        let actualPaymentId = paymentId;
                        let actualTransactionHash = transactionHash;
                        let actualPaymentDetails = paymentDetails;

                        // Handle nested structure: SDK returns { paymentId, transactionHash, paymentDetails }
                        if (paymentId && typeof paymentId === 'object') {
                            // The entire response is in the first parameter
                            actualPaymentId = paymentId.paymentId || paymentId.id;
                            actualTransactionHash = paymentId.transactionHash; // ← FIX: Get from top level!
                            actualPaymentDetails = paymentId.paymentDetails || paymentId;
                        }

                            actualPaymentId,
                            actualTransactionHash,
                            actualPaymentDetails,
                        });

                        this.handlePaymentSuccess(
                            orderData.orderId,
                            actualPaymentId,
                            actualTransactionHash,
                            actualPaymentDetails
                        );
                    },
                    onError: (error) => {
                        this.handlePaymentError(error);
                    },
                    onClose: () => {
                        this.hideLoading();
                        this.closeModal();
                    },
                };

                // Open the CoinleyVanilla payment modal
                coinleyPayment.open(paymentConfig, callbacks);

            } catch (error) {
                this.hideLoading();
                this.showNotice(
                    error.message ||
                    "There was a problem processing your order. Please try again.",
                    'error'
                );
            }
        }

        // Handle successful payment
        async handlePaymentSuccess(orderId, paymentId, transactionHash, paymentDetails) {
            try {

                // Update WooCommerce order with payment details
                this.updateWooCommerceOrder(orderId, paymentId, transactionHash, paymentDetails);

                // Show success message
                this.showNotice('Payment completed successfully! Redirecting...', 'success');

                // Close the modal first
                this.closeModal();

                // For regular checkout, redirect to thank you page
                // For blocks checkout, trigger form submission
                if (window.location.pathname.includes('/checkout/')) {
                    // Regular checkout - redirect to order received page
                    setTimeout(() => {
                        this.returnToStore();
                    }, 1000);
                } else {
                    // This is handled by the Blocks callback system
                }

            } catch (error) {
                this.showNotice(
                    "Payment was received, but we had trouble updating your order. Please contact support with your transaction ID: " +
                    transactionHash,
                    'warning'
                );
                
                // Still try to redirect even if there was an error
                setTimeout(() => {
                    this.returnToStore();
                }, 2000);
            }
        }

        // Handle payment error
        handlePaymentError(error) {
            this.hideLoading();
            this.showNotice(`Payment failed: ${error}`, 'error');
        }

        // Update WooCommerce order with payment information
        updateWooCommerceOrder(orderId, paymentId, transactionHash, paymentDetails) {
            const data = {
                action: 'coinleywp_update_order',
                order_id: orderId || orderData.orderId,
                payment_id: paymentId,
                transaction_hash: transactionHash,
                currency: paymentDetails?.currency || 'Unknown',
                network: paymentDetails?.network,
                amount: paymentDetails?.amount || orderData.amount,
                nonce: coinleyParams.nonce
            };
            
            
            $.post(coinleyParams.ajaxUrl, data)
                .done((response) => {
                })
                .fail((error) => {
                });
        }

        // Return to the order details page
        returnToStore() {
            const returnUrl = (coinleyParams && coinleyParams.orderReceivedUrl) 
                ? coinleyParams.orderReceivedUrl 
                : window.location.origin + '/checkout/order-received/';
            window.location.href = returnUrl;
        }


        // Show notice - simplified for CoinleyVanilla integration
        showNotice(message, type = 'info') {
            
            // Try WooCommerce notices first
            if (typeof wc_add_to_cart_params !== 'undefined' && $('.woocommerce-notices-wrapper').length) {
                $(document.body).trigger('wc_fragment_refresh');
                
                const noticeClass = type === 'error' ? 'woocommerce-error' : 
                                   type === 'warning' ? 'woocommerce-info' : 
                                   type === 'success' ? 'woocommerce-message' : 'woocommerce-info';
                
                $(`.${noticeClass}`).remove();
                $('.woocommerce-notices-wrapper').append(`<div class="${noticeClass}">${message}</div>`);
            } else {
                // Fallback to simple alert for critical messages
                if (type === 'error') {
                    alert(`Error: ${message}`);
                } else {
                }
            }
        }
    }

    // Set global flag immediately to prevent wallet connect initialization
    window.coinleyVanillaActive = true;

    // Global helper function for WooCommerce Blocks integration
    window.processCoinleyCheckout = function(amount, customerEmail, resolve, emitResponse) {
        
        const coinleyPaymentInstance = window.coinleyPayment || coinleyPayment;
        
        if (!coinleyPaymentInstance) {
            resolve({
                type: emitResponse.responseTypes.ERROR,
                message: 'Payment system not ready. Please try again.'
            });
            return;
        }

        const paymentConfig = {
            amount: amount,
            customerEmail: customerEmail,
            merchantName: coinleyParams.merchantName || "WooCommerce Store",
            callbackUrl: coinleyParams.callbackUrl || `${window.location.origin}/wp-json/coinleywp/v1/webhook`,
            merchantWalletAddresses: merchantWallets,
            preferredNetwork: 'ethereum', // Set default network to Ethereum
            preferredCurrency: 'USDT', // Set default currency to USDT
            metadata: {
                orderId: 'blocks_' + Date.now(),
                customerEmail: customerEmail,
                source: "woocommerce-blocks",
            },
        };

        const callbacks = {
            onSuccess: (paymentId, transactionHash, paymentDetails) => {

                // SDK returns nested structure - extract actual values
                let actualPaymentId = paymentId;
                let actualTransactionHash = transactionHash;
                let actualPaymentDetails = paymentDetails;

                // Handle nested structure: SDK returns { paymentId, transactionHash, paymentDetails }
                if (paymentId && typeof paymentId === 'object') {
                    // The entire response is in the first parameter
                    actualPaymentId = paymentId.paymentId || paymentId.id;
                    actualTransactionHash = paymentId.transactionHash; // ← FIX: Get from top level!
                    actualPaymentDetails = paymentId.paymentDetails || paymentId;
                }

                    actualPaymentId,
                    actualTransactionHash,
                    actualPaymentDetails
                });

                // Store payment data for order creation
                window.coinleyPaymentData = {
                    paymentId: actualPaymentId,
                    transactionHash: actualTransactionHash,
                    paymentDetails: actualPaymentDetails
                };

                const paymentMethodData = {
                    coinleywp_transaction_hash: String(actualTransactionHash || ''),
                    coinleywp_payment_id: String(actualPaymentId || ''),
                    coinleywp_completed: 'true'
                };


                resolve({
                    type: emitResponse.responseTypes.SUCCESS,
                    meta: {
                        paymentMethodData: paymentMethodData
                    }
                });
            },
            onError: (error) => {
                resolve({
                    type: emitResponse.responseTypes.ERROR,
                    message: `Payment failed: ${error}`
                });
            },
            onClose: () => {
                resolve({
                    type: emitResponse.responseTypes.ERROR,
                    message: 'Payment cancelled'
                });
            },
        };

        // Open the CoinleyVanilla payment modal
        coinleyPaymentInstance.open(paymentConfig, callbacks);
    };

    // Initialize the payment modal on document ready
    $(document).ready(function() {
        new CoinleyPaymentModal();
    });

})(jQuery); 