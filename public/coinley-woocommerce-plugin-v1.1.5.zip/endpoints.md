# Coinley API Endpoints Documentation

This document lists all the API endpoints used by the Coinley checkout SDK to interact with the main Coinley server. Use this for building consistent integrations and plugins.

## Base Configuration

**Base URL:** `https://hub.coinley.io`

### Authentication Headers
All authenticated endpoints require these headers:
```javascript
{
  'Content-Type': 'application/json',
  'x-api-key': 'your_api_key',
  'x-api-secret': 'your_api_secret',
  'Authorization': 'Bearer base64(api_key:api_secret)' // Optional, for some endpoints
}
```

---

## 🏪 Merchant Endpoints

### 1. Get Merchant Dashboard Data
**Purpose:** Fetch merchant profile, wallet addresses, and fee configuration

```http
GET /api/merchants/dashboard
```

**Headers:**
- `Content-Type: application/json`
- `Authorization: Bearer {base64_encoded_credentials}`
- `x-api-key: {api_key}`
- `x-api-secret: {api_secret}`

**Response Example:**
```json
{
  "merchant": {
    "id": "merchant_id",
    "name": "Merchant Name",
    "walletAddress": "0x1234...",
    "solWalletAddress": "Sol1234...",
    "merchantWallets": {
      "ethereum": "0x1234...",
      "bsc": "0x5678...",
      "tron": "TRx1234...",
      "algorand": "ALGO1234..."
    },
    "customFeePercentage": 0.0175,
    "status": "active"
  }
}
```

**Used For:**
- Getting merchant wallet addresses for payments
- Fetching custom fee percentage
- Initial SDK authentication and setup

---

### 2. Get Merchant Networks and Tokens
**Purpose:** Fetch merchant's configured supported networks and tokens

```http
GET /api/merchants/networks-and-tokens
```

**Headers:** Standard authentication headers

**Response Example:**
```json
{
  "networks": [
    {
      "name": "ethereum",
      "displayName": "Ethereum",
      "enabled": true,
      "tokens": ["USDT", "USDC", "ETH"]
    },
    {
      "name": "bsc",
      "displayName": "Binance Smart Chain",
      "enabled": true,
      "tokens": ["USDT", "USDC", "BNB"]
    }
  ],
  "supportedTokens": {
    "USDT": {
      "ethereum": { "address": "0xdAC17...", "decimals": 6 },
      "bsc": { "address": "0x55d398...", "decimals": 18 }
    }
  }
}
```

**Used For:**
- Dynamically configuring available payment methods
- Network-specific token configuration
- Merchant-specific payment options

---

## 💳 Payment Endpoints

### 3. Create Payment
**Purpose:** Create a new payment session

```http
POST /api/payments/create
```

**Headers:** Standard authentication headers

**Request Body:**
```json
{
  "amount": 100.00,
  "currency": "USDT",
  "network": "ethereum",
  "customerEmail": "customer@example.com",
  "callbackUrl": "https://your-site.com/callback",
  "metadata": {
    "orderId": "order_123",
    "customData": "any_value"
  },
  "merchantWalletAddresses": {
    "ethereum": "0x1234...",
    "bsc": "0x5678..."
  }
}
```

**Response Example:**
```json
{
  "payment": {
    "id": "pay_1234567890",
    "amount": 100.00,
    "currency": "USDT",
    "network": "ethereum",
    "status": "pending",
    "totalAmount": 101.75,
    "feeAmount": 1.75,
    "feeChargedTo": "customer",
    "recipientWallet": "0x1234...",
    "customFeePercentage": 0.0175,
    "expiresAt": "2024-01-01T12:00:00Z",
    "createdAt": "2024-01-01T11:00:00Z"
  }
}
```

**Used For:**
- Starting a new payment flow
- Generating payment IDs
- Setting up payment parameters

---

### 4. Get Payment Details
**Purpose:** Retrieve details of a specific payment

```http
GET /api/payments/{paymentId}
```

**Headers:** Standard authentication headers

**URL Parameters:**
- `paymentId` - The payment ID to retrieve

**Response Example:**
```json
{
  "payment": {
    "id": "pay_1234567890",
    "amount": 100.00,
    "currency": "USDT",
    "network": "ethereum",
    "status": "completed",
    "transactionHash": "0xabc123...",
    "confirmations": 12,
    "totalAmount": 101.75,
    "feeAmount": 1.75,
    "processedAt": "2024-01-01T11:05:00Z"
  }
}
```

**Used For:**
- Checking payment status
- Getting transaction details
- Payment verification

---

### 5. Process Payment
**Purpose:** Submit transaction hash to complete payment

```http
POST /api/payments/process
```

**Headers:** Standard authentication headers

**Request Body:**
```json
{
  "paymentId": "pay_1234567890",
  "transactionHash": "0xabc123def456...",
  "network": "ethereum",
  "senderAddress": "0x9876..." // Optional
}
```

**Response Example:**
```json
{
  "success": true,
  "payment": {
    "id": "pay_1234567890",
    "status": "processing",
    "transactionHash": "0xabc123...",
    "confirmations": 0,
    "processedAt": "2024-01-01T11:05:00Z"
  },
  "message": "Payment processing started"
}
```

**Used For:**
- Confirming payment with transaction hash
- Starting blockchain verification
- Updating payment status

---

### 6. Get Merchant Payments
**Purpose:** List payments with filtering options

```http
GET /api/payments?{query_parameters}
```

**Headers:** Standard authentication headers

**Query Parameters:**
- `status` - Filter by payment status (pending, completed, failed)
- `network` - Filter by network (ethereum, bsc, etc.)
- `currency` - Filter by currency (USDT, USDC, etc.)
- `limit` - Number of results (default: 50)
- `offset` - Pagination offset
- `startDate` - Filter from date (ISO 8601)
- `endDate` - Filter to date (ISO 8601)

**Response Example:**
```json
{
  "payments": [
    {
      "id": "pay_1234567890",
      "amount": 100.00,
      "currency": "USDT",
      "status": "completed",
      "createdAt": "2024-01-01T11:00:00Z"
    }
  ],
  "pagination": {
    "total": 150,
    "limit": 50,
    "offset": 0,
    "hasMore": true
  }
}
```

**Used For:**
- Payment history retrieval
- Dashboard analytics
- Transaction reporting

---

### 7. Get Payment Statistics
**Purpose:** Get aggregated payment statistics

```http
GET /api/payments/stats
```

**Headers:** Standard authentication headers

**Response Example:**
```json
{
  "stats": {
    "totalPayments": 1250,
    "completedPayments": 1180,
    "pendingPayments": 45,
    "failedPayments": 25,
    "totalVolume": "125000.00",
    "totalFees": "2187.50",
    "byNetwork": {
      "ethereum": {
        "count": 800,
        "volume": "85000.00"
      },
      "bsc": {
        "count": 450,
        "volume": "40000.00"
      }
    },
    "byCurrency": {
      "USDT": {
        "count": 1000,
        "volume": "100000.00"
      },
      "USDC": {
        "count": 250,
        "volume": "25000.00"
      }
    }
  }
}
```

**Used For:**
- Dashboard analytics
- Business intelligence
- Performance monitoring

---

## 🌐 Network & Configuration Endpoints

### 8. Get Supported Networks
**Purpose:** Get global supported networks and tokens

```http
GET /api/networks
```

**Headers:** Standard authentication headers

**Response Example:**
```json
{
  "networks": [
    {
      "id": "ethereum",
      "name": "Ethereum",
      "chainId": 1,
      "symbol": "ETH",
      "blockExplorerUrl": "https://etherscan.io",
      "rpcUrl": "https://mainnet.infura.io/v3/...",
      "isActive": true,
      "supportedTokens": [
        {
          "symbol": "USDT",
          "name": "Tether USD",
          "address": "0xdAC17F958D2ee523a2206206994597C13D831ec7",
          "decimals": 6
        }
      ]
    }
  ]
}
```

**Used For:**
- Getting network configurations
- Token contract addresses
- Network validation

---

## 🔐 Utility Endpoints

### 9. Validate Wallet Address
**Purpose:** Validate wallet address format for specific network

```http
POST /api/wallets/validate
```

**Headers:** Standard authentication headers

**Request Body:**
```json
{
  "address": "0x1234567890abcdef1234567890abcdef12345678",
  "network": "ethereum"
}
```

**Response Example:**
```json
{
  "isValid": true,
  "network": "ethereum",
  "addressType": "externally_owned_account",
  "checksumAddress": "0x1234567890AbCdEf1234567890AbCdEf12345678"
}
```

**Used For:**
- Address validation before payments
- Format verification
- Address checksumming

---

## 📊 Error Responses

All endpoints follow consistent error response format:

```json
{
  "error": "Error message description",
  "code": "ERROR_CODE",
  "details": {
    "field": "validation error details"
  }
}
```

**Common HTTP Status Codes:**
- `200` - Success
- `400` - Bad Request (validation errors)
- `401` - Unauthorized (invalid API credentials)
- `403` - Forbidden (insufficient permissions)
- `404` - Not Found (payment/resource not found)
- `429` - Too Many Requests (rate limiting)
- `500` - Internal Server Error

---

## 🔧 Implementation Examples

### JavaScript/Node.js Example
```javascript
const apiConfig = {
  baseUrl: 'https://hub.coinley.io',
  apiKey: 'your_api_key',
  apiSecret: 'your_api_secret'
};

const headers = {
  'Content-Type': 'application/json',
  'x-api-key': apiConfig.apiKey,
  'x-api-secret': apiConfig.apiSecret
};

// Create payment
const createPayment = async (paymentData) => {
  const response = await fetch(`${apiConfig.baseUrl}/api/payments/create`, {
    method: 'POST',
    headers,
    body: JSON.stringify(paymentData)
  });
  
  if (!response.ok) {
    throw new Error(`Payment creation failed: ${response.status}`);
  }
  
  return await response.json();
};
```

### Python Example
```python
import requests

class CoinleyAPI:
    def __init__(self, api_key, api_secret):
        self.base_url = 'https://hub.coinley.io'
        self.headers = {
            'Content-Type': 'application/json',
            'x-api-key': api_key,
            'x-api-secret': api_secret
        }
    
    def create_payment(self, payment_data):
        response = requests.post(
            f'{self.base_url}/api/payments/create',
            headers=self.headers,
            json=payment_data
        )
        response.raise_for_status()
        return response.json()
```

---

## 🔄 Integration Checklist

When building a plugin or integration:

- [ ] **Authentication:** Implement proper API key/secret handling
- [ ] **Error Handling:** Handle all error status codes appropriately
- [ ] **Rate Limiting:** Implement request throttling if needed
- [ ] **Payment Flow:** Create → Process → Verify workflow
- [ ] **Webhooks:** Consider implementing webhook endpoints for real-time updates
- [ ] **Testing:** Use test mode and mock transaction hashes for development
- [ ] **Security:** Never expose API secrets in client-side code

---

## 📞 Support

For API issues or questions:
- **Documentation:** https://docs.coinley.com
- **Support Email:** support@coinley.com  
- **Status Page:** https://status.coinley.com

---

**Last Updated:** December 2024  
**API Version:** 1.0 