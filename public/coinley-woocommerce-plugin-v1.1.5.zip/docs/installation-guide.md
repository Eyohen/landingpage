# Coinley WooCommerce Payment Gateway - Installation Guide

This guide will help you install and configure the Coinley WooCommerce Payment Gateway plugin on your WordPress store.

## Prerequisites

Before you begin, ensure you have:

1. WordPress 5.4 or higher
2. WooCommerce 4.0 or higher
3. A Coinley account (sign up at [Coinley.io](https://coinley.io) if you don't have one)
4. PHP 7.2 or higher
5. Administrator access to your WordPress website

## Installation

### Method 1: Install via WordPress Dashboard (Recommended)

1. Log in to your WordPress admin panel.
2. Go to **Plugins > Add New**.
3. In the search field, type "Coinley WooCommerce Payment Gateway".
4. Once the plugin appears, click **Install Now**.
5. After installation completes, click **Activate**.

### Method 2: Manual Installation

1. Download the plugin ZIP file from [Coinley.io](https://coinley.io/download/coinley-woocommerce.zip) or the [WordPress Plugin Directory](https://wordpress.org/plugins/coinley-woocommerce-payment-gateway/).
2. Log in to your WordPress admin panel.
3. Go to **Plugins > Add New**.
4. Click the **Upload Plugin** button at the top of the page.
5. Click **Choose File** and select the ZIP file you downloaded.
6. Click **Install Now**.
7. After installation completes, click **Activate**.

## Configuration

### Step 1: Obtain API Credentials

1. Log in to your [Coinley Dashboard](https://dashboard.coinley.io).
2. Navigate to **Settings > API Keys**.
3. Create a new API key for your store.
4. Note down your **API Key** and **API Secret**. Keep your API Secret secure!

### Step 2: Configure the Payment Gateway

1. In your WordPress admin panel, go to **WooCommerce > Settings > Payments**.
2. Find "Cryptocurrency Payment (Coinley)" and click **Manage**.
3. Configure the following settings:
   - **Enable/Disable**: Check the box to enable Coinley payments.
   - **Title**: The name displayed to customers during checkout (default: "Cryptocurrency Payment (Coinley)").
   - **Description**: Information shown to customers about this payment method.
   - **Test mode**: Enable for testing with test credentials (no actual payments will be processed).
   - **Live API Key**: Your Coinley API Key for production use.
   - **Live API Secret**: Your Coinley API Secret for production use.
   - **Test API Key**: Your Coinley Test API Key for testing.
   - **Test API Secret**: Your Coinley Test API Secret for testing.
   - **Debug log**: Enable to log API interactions for troubleshooting.
4. Click **Save changes**.

## Testing the Integration

Before going live with Coinley payments, it's important to test the integration:

1. Keep **Test mode** enabled.
2. Create a test product or use an existing one.
3. Go to your store's front end and add the product to your cart.
4. Proceed to checkout and select the Coinley payment method.
5. Complete the checkout process.
6. You'll be redirected to the Coinley test payment page.
7. Select a test cryptocurrency and complete the payment.
8. Verify that you're redirected back to your store and the order is marked as completed.

## Going Live

Once you've successfully tested the payment flow:

1. Go back to **WooCommerce > Settings > Payments > Coinley**.
2. Disable **Test mode**.
3. Ensure your **Live API Key** and **Live API Secret** are correctly entered.
4. Click **Save changes**.

Your store is now ready to accept cryptocurrency payments through Coinley!

## Customization

The plugin includes several ways to customize the checkout experience:

- To override the template files, copy them from `wp-content/plugins/coinleywp/includes/templates/` to `your-theme/coinley/`.
- CSS styles can be customized through your theme's stylesheet.

## Troubleshooting

If you encounter any issues:

1. Check the WooCommerce Status report (WooCommerce > Status).
2. Enable Debug logging in the plugin settings.
3. Review the logs at WooCommerce > Status > Logs.
4. If problems persist, contact [Coinley Support](https://coinley.io/support) with your log files.

## Security Best Practices

1. Never share your API Secret with anyone.
2. Regularly rotate your API keys from the Coinley Dashboard.
3. Keep WordPress, WooCommerce, and all plugins updated.
4. Use strong passwords for your WordPress admin and Coinley accounts.
5. Consider using two-factor authentication for your WordPress admin and Coinley accounts.

## Support

If you need assistance:

- Documentation: [Coinley Docs](https://docs.coinley.io)
- Email Support: [support@coinley.io](mailto:support@coinley.io)
- Live Chat: Available in your Coinley Dashboard 