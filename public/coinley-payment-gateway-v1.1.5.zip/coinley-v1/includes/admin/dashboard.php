<?php
/**
 * Coinley Admin Dashboard Template
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check if API is configured
$is_configured = !empty($this->gateway_settings['api_key']) && !empty($this->gateway_settings['api_secret']);
?>

<style>
/* Critical CSS to ensure styling loads immediately */
.coinleywp-admin {
    background: #f8fafc !important;
    font-family: "Bricolage Grotesque", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
    margin: 0 -20px -10px -20px !important;
    padding: 30px !important;
}

.coinleywp-header {
    background: linear-gradient(135deg, #7C3AED 0%, #8B5CF6 50%, #A855F7 100%) !important;
    color: white !important;
    padding: 32px 40px !important;
    border-radius: 24px !important;
    margin-bottom: 40px !important;
    box-shadow: 0 20px 25px -5px rgba(124, 58, 237, 0.1), 0 10px 10px -5px rgba(124, 58, 237, 0.04) !important;
}

.coinleywp-header h1 {
    color: white !important;
    font-size: 32px !important;
    font-weight: 700 !important;
    letter-spacing: -0.025em !important;
    margin: 0 0 8px 0 !important;
}

.stat-card {
    background: white !important;
    border-radius: 20px !important;
    padding: 32px !important;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06) !important;
    border: 1px solid #f1f5f9 !important;
}

.coinleywp-merchant-card {
    background: white !important;
    border-radius: 20px !important;
    padding: 32px !important;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06) !important;
    border: 1px solid #f1f5f9 !important;
}

.coinleywp-recent-transactions {
    background: white !important;
    border-radius: 20px !important;
    padding: 32px !important;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06) !important;
    border: 1px solid #f1f5f9 !important;
}
</style>

<div class="wrap coinleywp-admin">
    <div class="coinleywp-header">
        <div class="coinleywp-header-logo">
            <img src="<?php echo esc_url(COINLEYWP_PLUGIN_URL); ?>assets/images/coinley-logo.svg" alt="Coinley" style="height: 40px;">
        </div>
        <div class="coinleywp-header-content">
            <h1><?php _e('Coinley Dashboard', 'coinleywp'); ?></h1>
            <p><?php _e('Manage your cryptocurrency payments and view transaction analytics', 'coinleywp'); ?></p>
        </div>
        <?php if ($is_configured): ?>
        <div class="coinleywp-header-actions">
            <button class="button button-primary" id="refresh-dashboard">
                <span class="dashicons dashicons-update"></span>
                <?php _e('Refresh Data', 'coinleywp'); ?>
            </button>
        </div>
        <?php endif; ?>
    </div>

    <?php if (!$is_configured): ?>
    <div class="notice notice-warning">
        <p>
            <strong><?php _e('Setup Required', 'coinleywp'); ?></strong><br>
            <?php 
            printf(
                __('Please configure your Coinley API credentials in the %s to start accepting crypto payments.', 'coinleywp'),
                '<a href="' . admin_url('admin.php?page=coinley-settings') . '">' . __('settings page', 'coinleywp') . '</a>'
            );
            ?>
        </p>
    </div>
    <?php else: ?>

    <!-- Merchant Info Card -->
    <?php if ($merchant_data): ?>
    <div class="coinleywp-merchant-card">
        <div class="merchant-info">
            <h3><?php _e('Merchant Profile', 'coinleywp'); ?></h3>
            <div class="merchant-details">
                <div class="merchant-detail">
                    <label><?php _e('Merchant Name:', 'coinleywp'); ?></label>
                    <span><?php echo esc_html($merchant_data['name'] ?? 'Joshua'); ?></span>
                </div>
                <div class="merchant-detail">
                    <label><?php _e('Merchant ID:', 'coinleywp'); ?></label>
                    <span><?php echo esc_html($merchant_data['id'] ?? 'N/A'); ?></span>
                </div>
                <div class="merchant-detail">
                    <label><?php _e('Status:', 'coinleywp'); ?></label>
                    <span class="status-badge status-<?php echo esc_attr($merchant_data['status'] ?? 'active'); ?>">
                        <?php echo esc_html(ucfirst($merchant_data['status'] ?? 'Active')); ?>
                    </span>
                </div>
                <div class="merchant-detail">
                    <label><?php _e('Fee Rate:', 'coinleywp'); ?></label>
                    <span><?php echo esc_html(number_format(($merchant_data['customFeePercentage'] ?? 0.0175) * 100, 2)); ?>%</span>
                </div>
                <div class="merchant-detail">
                    <label><?php _e('Fee Charged To:', 'coinleywp'); ?></label>
                    <span class="fee-charged-badge">
                        <?php 
                        $feeChargedTo = $merchant_data['feeChargedTo'] ?? 'customer';
                        if ($feeChargedTo === 'customer') {
                            echo '<span style="color: #059669; font-weight: 600;">' . __('Customer', 'coinleywp') . '</span>';
                            echo '<small style="display: block; color: #6b7280; font-size: 0.875em;">' . __('Customer pays original amount + fee', 'coinleywp') . '</small>';
                        } else {
                            echo '<span style="color: #dc2626; font-weight: 600;">' . __('Merchant', 'coinleywp') . '</span>';
                            echo '<small style="display: block; color: #6b7280; font-size: 0.875em;">' . __('Customer pays original amount, merchant receives amount - fee', 'coinleywp') . '</small>';
                        }
                        ?>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="wallet-addresses">
            <h4><?php _e('Wallet Addresses', 'coinleywp'); ?></h4>
            <?php if (isset($merchant_data['merchantWallets'])): ?>
            <div class="wallet-list">
                <?php foreach ($merchant_data['merchantWallets'] as $network => $wallet_data): ?>
                <?php 
                    // Handle both string and array formats
                    $wallet_address = '';
                    if (is_string($wallet_data)) {
                        $wallet_address = $wallet_data;
                    } elseif (is_array($wallet_data)) {
                        // Try common wallet address properties
                        if (isset($wallet_data['walletAddress'])) {
                            $wallet_address = $wallet_data['walletAddress'];
                        } elseif (isset($wallet_data['address'])) {
                            $wallet_address = $wallet_data['address'];
                        }
                    }
                    
                    // Only display if we have a valid address
                    if (!empty($wallet_address) && is_string($wallet_address)):
                ?>
                <div class="wallet-item">
                    <strong><?php echo esc_html(ucfirst($network)); ?>:</strong>
                    <code class="wallet-address" data-address="<?php echo esc_attr($wallet_address); ?>">
                        <?php echo esc_html(substr($wallet_address, 0, 10) . '...' . substr($wallet_address, -8)); ?>
                    </code>
                    <button class="button-link copy-address" data-address="<?php echo esc_attr($wallet_address); ?>">
                        <span class="dashicons dashicons-admin-page"></span>
                    </button>
                </div>
                <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p><?php _e('No wallet addresses configured yet.', 'coinleywp'); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <?php if ($stats): ?>
    <div class="coinleywp-stats-grid">
        <div class="stat-card">
            <div class="stat-icon">
                <span class="dashicons dashicons-chart-line"></span>
            </div>
            <div class="stat-content">
                <h3><?php echo esc_html(number_format($stats['totalPayments'] ?? 0)); ?></h3>
                <p><?php _e('Total Payments', 'coinleywp'); ?></p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <span class="dashicons dashicons-yes-alt"></span>
            </div>
            <div class="stat-content">
                <h3><?php echo esc_html(number_format($stats['completedPayments'] ?? 0)); ?></h3>
                <p><?php _e('Completed', 'coinleywp'); ?></p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <span class="dashicons dashicons-clock"></span>
            </div>
            <div class="stat-content">
                <h3><?php echo esc_html(number_format($stats['pendingPayments'] ?? 0)); ?></h3>
                <p><?php _e('Pending', 'coinleywp'); ?></p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon">
                <span class="dashicons dashicons-money-alt"></span>
            </div>
            <div class="stat-content">
                <h3>$<?php echo esc_html(number_format($stats['totalVolume'] ?? 0, 2)); ?></h3>
                <p><?php _e('Total Volume', 'coinleywp'); ?></p>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Recent Transactions -->
    <div class="coinleywp-recent-transactions">
        <div class="section-header">
            <h2><?php _e('Recent Transactions', 'coinleywp'); ?></h2>
            <a href="<?php echo esc_url(admin_url('admin.php?page=coinley-transactions')); ?>" class="button">
                <?php _e('View All Transactions', 'coinleywp'); ?>
            </a>
        </div>

        <?php if (!empty($recent_transactions)): ?>
        <div class="transactions-table-wrapper">
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php _e('Payment ID', 'coinleywp'); ?></th>
                        <th><?php _e('Amount', 'coinleywp'); ?></th>
                        <th><?php _e('Currency', 'coinleywp'); ?></th>
                        <th><?php _e('Network', 'coinleywp'); ?></th>
                        <th><?php _e('Status', 'coinleywp'); ?></th>
                        <th><?php _e('Date', 'coinleywp'); ?></th>
                        <th><?php _e('Actions', 'coinleywp'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recent_transactions as $transaction): ?>
                    <tr>
                        <td>
                            <code><?php echo esc_html($transaction['id']); ?></code>
                        </td>
                        <td>
                            <strong>$<?php echo esc_html(number_format($transaction['amount'], 2)); ?></strong>
                        </td>
                        <td>
                            <span class="currency-badge"><?php echo esc_html($transaction['currency']); ?></span>
                        </td>
                        <td>
                            <?php echo esc_html(ucfirst($transaction['network'] ?? 'N/A')); ?>
                        </td>
                        <td>
                            <span class="status-badge status-<?php echo esc_attr($transaction['status']); ?>">
                                <?php echo esc_html(ucfirst($transaction['status'])); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo esc_html(date('M j, Y H:i', strtotime($transaction['createdAt']))); ?>
                        </td>
                        <td>
                            <button class="button view-transaction" data-payment-id="<?php echo esc_attr($transaction['id']); ?>">
                                <?php _e('View', 'coinleywp'); ?>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="no-transactions">
            <div class="no-transactions-icon">
                <span class="dashicons dashicons-admin-post"></span>
            </div>
            <h3><?php _e('No Transactions Yet', 'coinleywp'); ?></h3>
            <p><?php _e('Your cryptocurrency transactions will appear here once customers start making payments.', 'coinleywp'); ?></p>
        </div>
        <?php endif; ?>
    </div>

    <?php endif; ?>
</div>

<!-- Transaction Details Modal -->
<div id="transaction-modal" class="coinleywp-modal" style="display: none;">
    <div class="coinleywp-modal-content">
        <div class="coinleywp-modal-header">
            <h3><?php _e('Transaction Details', 'coinleywp'); ?></h3>
            <span class="coinleywp-modal-close">&times;</span>
        </div>
        <div class="coinleywp-modal-body">
            <div class="loading"><?php _e('Loading transaction details...', 'coinleywp'); ?></div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Copy wallet address functionality
    document.querySelectorAll('.copy-address').forEach(function(button) {
        button.addEventListener('click', function() {
            const address = this.dataset.address;
            navigator.clipboard.writeText(address).then(function() {
                button.innerHTML = '<span class="dashicons dashicons-yes"></span>';
                setTimeout(function() {
                    button.innerHTML = '<span class="dashicons dashicons-admin-page"></span>';
                }, 2000);
            });
        });
    });

    // View transaction details
    document.querySelectorAll('.view-transaction').forEach(function(button) {
        button.addEventListener('click', function() {
            const paymentId = this.dataset.paymentId;
            showTransactionDetails(paymentId);
        });
    });

    // Refresh dashboard
    const refreshBtn = document.getElementById('refresh-dashboard');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            location.reload();
        });
    }

    // Modal functionality
    const modal = document.getElementById('transaction-modal');
    const closeBtn = modal.querySelector('.coinleywp-modal-close');
    
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });

    function showTransactionDetails(paymentId) {
        const modal = document.getElementById('transaction-modal');
        const modalBody = modal.querySelector('.coinleywp-modal-body');
        
        modalBody.innerHTML = '<div class="loading"><?php _e('Loading transaction details...', 'coinleywp'); ?></div>';
        modal.style.display = 'block';

        // Make AJAX request to get transaction details
        jQuery.post(coinleywp_admin.ajax_url, {
            action: 'coinleywp_get_transaction_details',
            nonce: coinleywp_admin.nonce,
            payment_id: paymentId
        }, function(response) {
            if (response.success) {
                const transaction = response.data;
                modalBody.innerHTML = buildTransactionDetailsHTML(transaction);
            } else {
                modalBody.innerHTML = '<div class="error"><?php _e('Failed to load transaction details', 'coinleywp'); ?></div>';
            }
        });
    }

    function buildTransactionDetailsHTML(transaction) {
        return `
            <div class="transaction-details">
                <div class="detail-row">
                    <label><?php _e('Payment ID:', 'coinleywp'); ?></label>
                    <span><code>${transaction.id}</code></span>
                </div>
                <div class="detail-row">
                    <label><?php _e('Amount:', 'coinleywp'); ?></label>
                    <span><strong>$${parseFloat(transaction.amount).toFixed(2)}</strong></span>
                </div>
                <div class="detail-row">
                    <label><?php _e('Currency:', 'coinleywp'); ?></label>
                    <span class="currency-badge">${transaction.currency}</span>
                </div>
                <div class="detail-row">
                    <label><?php _e('Network:', 'coinleywp'); ?></label>
                    <span>${transaction.network}</span>
                </div>
                <div class="detail-row">
                    <label><?php _e('Status:', 'coinleywp'); ?></label>
                    <span class="status-badge status-${transaction.status}">${transaction.status}</span>
                </div>
                ${transaction.transactionHash ? `
                <div class="detail-row">
                    <label><?php _e('Transaction Hash:', 'coinleywp'); ?></label>
                    <span><code>${transaction.transactionHash}</code></span>
                </div>
                ` : ''}
                <div class="detail-row">
                    <label><?php _e('Created:', 'coinleywp'); ?></label>
                    <span>${new Date(transaction.createdAt).toLocaleString()}</span>
                </div>
                ${transaction.processedAt ? `
                <div class="detail-row">
                    <label><?php _e('Processed:', 'coinleywp'); ?></label>
                    <span>${new Date(transaction.processedAt).toLocaleString()}</span>
                </div>
                ` : ''}
            </div>
        `;
    }
});
</script> 