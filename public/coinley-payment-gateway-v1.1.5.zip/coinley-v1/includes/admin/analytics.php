<?php
/**
 * Coinley Admin Analytics Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check if API is configured
$is_configured = !empty($this->gateway_settings['api_key']) && !empty($this->gateway_settings['api_secret']);
?>

<div class="wrap coinleywp-admin">
    <div class="coinleywp-header">
        <div class="coinleywp-header-content">
            <h1><?php _e('Analytics & Reports', 'coinleywp'); ?></h1>
            <p><?php _e('View detailed analytics and insights about your cryptocurrency payments', 'coinleywp'); ?></p>
        </div>
        <?php if ($is_configured): ?>
            <div class="coinleywp-header-actions">
                <button class="button button-primary" id="refresh-analytics">
                    <span class="dashicons dashicons-update"></span>
                    <?php _e('Refresh Data', 'coinleywp'); ?>
                </button>
            </div>
        <?php endif; ?>
    </div>

    <?php if (!$is_configured): ?>
        <div class="notice notice-warning">
            <p>
                <strong><?php _e('Setup Required', 'coinleywp'); ?></strong><br>
                <?php 
                printf(
                    __('Please configure your Coinley API credentials in the %s to view analytics.', 'coinleywp'),
                    '<a href="' . admin_url('admin.php?page=coinley-settings') . '">' . __('settings page', 'coinleywp') . '</a>'
                );
                ?>
            </p>
        </div>
    <?php else: ?>

        <!-- Overview Stats -->
        <?php if ($stats): ?>
        <div class="coinleywp-analytics-overview">
            <div class="analytics-stats-grid">
                <div class="analytics-stat-card">
                    <div class="stat-header">
                        <h3><?php _e('Total Volume', 'coinleywp'); ?></h3>
                        <span class="stat-period"><?php _e('All Time', 'coinleywp'); ?></span>
                    </div>
                    <div class="stat-value">
                        $<?php echo esc_html(number_format($stats['totalVolume'] ?? 0, 2)); ?>
                    </div>
                    <div class="stat-change positive">
                        <span class="dashicons dashicons-arrow-up-alt"></span>
                        <?php _e('Total earnings', 'coinleywp'); ?>
                    </div>
                </div>

                <div class="analytics-stat-card">
                    <div class="stat-header">
                        <h3><?php _e('Success Rate', 'coinleywp'); ?></h3>
                        <span class="stat-period"><?php _e('All Time', 'coinleywp'); ?></span>
                    </div>
                    <div class="stat-value">
                        <?php 
                        $successRate = $stats['totalPayments'] > 0 
                            ? round(($stats['completedPayments'] / $stats['totalPayments']) * 100, 1) 
                            : 0;
                        echo esc_html($successRate . '%');
                        ?>
                    </div>
                    <div class="stat-change <?php echo esc_attr($successRate >= 90 ? 'positive' : 'neutral'); ?>">
                        <span class="dashicons dashicons-chart-line"></span>
                        <?php echo esc_html($stats['completedPayments']); ?>/<?php echo esc_html($stats['totalPayments']); ?> <?php _e('completed', 'coinleywp'); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

    <?php endif; ?>
</div> 