<?php
/**
 * Coinley Admin Transactions Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}

// Check if API is configured
$is_configured = !empty($this->gateway_settings['api_key']) && !empty($this->gateway_settings['api_secret']);
?>

<style>
/* Critical CSS for transactions page */
.coinleywp-admin {
    background: #f8fafc !important;
    font-family: "Bricolage Grotesque", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
    margin: 0 -20px -10px -20px !important;
    padding: 30px !important;
}

.coinleywp-header {
    background: linear-gradient(135deg, #7C3AED 0%, #8B5CF6 50%, #A855F7 100%) !important;
    color: white !important;
    padding: 32px 40px !important;
    border-radius: 24px !important;
    margin-bottom: 40px !important;
    box-shadow: 0 20px 25px -5px rgba(124, 58, 237, 0.1), 0 10px 10px -5px rgba(124, 58, 237, 0.04) !important;
    display: flex !important;
    align-items: center !important;
}

.coinleywp-header h1 {
    color: white !important;
    font-size: 32px !important;
    font-weight: 700 !important;
    letter-spacing: -0.025em !important;
    margin: 0 0 8px 0 !important;
}

.coinleywp-header p {
    margin: 0 !important;
    opacity: 0.9;
    font-size: 18px;
    font-weight: 400;
    line-height: 1.5;
}

.coinleywp-filters {
    background: white !important;
    border-radius: 20px !important;
    padding: 32px !important;
    margin-bottom: 32px !important;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03) !important;
    border: 1px solid #f1f5f9 !important;
    /* COMPLETELY KILL GRID ON MAIN CONTAINER */
    display: block !important;
    grid: none !important;
    grid-template: none !important;
    grid-template-columns: none !important;
    grid-template-rows: none !important;
    grid-template-areas: none !important;
    grid-auto-columns: none !important;
    grid-auto-rows: none !important;
    grid-auto-flow: none !important;
    grid-column-gap: none !important;
    grid-row-gap: none !important;
    grid-gap: none !important;
    /* Force block layout */
    position: static !important;
    width: 100% !important;
    box-sizing: border-box !important;
}

/* Kill grid on ALL children */
.coinleywp-filters *,
.coinleywp-filters *::before,
.coinleywp-filters *::after {
    grid: none !important;
    grid-template: none !important;
    grid-template-columns: none !important;
    grid-template-rows: none !important;
    grid-template-areas: none !important;
    grid-auto-columns: none !important;
    grid-auto-rows: none !important;
    grid-auto-flow: none !important;
    grid-column: none !important;
    grid-row: none !important;
    grid-area: none !important;
    align-self: auto !important;
    justify-self: auto !important;
}

.filter-section {
    margin-bottom: 20px !important;
    /* Complete reset */
    display: block !important;
    position: static !important;
    width: 100% !important;
    /* Kill grid */
    grid: none !important;
    grid-template: none !important;
    grid-template-columns: none !important;
    grid-template-rows: none !important;
}

.filter-container {
    display: block !important;
    width: 100% !important;
    position: static !important;
    /* Kill grid */
    grid: none !important;
    grid-template: none !important;
    grid-template-columns: none !important;
    grid-template-rows: none !important;
}

/* COMPLETELY RESET - Simple flexbox layout */
.coinleywp-admin .coinleywp-filters .filter-grid {
    display: flex !important;
    flex-direction: row !important;
    flex-wrap: wrap !important;
    gap: 20px !important;
    align-items: flex-end !important;
    justify-content: flex-start !important;
    margin: 0 !important;
    padding: 0 !important;
    width: 100% !important;
    max-width: 100% !important;
    /* KILL ALL GRID PROPERTIES */
    grid: none !important;
    grid-template: none !important;
    grid-template-columns: none !important;
    grid-template-rows: none !important;
    grid-template-areas: none !important;
    grid-auto-columns: none !important;
    grid-auto-rows: none !important;
    grid-auto-flow: none !important;
    grid-column: none !important;
    grid-row: none !important;
    grid-area: none !important;
    /* Force positioning */
    position: static !important;
    left: auto !important;
    right: auto !important;
    top: auto !important;
    bottom: auto !important;
}

.coinleywp-admin .coinleywp-filters .filter-group {
    display: flex !important;
    flex-direction: column !important;
    position: static !important;
    min-width: 140px !important;
    max-width: 200px !important;
    flex: 0 0 auto !important;
    margin: 0 !important;
    padding: 0 !important;
    /* Kill any grid item properties */
    grid-column: none !important;
    grid-row: none !important;
    grid-area: none !important;
    align-self: auto !important;
    justify-self: auto !important;
}

.coinleywp-admin .coinleywp-filters .filter-group label {
    display: block !important;
    font-weight: 600 !important;
    color: #475569 !important;
    font-size: 13px !important;
    margin: 0 0 8px 0 !important;
    padding: 0 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.05em !important;
    white-space: nowrap !important;
    line-height: 1.2 !important;
}

.coinleywp-admin .coinleywp-filters .filter-group select,
.coinleywp-admin .coinleywp-filters .filter-group input[type="date"] {
    padding: 12px 16px !important;
    border: 2px solid #e2e8f0 !important;
    border-radius: 12px !important;
    font-size: 14px !important;
    font-weight: 500 !important;
    transition: all 0.2s ease !important;
    width: 100% !important;
    max-width: 100% !important;
    min-width: 0 !important;
    background: #ffffff !important;
    color: #1e293b !important;
    height: 48px !important;
    box-sizing: border-box !important;
    -webkit-appearance: none !important;
    -moz-appearance: none !important;
    appearance: none !important;
    outline: none !important;
    margin: 0 !important;
    line-height: 1.4 !important;
    vertical-align: top !important;
}

/* Enhanced select dropdown styling with higher specificity */
.coinleywp-admin .coinleywp-filters .filter-group select {
    background-image: url('data:image/svg+xml;charset=UTF-8,%3Csvg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20"%3E%3Cpath stroke="%236b7280" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 8l4 4 4-4"/%3E%3C/svg%3E') !important;
    background-position: right 12px center !important;
    background-repeat: no-repeat !important;
    background-size: 16px !important;
    padding-right: 40px !important;
    cursor: pointer !important;
}

.coinleywp-admin .coinleywp-filters .filter-group input[type="date"] {
    padding-right: 16px !important;
    cursor: pointer !important;
}

/* Hover states with ultra-specific targeting */
.coinleywp-admin .coinleywp-filters .filter-group select:hover,
.coinleywp-admin .coinleywp-filters .filter-group input[type="date"]:hover {
    border-color: #cbd5e1 !important;
    background-color: #fafafa !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
}

/* Focus states with ultra-specific targeting */
.coinleywp-admin .coinleywp-filters .filter-group select:focus,
.coinleywp-admin .coinleywp-filters .filter-group input[type="date"]:focus {
    border-color: #7C3AED !important;
    box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.1) !important;
    background-color: #ffffff !important;
    transform: translateY(-1px) !important;
    outline: none !important;
}

/* Active/filled state with ultra-specific targeting */
.coinleywp-admin .coinleywp-filters .filter-group.has-value select,
.coinleywp-admin .coinleywp-filters .filter-group.has-value input[type="date"] {
    border-color: #7C3AED !important;
    background-color: #f9f5ff !important;
    box-shadow: 0 0 0 1px rgba(124, 58, 237, 0.1) !important;
}

.coinleywp-admin .coinleywp-filters .filter-group.has-value select:focus,
.coinleywp-admin .coinleywp-filters .filter-group.has-value input[type="date"]:focus {
    background-color: #ffffff !important;
}

/* Date input calendar icon styling */
.coinleywp-admin .coinleywp-filters .filter-group input[type="date"]::-webkit-calendar-picker-indicator {
    color: #7C3AED !important;
    cursor: pointer !important;
    padding: 2px !important;
    border-radius: 3px !important;
    margin-left: auto !important;
}

.coinleywp-admin .coinleywp-filters .filter-group input[type="date"]::-webkit-calendar-picker-indicator:hover {
    background-color: rgba(124, 58, 237, 0.1) !important;
}

/* Option styling for better visibility */
.coinleywp-admin .coinleywp-filters .filter-group select option {
    padding: 10px !important;
    font-size: 14px !important;
    color: #1e293b !important;
    background: #ffffff !important;
}

/* Filter chips for active filters */
.active-filters {
    display: flex !important;
    flex-wrap: wrap !important;
    gap: 8px !important;
    margin-bottom: 20px !important;
}

.filter-chip {
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    padding: 6px 12px !important;
    background: #f3f0ff !important;
    border: 1px solid #e0d9ff !important;
    border-radius: 20px !important;
    font-size: 13px !important;
    font-weight: 500 !important;
    color: #7C3AED !important;
    transition: all 0.2s ease !important;
}

.filter-chip:hover {
    background: #ede7ff !important;
    border-color: #d4c9ff !important;
}

.filter-chip .remove-filter {
    cursor: pointer !important;
    width: 16px !important;
    height: 16px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    border-radius: 50% !important;
    background: #7C3AED !important;
    color: white !important;
    font-size: 12px !important;
    line-height: 1 !important;
}

.filter-chip .remove-filter:hover {
    background: #6B2FD6 !important;
}

/* Enhanced action buttons */
.filter-actions {
    display: flex !important;
    gap: 16px !important;
    flex-wrap: wrap !important;
    margin-top: 20px !important;
    padding-top: 20px !important;
    border-top: 1px solid #f1f5f9 !important;
    justify-content: flex-start !important;
    align-items: center !important;
}

.filter-actions .button {
    display: inline-flex !important;
    align-items: center !important;
    gap: 8px !important;
    padding: 12px 24px !important;
    border-radius: 12px !important;
    font-weight: 600 !important;
    font-size: 14px !important;
    transition: all 0.2s ease !important;
    border: 2px solid transparent !important;
    cursor: pointer !important;
}

.filter-actions .button-primary {
    background: linear-gradient(135deg, #7C3AED, #8B5CF6) !important;
    border: none !important;
    color: white !important;
    box-shadow: 0 4px 14px 0 rgba(124, 58, 237, 0.25) !important;
}

.filter-actions .button-primary:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 20px 0 rgba(124, 58, 237, 0.35) !important;
}

.filter-actions .button-primary:active {
    transform: translateY(0) !important;
    box-shadow: 0 2px 8px 0 rgba(124, 58, 237, 0.25) !important;
}

.filter-actions .button:not(.button-primary) {
    background: #f8fafc !important;
    border: 2px solid #e2e8f0 !important;
    color: #475569 !important;
}

.filter-actions .button:not(.button-primary):hover {
    background: #f1f5f9 !important;
    border-color: #cbd5e1 !important;
    color: #334155 !important;
}

.filter-actions .button .dashicons {
    font-size: 18px !important;
    width: 18px !important;
    height: 18px !important;
    line-height: 1 !important;
}

/* Filter counter badge */
.filter-count {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    min-width: 20px !important;
    height: 20px !important;
    padding: 0 6px !important;
    background: #7C3AED !important;
    color: white !important;
    border-radius: 10px !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    margin-left: 4px !important;
}

.coinleywp-transactions-wrapper {
    background: white !important;
    border-radius: 20px !important;
    padding: 32px !important;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06) !important;
    border: 1px solid #f1f5f9 !important;
}

.table-nav {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    margin-bottom: 24px !important;
    padding-bottom: 20px !important;
    border-bottom: 2px solid #f1f5f9 !important;
}

.transaction-count {
    font-weight: 600 !important;
    color: #475569 !important;
    font-size: 16px !important;
}

.table-nav .button {
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    color: #475569 !important;
    padding: 10px 16px !important;
    border-radius: 10px !important;
    font-weight: 600 !important;
    transition: all 0.2s ease !important;
}

.table-nav .button:hover {
    background: #7C3AED !important;
    border-color: #7C3AED !important;
    color: white !important;
    transform: translateY(-1px) !important;
}

/* Enhanced table styling */
#transactions-table {
    border: none !important;
    box-shadow: none !important;
}

#transactions-table thead th {
    background: #f8fafc !important;
    border-bottom: 2px solid #e2e8f0 !important;
    color: #475569 !important;
    font-weight: 700 !important;
    text-transform: uppercase !important;
    font-size: 12px !important;
    letter-spacing: 0.05em !important;
    padding: 16px 12px !important;
}

#transactions-table tbody tr {
    border-bottom: 1px solid #f1f5f9 !important;
    transition: background-color 0.15s ease !important;
}

#transactions-table tbody tr:hover {
    background-color: #fafbfc !important;
}

#transactions-table tbody td {
    padding: 16px 12px !important;
    vertical-align: middle !important;
}

/* Status badge styling */
.status-badge {
    display: inline-flex !important;
    align-items: center !important;
    padding: 6px 12px !important;
    border-radius: 20px !important;
    font-size: 12px !important;
    font-weight: 600 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.025em !important;
}

.status-badge.status-pending {
    background: #fef3c7 !important;
    color: #92400e !important;
}

.status-badge.status-processing {
    background: #dbeafe !important;
    color: #1e40af !important;
}

.status-badge.status-completed {
    background: #d1fae5 !important;
    color: #065f46 !important;
}

.status-badge.status-failed {
    background: #fee2e2 !important;
    color: #991b1b !important;
}

/* Currency badge styling */
.currency-badge {
    display: inline-flex !important;
    align-items: center !important;
    padding: 4px 10px !important;
    background: #f3f0ff !important;
    border: 1px solid #e0d9ff !important;
    border-radius: 8px !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    color: #7C3AED !important;
}

/* Transaction hash styling */
.transaction-hash {
    background: #f8fafc !important;
    padding: 4px 8px !important;
    border-radius: 6px !important;
    font-family: 'SF Mono', Monaco, 'Courier New', monospace !important;
    font-size: 12px !important;
    color: #475569 !important;
}

/* View button styling */
.view-transaction {
    background: transparent !important;
    border: 1px solid #e2e8f0 !important;
    color: #7C3AED !important;
    padding: 6px 16px !important;
    border-radius: 8px !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    transition: all 0.15s ease !important;
    cursor: pointer !important;
}

.view-transaction:hover {
    background: #7C3AED !important;
    border-color: #7C3AED !important;
    color: white !important;
    transform: translateY(-1px) !important;
    box-shadow: 0 2px 8px rgba(124, 58, 237, 0.2) !important;
}

/* Loading state improvements */
.loading {
    text-align: center !important;
    padding: 60px 20px !important;
    color: #64748b !important;
}

.loading .spinner {
    margin: 0 auto 16px !important;
}

/* No data state */
.no-data {
    text-align: center !important;
    padding: 60px 20px !important;
    color: #94a3b8 !important;
    font-size: 16px !important;
}

/* Refresh button spin animation */
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.dashicons-update-spin {
    animation: spin 1s linear infinite !important;
}

/* Responsive Design with ultra-specific targeting */
@media (max-width: 1200px) {
    .coinleywp-admin .coinleywp-filters .filter-grid {
        flex-wrap: wrap !important;
    }
}

@media (max-width: 1024px) {
    .coinleywp-admin .coinleywp-filters .filter-grid {
        flex-wrap: wrap !important;
    }
}

@media (max-width: 768px) {
    .coinleywp-admin {
        padding: 16px !important;
    }
    
    .coinleywp-header {
        padding: 24px !important;
        text-align: center !important;
    }
    
    .coinleywp-header h1 {
        font-size: 24px !important;
    }
    
    .coinleywp-filters {
        padding: 20px !important;
    }
    
    .coinleywp-admin .coinleywp-filters .filter-grid {
        grid-template-columns: 1fr !important;
        gap: 16px !important;
    }
    
    .coinleywp-admin .coinleywp-filters .filter-group {
        min-height: 70px !important;
    }
    
    .coinleywp-admin .coinleywp-filters .filter-group label {
        font-size: 12px !important;
    }
    
    .coinleywp-admin .coinleywp-filters .filter-group select,
    .coinleywp-admin .coinleywp-filters .filter-group input[type="date"] {
        height: 44px !important;
        padding: 10px 14px !important;
        font-size: 13px !important;
    }
    
    .coinleywp-admin .coinleywp-filters .filter-group select {
        padding-right: 36px !important;
        background-size: 14px !important;
        background-position: right 10px center !important;
    }
    
    .filter-actions {
        flex-direction: column !important;
        gap: 12px !important;
    }
    
    .filter-actions .button {
        width: 100% !important;
        justify-content: center !important;
    }
    
    .active-filters {
        flex-direction: column !important;
        align-items: flex-start !important;
    }
    
    .filter-chip {
        margin-bottom: 4px !important;
    }
    
    .coinleywp-transactions-wrapper {
        padding: 16px !important;
        overflow-x: auto !important;
    }
    
    .table-nav {
        flex-direction: column !important;
        gap: 16px !important;
        text-align: center !important;
    }
    
    #transactions-table {
        min-width: 800px !important;
    }
}

@media (max-width: 480px) {
    .coinleywp-header h1 {
        font-size: 20px !important;
    }
    
    .coinleywp-header p {
        font-size: 14px !important;
    }
    
    .filter-section-title {
        font-size: 14px !important;
    }
    
    .coinleywp-admin .coinleywp-filters .filter-group {
        min-height: 65px !important;
    }
    
    .coinleywp-admin .coinleywp-filters .filter-group select,
    .coinleywp-admin .coinleywp-filters .filter-group input[type="date"] {
        height: 40px !important;
        padding: 8px 12px !important;
        font-size: 12px !important;
    }
    
    .coinleywp-admin .coinleywp-filters .filter-group select {
        padding-right: 32px !important;
        background-size: 12px !important;
        background-position: right 8px center !important;
    }
}
</style>

<div class="wrap coinleywp-admin">
    <div class="coinleywp-header">
        <div class="coinleywp-header-content">
            <h1><?php _e('Transaction Management', 'coinleywp'); ?></h1>
            <p><?php _e('View and manage all cryptocurrency transactions for your store', 'coinleywp'); ?></p>
        </div>
    </div>

    <?php if (!$is_configured): ?>
    <div class="notice notice-warning">
        <p>
            <strong><?php _e('Setup Required', 'coinleywp'); ?></strong><br>
            <?php 
            printf(
                __('Please configure your Coinley API credentials in the %s to view transactions.', 'coinleywp'),
                '<a href="' . admin_url('admin.php?page=coinley-settings') . '">' . __('settings page', 'coinleywp') . '</a>'
            );
            ?>
        </p>
    </div>
    <?php else: ?>

    <!-- Enhanced Filters -->
    <div class="coinleywp-filters">
        <!-- Active Filters Display -->
        <div class="active-filters" id="active-filters-container" style="display: none;">
            <!-- Active filter chips will be populated by JavaScript -->
        </div>

        <div class="filter-section">
            <div class="filter-container">
                <div class="filter-grid">
                    <!-- Status Filter -->
                    <div class="filter-group" data-filter="status">
                        <label for="status-filter"><?php _e('Status', 'coinleywp'); ?></label>
                        <select id="status-filter" class="filter-input">
                            <option value=""><?php _e('All Statuses', 'coinleywp'); ?></option>
                            <option value="pending"><?php _e('Pending', 'coinleywp'); ?></option>
                            <option value="processing"><?php _e('Processing', 'coinleywp'); ?></option>
                            <option value="completed"><?php _e('Completed', 'coinleywp'); ?></option>
                            <option value="failed"><?php _e('Failed', 'coinleywp'); ?></option>
                        </select>
                    </div>

                    <!-- Currency Filter -->
                    <div class="filter-group" data-filter="currency">
                        <label for="currency-filter"><?php _e('Currency', 'coinleywp'); ?></label>
                        <select id="currency-filter" class="filter-input">
                            <option value=""><?php _e('All Currencies', 'coinleywp'); ?></option>
                            <option value="USDT">USDT</option>
                            <option value="USDC">USDC</option>
                            <option value="BNB">BNB</option>
                            <option value="ETH">ETH</option>
                            <option value="SOL">SOL</option>
                        </select>
                    </div>

                    <!-- Network Filter -->
                    <div class="filter-group" data-filter="network">
                        <label for="network-filter"><?php _e('Network', 'coinleywp'); ?></label>
                        <select id="network-filter" class="filter-input">
                            <option value=""><?php _e('All Networks', 'coinleywp'); ?></option>
                            <option value="ethereum">Ethereum</option>
                            <option value="bsc">BSC</option>
                            <option value="polygon">Polygon</option>
                            <option value="solana">Solana</option>
                        </select>
                    </div>

                    <!-- From Date Filter -->
                    <div class="filter-group" data-filter="date-from">
                        <label for="date-from"><?php _e('From Date', 'coinleywp'); ?></label>
                        <input type="date" id="date-from" class="filter-input">
                    </div>

                    <!-- To Date Filter -->
                    <div class="filter-group" data-filter="date-to">
                        <label for="date-to"><?php _e('To Date', 'coinleywp'); ?></label>
                        <input type="date" id="date-to" class="filter-input">
                    </div>
                </div>

                <!-- Filter Action Buttons -->
                <div class="filter-actions">
                    <button class="button button-primary" id="apply-filters">
                        <span class="dashicons dashicons-filter"></span>
                        <?php _e('Apply Filters', 'coinleywp'); ?>
                        <span class="filter-count" id="filter-count" style="display: none;">0</span>
                    </button>
                    <button class="button" id="clear-filters">
                        <span class="dashicons dashicons-dismiss"></span>
                        <?php _e('Clear All', 'coinleywp'); ?>
                    </button>
                    <button class="button" id="export-transactions">
                        <span class="dashicons dashicons-download"></span>
                        <?php _e('Export', 'coinleywp'); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Transactions Table -->
    <div class="coinleywp-transactions-wrapper">
        <div class="table-nav">
            <div class="table-nav-left">
                <span class="transaction-count"><?php _e('Loading transactions...', 'coinleywp'); ?></span>
            </div>
            <div class="table-nav-right">
                <button class="button" id="refresh-transactions">
                    <span class="dashicons dashicons-update"></span>
                    <?php _e('Refresh', 'coinleywp'); ?>
                </button>
            </div>
        </div>

        <table class="wp-list-table widefat fixed striped" id="transactions-table">
            <thead>
                <tr>
                    <th class="check-column">
                        <input type="checkbox" id="select-all-transactions">
                    </th>
                    <th><?php _e('Payment ID', 'coinleywp'); ?></th>
                    <th><?php _e('Amount', 'coinleywp'); ?></th>
                    <th><?php _e('Currency', 'coinleywp'); ?></th>
                    <th><?php _e('Network', 'coinleywp'); ?></th>
                    <th><?php _e('Status', 'coinleywp'); ?></th>
                    <th><?php _e('Transaction Hash', 'coinleywp'); ?></th>
                    <th><?php _e('Date', 'coinleywp'); ?></th>
                    <th><?php _e('Actions', 'coinleywp'); ?></th>
                </tr>
            </thead>
            <tbody id="transactions-tbody">
                <tr>
                    <td colspan="9" class="loading">
                        <div class="spinner is-active"></div>
                        <?php _e('Loading transactions...', 'coinleywp'); ?>
                    </td>
                </tr>
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="tablenav bottom">
            <div class="alignleft actions">
                <select id="bulk-action">
                    <option value=""><?php _e('Bulk Actions', 'coinleywp'); ?></option>
                    <option value="export"><?php _e('Export Selected', 'coinleywp'); ?></option>
                </select>
                <button class="button action" id="apply-bulk-action">
                    <?php _e('Apply', 'coinleywp'); ?>
                </button>
            </div>
            <div class="tablenav-pages" id="pagination-container">
                <!-- Pagination will be populated by JavaScript -->
            </div>
        </div>
    </div>

    <?php endif; ?>
</div>

<!-- Transaction Details Modal -->
<div id="transaction-modal" class="coinleywp-modal" style="display: none;">
    <div class="coinleywp-modal-content large">
        <div class="coinleywp-modal-header">
            <h3><?php _e('Transaction Details', 'coinleywp'); ?></h3>
            <span class="coinleywp-modal-close">&times;</span>
        </div>
        <div class="coinleywp-modal-body">
            <div class="loading"><?php _e('Loading transaction details...', 'coinleywp'); ?></div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let currentPage = 1;
    let currentFilters = {};
    let activeFilterCount = 0;
    
    // Initialize filter functionality
    initializeFilters();
    
    // Load initial transactions
    loadTransactions();
    
    function initializeFilters() {
        // Add change listeners to all filter inputs
        document.querySelectorAll('.filter-input').forEach(input => {
            input.addEventListener('change', function() {
                updateFilterVisualState(this);
                updateActiveFilterCount();
            });
        });
        
        // Apply filters button
        document.getElementById('apply-filters').addEventListener('click', function() {
            applyFilters();
        });
        
        // Clear filters button
        document.getElementById('clear-filters').addEventListener('click', function() {
            clearAllFilters();
        });
        
        // Refresh button
        document.getElementById('refresh-transactions').addEventListener('click', function() {
            const btn = this;
            btn.querySelector('.dashicons').classList.add('dashicons-update-spin');
            loadTransactions(() => {
                btn.querySelector('.dashicons').classList.remove('dashicons-update-spin');
            });
        });
    }
    
    function updateFilterVisualState(input) {
        const filterGroup = input.closest('.filter-group');
        if (input.value) {
            filterGroup.classList.add('has-value');
        } else {
            filterGroup.classList.remove('has-value');
        }
    }
    
    function updateActiveFilterCount() {
        activeFilterCount = 0;
        document.querySelectorAll('.filter-input').forEach(input => {
            if (input.value) activeFilterCount++;
        });
        
        const filterCountBadge = document.getElementById('filter-count');
        if (activeFilterCount > 0) {
            filterCountBadge.textContent = activeFilterCount;
            filterCountBadge.style.display = 'inline-flex';
        } else {
            filterCountBadge.style.display = 'none';
        }
    }
    
    function applyFilters() {
        currentFilters = {
            status: document.getElementById('status-filter').value,
            currency: document.getElementById('currency-filter').value,
            network: document.getElementById('network-filter').value,
            start_date: document.getElementById('date-from').value,
            end_date: document.getElementById('date-to').value
        };
        currentPage = 1;
        updateActiveFiltersDisplay();
        loadTransactions();
    }
    
    function updateActiveFiltersDisplay() {
        const container = document.getElementById('active-filters-container');
        const activeFilters = [];
        
        // Build active filter chips
        Object.entries(currentFilters).forEach(([key, value]) => {
            if (value) {
                let displayName = '';
                let displayValue = value;
                
                switch(key) {
                    case 'status':
                        displayName = '<?php _e('Status', 'coinleywp'); ?>';
                        displayValue = value.charAt(0).toUpperCase() + value.slice(1);
                        break;
                    case 'currency':
                        displayName = '<?php _e('Currency', 'coinleywp'); ?>';
                        break;
                    case 'network':
                        displayName = '<?php _e('Network', 'coinleywp'); ?>';
                        displayValue = value.charAt(0).toUpperCase() + value.slice(1);
                        break;
                    case 'start_date':
                        displayName = '<?php _e('From', 'coinleywp'); ?>';
                        displayValue = new Date(value).toLocaleDateString();
                        break;
                    case 'end_date':
                        displayName = '<?php _e('To', 'coinleywp'); ?>';
                        displayValue = new Date(value).toLocaleDateString();
                        break;
                }
                
                activeFilters.push(`
                    <div class="filter-chip" data-filter="${key}">
                        <span>${displayName}: <strong>${displayValue}</strong></span>
                        <span class="remove-filter" data-filter="${key}">×</span>
                    </div>
                `);
            }
        });
        
        if (activeFilters.length > 0) {
            container.innerHTML = activeFilters.join('');
            container.style.display = 'flex';
            
            // Add remove filter listeners
            container.querySelectorAll('.remove-filter').forEach(btn => {
                btn.addEventListener('click', function() {
                    removeFilter(this.dataset.filter);
                });
            });
        } else {
            container.style.display = 'none';
        }
    }
    
    function removeFilter(filterKey) {
        // Clear the specific filter
        switch(filterKey) {
            case 'status':
                document.getElementById('status-filter').value = '';
                break;
            case 'currency':
                document.getElementById('currency-filter').value = '';
                break;
            case 'network':
                document.getElementById('network-filter').value = '';
                break;
            case 'start_date':
                document.getElementById('date-from').value = '';
                break;
            case 'end_date':
                document.getElementById('date-to').value = '';
                break;
        }
        
        // Update visual state
        const input = document.querySelector(`[data-filter="${filterKey}"] .filter-input`);
        if (input) updateFilterVisualState(input);
        
        updateActiveFilterCount();
        applyFilters();
    }
    
    function clearAllFilters() {
        document.querySelectorAll('.filter-input').forEach(input => {
            input.value = '';
            updateFilterVisualState(input);
        });
        currentFilters = {};
        currentPage = 1;
        updateActiveFilterCount();
        updateActiveFiltersDisplay();
        loadTransactions();
    }
    
    // Select all functionality
    document.getElementById('select-all-transactions').addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('#transactions-tbody input[type="checkbox"]');
        checkboxes.forEach(cb => cb.checked = this.checked);
    });
    
    function loadTransactions(callback) {
        const tbody = document.getElementById('transactions-tbody');
        tbody.innerHTML = '<tr><td colspan="9" class="loading"><div class="spinner is-active"></div> <?php _e('Loading transactions...', 'coinleywp'); ?></td></tr>';
        
        const data = Object.assign({
            action: 'coinleywp_fetch_transactions',
            nonce: coinleywp_admin.nonce,
            limit: 20,
            offset: (currentPage - 1) * 20
        }, currentFilters);
        
        jQuery.post(coinleywp_admin.ajax_url, data, function(response) {
            if (response.success) {
                displayTransactions(response.data.payments || []);
                updatePagination(response.data.pagination || {});
                updateTransactionCount(response.data.pagination || {});
            } else {
                tbody.innerHTML = '<tr><td colspan="9" class="error"><?php _e('Failed to load transactions', 'coinleywp'); ?></td></tr>';
            }
            if (callback) callback();
        });
    }
    
    function displayTransactions(transactions) {
        const tbody = document.getElementById('transactions-tbody');
        
        if (transactions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="no-data"><?php _e('No transactions found', 'coinleywp'); ?></td></tr>';
            return;
        }
        
        tbody.innerHTML = transactions.map(transaction => `
            <tr>
                <td class="check-column">
                    <input type="checkbox" value="${transaction.id}">
                </td>
                <td>
                    <code>${transaction.id}</code>
                </td>
                <td>
                    <strong>$${parseFloat(transaction.amount).toFixed(2)}</strong>
                </td>
                <td>
                    <span class="currency-badge">${transaction.currency}</span>
                </td>
                <td>
                    ${transaction.network || 'N/A'}
                </td>
                <td>
                    <span class="status-badge status-${transaction.status}">${transaction.status}</span>
                </td>
                <td>
                    ${transaction.transactionHash ? 
                        `<code class="transaction-hash" title="${transaction.transactionHash}">${transaction.transactionHash.substring(0, 10)}...${transaction.transactionHash.substring(transaction.transactionHash.length - 8)}</code>` : 
                        'N/A'
                    }
                </td>
                <td>
                    ${new Date(transaction.createdAt).toLocaleDateString()} ${new Date(transaction.createdAt).toLocaleTimeString()}
                </td>
                <td>
                    <button class="button view-transaction" data-payment-id="${transaction.id}">
                        <?php _e('View', 'coinleywp'); ?>
                    </button>
                </td>
            </tr>
        `).join('');
        
        // Add event listeners to view buttons
        tbody.querySelectorAll('.view-transaction').forEach(button => {
            button.addEventListener('click', function() {
                showTransactionDetails(this.dataset.paymentId);
            });
        });
    }
    
    function updatePagination(pagination) {
        const container = document.getElementById('pagination-container');
        if (!pagination.total) {
            container.innerHTML = '';
            return;
        }
        
        const totalPages = Math.ceil(pagination.total / pagination.limit);
        const currentPageNum = Math.floor(pagination.offset / pagination.limit) + 1;
        
        let paginationHTML = '<span class="pagination-links">';
        
        // Previous page
        if (currentPageNum > 1) {
            paginationHTML += `<a class="prev-page" href="#" data-page="${currentPageNum - 1}">‹</a>`;
        }
        
        // Page numbers
        for (let i = Math.max(1, currentPageNum - 2); i <= Math.min(totalPages, currentPageNum + 2); i++) {
            if (i === currentPageNum) {
                paginationHTML += `<span class="paging-input">${i}</span>`;
            } else {
                paginationHTML += `<a class="page-number" href="#" data-page="${i}">${i}</a>`;
            }
        }
        
        // Next page
        if (currentPageNum < totalPages) {
            paginationHTML += `<a class="next-page" href="#" data-page="${currentPageNum + 1}">›</a>`;
        }
        
        paginationHTML += '</span>';
        container.innerHTML = paginationHTML;
        
        // Add event listeners
        container.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                currentPage = parseInt(this.dataset.page);
                loadTransactions();
            });
        });
    }
    
    function updateTransactionCount(pagination) {
        const countEl = document.querySelector('.transaction-count');
        if (pagination.total) {
            const start = pagination.offset + 1;
            const end = Math.min(pagination.offset + pagination.limit, pagination.total);
            countEl.textContent = `<?php _e('Showing', 'coinleywp'); ?> ${start}-${end} <?php _e('of', 'coinleywp'); ?> ${pagination.total} <?php _e('transactions', 'coinleywp'); ?>`;
        } else {
            countEl.textContent = '<?php _e('No transactions found', 'coinleywp'); ?>';
        }
    }
    
    function showTransactionDetails(paymentId) {
        const modal = document.getElementById('transaction-modal');
        const modalBody = modal.querySelector('.coinleywp-modal-body');
        
        modalBody.innerHTML = '<div class="loading"><?php _e('Loading transaction details...', 'coinleywp'); ?></div>';
        modal.style.display = 'block';

        jQuery.post(coinleywp_admin.ajax_url, {
            action: 'coinleywp_get_transaction_details',
            nonce: coinleywp_admin.nonce,
            payment_id: paymentId
        }, function(response) {
            if (response.success) {
                modalBody.innerHTML = buildTransactionDetailsHTML(response.data);
            } else {
                modalBody.innerHTML = '<div class="error"><?php _e('Failed to load transaction details', 'coinleywp'); ?></div>';
            }
        });
    }
    
    function buildTransactionDetailsHTML(transaction) {
        return `
            <div class="transaction-details">
                <div class="detail-section">
                    <h4><?php _e('Payment Information', 'coinleywp'); ?></h4>
                    <div class="detail-grid">
                        <div class="detail-row">
                            <label><?php _e('Payment ID:', 'coinleywp'); ?></label>
                            <span><code>${transaction.id}</code></span>
                        </div>
                        <div class="detail-row">
                            <label><?php _e('Amount:', 'coinleywp'); ?></label>
                            <span><strong>$${parseFloat(transaction.amount).toFixed(2)}</strong></span>
                        </div>
                        <div class="detail-row">
                            <label><?php _e('Total Amount:', 'coinleywp'); ?></label>
                            <span><strong>$${parseFloat(transaction.totalAmount || transaction.amount).toFixed(2)}</strong></span>
                        </div>
                        <div class="detail-row">
                            <label><?php _e('Fee Amount:', 'coinleywp'); ?></label>
                            <span>$${parseFloat(transaction.feeAmount || 0).toFixed(2)}</span>
                        </div>
                        <div class="detail-row">
                            <label><?php _e('Currency:', 'coinleywp'); ?></label>
                            <span class="currency-badge">${transaction.currency}</span>
                        </div>
                        <div class="detail-row">
                            <label><?php _e('Network:', 'coinleywp'); ?></label>
                            <span>${transaction.network}</span>
                        </div>
                        <div class="detail-row">
                            <label><?php _e('Status:', 'coinleywp'); ?></label>
                            <span class="status-badge status-${transaction.status}">${transaction.status}</span>
                        </div>
                    </div>
                </div>
                
                ${transaction.transactionHash ? `
                <div class="detail-section">
                    <h4><?php _e('Blockchain Information', 'coinleywp'); ?></h4>
                    <div class="detail-grid">
                        <div class="detail-row">
                            <label><?php _e('Transaction Hash:', 'coinleywp'); ?></label>
                            <span><code>${transaction.transactionHash}</code></span>
                        </div>
                        <div class="detail-row">
                            <label><?php _e('Confirmations:', 'coinleywp'); ?></label>
                            <span>${transaction.confirmations || 'N/A'}</span>
                        </div>
                    </div>
                </div>
                ` : ''}
                
                <div class="detail-section">
                    <h4><?php _e('Timeline', 'coinleywp'); ?></h4>
                    <div class="detail-grid">
                        <div class="detail-row">
                            <label><?php _e('Created:', 'coinleywp'); ?></label>
                            <span>${new Date(transaction.createdAt).toLocaleString()}</span>
                        </div>
                        ${transaction.processedAt ? `
                        <div class="detail-row">
                            <label><?php _e('Processed:', 'coinleywp'); ?></label>
                            <span>${new Date(transaction.processedAt).toLocaleString()}</span>
                        </div>
                        ` : ''}
                        ${transaction.expiresAt ? `
                        <div class="detail-row">
                            <label><?php _e('Expires:', 'coinleywp'); ?></label>
                            <span>${new Date(transaction.expiresAt).toLocaleString()}</span>
                        </div>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }
    
    // Modal close functionality
    const modal = document.getElementById('transaction-modal');
    const closeBtn = modal.querySelector('.coinleywp-modal-close');
    
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});
</script>