<?php
/**
 * Coinley Admin Settings Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Normalize network name for admin display
 */
function normalize_network_name_for_admin($network_name) {
    $network_mapping = array(
        'ethereum' => 'ethereum',
        'bsc' => 'bsc', 
        'tron' => 'tron',
        'algorand' => 'algorand',
        'solana' => 'solana',
        // Handle alternative names
        'eth' => 'ethereum',
        'bnb' => 'bsc',
        'trx' => 'tron'
    );
    
    $normalized = strtolower(trim($network_name));
    return $network_mapping[$normalized] ?? $normalized;
}

// Check if API is configured
$is_configured = !empty($this->gateway_settings['api_key']) && !empty($this->gateway_settings['api_secret']);

// Get merchant networks and tokens if API is configured
$networks_data = array();
$merchant_wallets = array();
$fee_settings = array();

if ($is_configured && $this->api) {
    try {
        // Fetch networks and tokens
        $networks_response = $this->api->get_merchant_networks_and_tokens();
        if (!is_wp_error($networks_response) && is_array($networks_response)) {
            $networks_data = array(
                'networks' => $networks_response['networks'] ?? array(),
                'tokens' => $networks_response['tokens'] ?? array()
            );
        }

        // Fetch wallet data - use the gateway method which formats the response correctly
        if ($this->gateway && method_exists($this->gateway, 'get_merchant_wallets')) {
            $formatted_wallets = $this->gateway->get_merchant_wallets();

            // Convert formatted wallets to array format expected by the frontend
            // The API returns: [{ networkShortName: 'ethereum', walletAddress: '0x...', supportedTokens: ['USDT'] }]
            // We need to transform it for display
            $merchant_wallets_display = array();

            if (!empty($formatted_wallets)) {
                // Get the full wallet data for display
                $full_wallet_data = get_option('coinleywp_merchant_wallets_full', array());

                foreach ($full_wallet_data as $network => $data) {
                    if (is_array($data)) {
                        $merchant_wallets_display[] = array(
                            'networkShortName' => $network,
                            'networkName' => $data['networkName'] ?? ucfirst($network),
                            'networkType' => $data['networkType'] ?? $network,
                            'networkLogo' => $data['networkLogo'] ?? '',
                            'walletAddress' => $data['address'] ?? '',
                            'supportedTokens' => $data['supportedTokens'] ?? array(),
                            'isConfigured' => $data['isConfigured'] ?? !empty($data['address'])
                        );
                    }
                }

                $merchant_wallets = $merchant_wallets_display;
            }
        }

        // Fetch fee settings
        $fee_response = $this->api->get_merchant_fee_settings();
        if (!is_wp_error($fee_response) && isset($fee_response['feeSettings'])) {
            $fee_settings = $fee_response['feeSettings'];
        }
    } catch (Exception $e) {
        // Log error and continue with fallback data
        error_log('CoinleyWP: Settings API Error: ' . $e->getMessage());
    }
}

// If API failed or no wallets returned, try to get cached wallet addresses
if (empty($merchant_wallets)) {
    $gateway_settings = get_option('woocommerce_coinleywp_settings', array());
    $cached_wallets = $gateway_settings['merchant_wallets'] ?? array();
    
    if (!empty($cached_wallets)) {
        $merchant_wallets = $cached_wallets;
        // Add a notice that we're showing cached data
        if ($is_configured) {
            $wallet_cache_notice = true;
        }
    }
}


?>

<style>
/* Critical CSS for settings page */
.coinleywp-admin {
    background: #f8fafc !important;
    font-family: "Bricolage Grotesque", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
    margin: 0 -20px -10px -20px !important;
    padding: 30px !important;
}

.coinleywp-header {
    background: linear-gradient(135deg, #7C3AED 0%, #8B5CF6 50%, #A855F7 100%) !important;
    color: white !important;
    padding: 32px 40px !important;
    border-radius: 24px !important;
    margin-bottom: 40px !important;
    box-shadow: 0 20px 25px -5px rgba(124, 58, 237, 0.1), 0 10px 10px -5px rgba(124, 58, 237, 0.04) !important;
    display: flex !important;
    align-items: center !important;
}

.coinleywp-header h1 {
    color: white !important;
    font-size: 32px !important;
    font-weight: 700 !important;
    letter-spacing: -0.025em !important;
    margin: 0 0 8px 0 !important;
}

.coinleywp-header p {
    margin: 0 !important;
    opacity: 0.9;
    font-size: 18px;
    font-weight: 400;
    line-height: 1.5;
}

.coinleywp-settings-container {
    display: grid !important;
    gap: 32px !important;
}

.settings-section {
    background: white !important;
    border-radius: 20px !important;
    padding: 32px !important;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06) !important;
    border: 1px solid #f1f5f9 !important;
    transition: box-shadow 0.2s ease !important;
}

.settings-section:hover {
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05) !important;
}

.section-header {
    margin-bottom: 32px !important;
    padding-bottom: 20px !important;
    border-bottom: 2px solid #f1f5f9 !important;
}

.section-header h2 {
    margin: 0 0 8px 0 !important;
    font-size: 24px !important;
    font-weight: 700 !important;
    color: #1e293b !important;
    letter-spacing: -0.025em !important;
}

.section-header p {
    margin: 0 !important;
    color: #64748b !important;
    font-size: 16px !important;
    line-height: 1.6 !important;
}

.form-grid {
    display: grid !important;
    gap: 24px !important;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)) !important;
}

.form-group {
    display: flex !important;
    flex-direction: column !important;
    gap: 8px !important;
}

.form-group label {
    font-weight: 600 !important;
    color: #475569 !important;
    font-size: 14px !important;
    margin: 0 !important;
}

.form-group input,
.form-group textarea,
.form-group select {
    padding: 12px 16px !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 12px !important;
    font-size: 14px !important;
    transition: all 0.2s ease !important;
    background: white !important;
    color: #1e293b !important;
    font-family: inherit !important;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
    outline: none !important;
    border-color: #7C3AED !important;
    box-shadow: 0 0 0 3px rgba(124, 58, 237, 0.1) !important;
}

.form-group input[readonly] {
    background: #f8fafc !important;
    color: #64748b !important;
    cursor: not-allowed !important;
}

.api-credential-field {
    position: relative;
}

.api-credential-field .show-credential-btn {
    background: #64748b !important;
    color: white !important;
    border: none !important;
    padding: 8px 12px !important;
    border-radius: 6px !important;
    cursor: pointer !important;
    font-size: 12px !important;
    transition: all 0.2s ease !important;
}

.api-credential-field .show-credential-btn:hover {
    background: #475569 !important;
    transform: translateY(-1px) !important;
}

.api-credential-field .show-credential-btn:active {
    transform: translateY(0) !important;
}

.security-notice {
    background: #fef3c7 !important;
    border-left: 4px solid #f59e0b !important;
    padding: 12px 16px !important;
    margin: 16px 0 !important;
    border-radius: 4px !important;
    font-size: 13px !important;
    color: #92400e !important;
}

.security-notice strong {
    color: #78350f !important;
}

.form-group .description {
    font-size: 13px !important;
    color: #64748b !important;
    margin: 0 !important;
    line-height: 1.5 !important;
}

.checkbox-group {
    flex-direction: row !important;
    align-items: center !important;
    gap: 12px !important;
}

.checkbox-group input[type="checkbox"] {
    width: auto !important;
    margin: 0 !important;
    transform: scale(1.2) !important;
    accent-color: #7C3AED !important;
}

.checkbox-group label {
    font-weight: 500 !important;
    color: #1e293b !important;
    margin: 0 !important;
    cursor: pointer !important;
}

.form-actions {
    display: flex !important;
    gap: 16px !important;
    flex-wrap: wrap !important;
    margin-top: 32px !important;
    padding-top: 24px !important;
    border-top: 1px solid #f1f5f9 !important;
}

.form-actions .button {
    padding: 12px 20px !important;
    border-radius: 12px !important;
    font-weight: 600 !important;
    font-size: 14px !important;
    transition: all 0.2s ease !important;
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
}

.form-actions .button-primary {
    background: linear-gradient(135deg, #7C3AED, #8B5CF6) !important;
    border: none !important;
    color: white !important;
    box-shadow: 0 4px 6px rgba(124, 58, 237, 0.2) !important;
}

.form-actions .button-primary:hover {
    transform: translateY(-2px) !important;
    box-shadow: 0 8px 15px rgba(124, 58, 237, 0.3) !important;
}

.form-actions .button:not(.button-primary) {
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    color: #475569 !important;
}

.form-actions .button:not(.button-primary):hover {
    background: #7C3AED !important;
    border-color: #7C3AED !important;
    color: white !important;
    transform: translateY(-1px) !important;
}



.webhook-info {
    display: grid !important;
    gap: 20px !important;
    margin-bottom: 24px !important;
}

.webhook-item {
    display: flex !important;
    align-items: center !important;
    gap: 12px !important;
    padding: 16px !important;
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 12px !important;
}

.webhook-item label {
    font-weight: 600 !important;
    color: #475569 !important;
    min-width: 120px !important;
    margin: 0 !important;
}

.webhook-item code {
    background: #e2e8f0 !important;
    padding: 8px 12px !important;
    border-radius: 8px !important;
    font-family: 'SF Mono', 'Monaco', 'Inconsolata', 'Roboto Mono', monospace !important;
    font-size: 13px !important;
    color: #475569 !important;
    flex: 1 !important;
    word-break: break-all !important;
}

.webhook-instructions {
    background: #f0f9ff !important;
    border: 1px solid #bae6fd !important;
    border-radius: 12px !important;
    padding: 20px !important;
}

.webhook-instructions h4 {
    margin: 0 0 16px 0 !important;
    color: #0369a1 !important;
    font-size: 16px !important;
    font-weight: 600 !important;
}

.webhook-instructions ol {
    margin: 0 !important;
    padding-left: 20px !important;
    color: #0c4a6e !important;
}

.webhook-instructions li {
    margin-bottom: 8px !important;
    line-height: 1.5 !important;
}



.wallet-validation-info {
    margin-top: 24px !important;
}

.validation-status {
    background: #f8fafc !important;
    border: 1px solid #e2e8f0 !important;
    border-radius: 12px !important;
    padding: 20px !important;
}

.validation-status.hidden {
    display: none !important;
}

.validation-item {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    padding: 8px 0 !important;
    border-bottom: 1px solid #f1f5f9 !important;
}

.validation-item:last-child {
    border-bottom: none !important;
}

.validation-item .network-name {
    font-weight: 600 !important;
    color: #475569 !important;
    font-size: 14px !important;
}

.validation-item .validation-result {
    font-size: 13px !important;
    font-weight: 500 !important;
    padding: 4px 8px !important;
    border-radius: 6px !important;
    text-transform: uppercase !important;
    letter-spacing: 0.025em !important;
}

.validation-result.valid {
    background: #dcfce7 !important;
    color: #166534 !important;
}

.validation-result.invalid {
    background: #fecaca !important;
    color: #991b1b !important;
}

.validation-result.empty {
    background: #f1f5f9 !important;
    color: #64748b !important;
}

.wallet-input.valid {
    border-color: #10b981 !important;
    box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1) !important;
}

.wallet-input.invalid {
    border-color: #ef4444 !important;
    box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1) !important;
}

.wallet-input:focus.valid {
    border-color: #10b981 !important;
    box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.2) !important;
}

.wallet-input:focus.invalid {
    border-color: #ef4444 !important;
    box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.2) !important;
}

.notice {
    background: white !important;
    border-left: 4px solid #7C3AED !important;
    border-radius: 8px !important;
    margin: 20px 0 !important;
    padding: 16px 20px !important;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05) !important;
}

.notice.notice-success {
    border-left-color: #10b981 !important;
}

.notice.notice-error {
    border-left-color: #ef4444 !important;
}

.important-notice {
    color: #ef4444 !important;
    font-weight: 500 !important;
}

.network-icon {
    display: inline-block !important;
    margin-right: 8px !important;
    font-size: 16px !important;
}

.help-tip {
    display: inline-block !important;
    margin-left: 8px !important;
    color: #64748b !important;
    cursor: help !important;
}

.wallet-input {
    font-family: monospace !important;
    letter-spacing: 0.5px !important;
}

@media (max-width: 768px) {
    .coinleywp-admin {
        padding: 16px !important;
    }
    
    .coinleywp-header {
        padding: 24px !important;
    }
    
    .coinleywp-header h1 {
        font-size: 28px !important;
    }
    
    .coinleywp-header p {
        font-size: 16px !important;
    }
    
    .settings-section {
        padding: 24px !important;
    }
    
    .form-grid {
        grid-template-columns: 1fr !important;
    }
    
    .networks-grid {
        grid-template-columns: 1fr !important;
    }
    
    .form-actions {
        flex-direction: column !important;
    }
    
    .webhook-item {
        flex-direction: column !important;
        align-items: flex-start !important;
    }
    
    .webhook-item label {
        min-width: auto !important;
    }
}
</style>

<div class="wrap coinleywp-admin">
    <div class="coinleywp-header">
        <div class="coinleywp-header-content">
            <h1><?php _e('Coinley Settings', 'coinleywp'); ?></h1>
            <p><?php _e('Configure your Coinley payment gateway settings and preferences', 'coinleywp'); ?></p>
        </div>
    </div>

    <div class="coinleywp-settings-container">
        <!-- API Configuration -->
        <div class="settings-section">
            <div class="section-header">
                <h2><?php _e('API Configuration', 'coinleywp'); ?></h2>
                <p><?php _e('Configure your Coinley API credentials to start accepting payments', 'coinleywp'); ?></p>
                <?php if ($is_configured): ?>
                <div class="security-notice">
                    <strong><?php _e('Security Notice:', 'coinleywp'); ?></strong>
                    <?php _e('API credentials are protected and read-only for security purposes. They are automatically populated during authentication and cannot be edited directly.', 'coinleywp'); ?>
                </div>
                <?php endif; ?>
            </div>

            <form method="post" action="options.php" id="coinleywp-api-form">
                <?php settings_fields('woocommerce_coinleywp_settings'); ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="merchant_email"><?php _e('Merchant Email', 'coinleywp'); ?></label>
                        <input type="email" 
                               id="merchant_email" 
                               name="woocommerce_coinleywp_merchant_email" 
                               value="<?php echo esc_attr($this->gateway_settings['merchant_email'] ?? ''); ?>"
                               required>
                        <p class="description"><?php _e('Enter your Coinley merchant account email', 'coinleywp'); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="merchant_password"><?php _e('Merchant Password', 'coinleywp'); ?></label>
                        <input type="password" 
                               id="merchant_password" 
                               name="woocommerce_coinleywp_merchant_password" 
                               <?php echo esc_attr($is_configured ? '' : 'required'); ?>>
                        <p class="description"><?php _e('Your Coinley merchant account password', 'coinleywp'); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="api_key"><?php _e('API Key', 'coinleywp'); ?></label>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="text" 
                                   id="api_key" 
                                   name="woocommerce_coinleywp_api_key" 
                                   value="<?php 
                                   $api_key = $this->gateway_settings['api_key'] ?? '';
                                   echo esc_attr($api_key ? '••••••••••••••••••••••••••••••••' . substr($api_key, -4) : ''); 
                                   ?>"
                                   readonly
                                   style="flex: 1; background-color: #f8fafc; color: #64748b;">
                            <?php if (!empty($this->gateway_settings['api_key'])): ?>
                            <button type="button" class="button" id="show-api-key" style="margin-left: 8px;">
                                <span class="dashicons dashicons-visibility"></span>
                                <?php _e('Show', 'coinleywp'); ?>
                            </button>
                            <?php endif; ?>
                        </div>
                        <p class="description"><?php _e('Your API key is automatically populated after successful login and is read-only for security purposes', 'coinleywp'); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="api_secret"><?php _e('API Secret', 'coinleywp'); ?></label>
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="text" 
                                   id="api_secret" 
                                   name="woocommerce_coinleywp_api_secret" 
                                   value="<?php 
                                   $api_secret = $this->gateway_settings['api_secret'] ?? '';
                                   echo esc_attr($api_secret ? '••••••••••••••••••••••••••••••••' . substr($api_secret, -4) : ''); 
                                   ?>"
                                   readonly
                                   style="flex: 1; background-color: #f8fafc; color: #64748b;">
                            <?php if (!empty($this->gateway_settings['api_secret'])): ?>
                            <button type="button" class="button" id="show-api-secret" style="margin-left: 8px;">
                                <span class="dashicons dashicons-visibility"></span>
                                <?php _e('Show', 'coinleywp'); ?>
                            </button>
                            <?php endif; ?>
                        </div>
                        <p class="description"><?php _e('Your API secret is automatically populated after successful login and is read-only for security purposes', 'coinleywp'); ?></p>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-yes"></span>
                        <?php _e('Connect to Coinley', 'coinleywp'); ?>
                    </button>
                    <?php if ($is_configured): ?>
                    <button type="button" class="button" id="test-connection">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <?php _e('Test Connection', 'coinleywp'); ?>
                    </button>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <?php if ($is_configured): ?>
        <!-- Payment Settings -->
        <div class="settings-section">
            <div class="section-header">
                <h2><?php _e('Payment Settings', 'coinleywp'); ?></h2>
                <p><?php _e('Configure payment gateway behavior and preferences', 'coinleywp'); ?></p>
            </div>

            <form method="post" id="coinleywp-payment-settings">
                <?php wp_nonce_field('coinleywp_settings_nonce', 'coinleywp_nonce'); ?>
                
                <div class="form-grid">
                    <div class="form-group">
                        <label for="gateway_title"><?php _e('Payment Method Title', 'coinleywp'); ?></label>
                        <input type="text" 
                               id="gateway_title" 
                               name="title" 
                               value="<?php echo esc_attr($this->gateway_settings['title'] ?? 'Pay with Cryptocurrency'); ?>">
                        <p class="description"><?php _e('Title displayed to customers during checkout', 'coinleywp'); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="gateway_description"><?php _e('Payment Method Description', 'coinleywp'); ?></label>
                        <textarea id="gateway_description" 
                                  name="description" 
                                  rows="3"><?php echo esc_textarea($this->gateway_settings['description'] ?? 'Pay securely using cryptocurrency through Coinley.'); ?></textarea>
                        <p class="description"><?php _e('Description shown to customers during checkout', 'coinleywp'); ?></p>
                    </div>

                    <div class="form-group">
                        <label for="payment_timeout"><?php _e('Payment Timeout (seconds)', 'coinleywp'); ?></label>
                        <input type="number" 
                               id="payment_timeout" 
                               name="payment_timeout" 
                               value="<?php echo esc_attr($this->gateway_settings['payment_timeout'] ?? '300'); ?>"
                               min="60" 
                               max="1800" 
                               step="30">
                        <p class="description"><?php _e('Time in seconds before payment modal times out (60-1800 seconds)', 'coinleywp'); ?></p>
                    </div>

                    <div class="form-group checkbox-group">
                        <label>
                            <input type="checkbox" 
                                   name="testmode" 
                                   value="yes" 
                                   <?php checked($this->gateway_settings['testmode'] ?? '', 'yes'); ?>>
                            <?php _e('Enable Test Mode', 'coinleywp'); ?>
                        </label>
                        <p class="description"><?php _e('Place the payment gateway in test mode for development', 'coinleywp'); ?></p>
                    </div>

                    <div class="form-group checkbox-group">
                        <label>
                            <input type="checkbox" 
                                   name="debug" 
                                   value="yes" 
                                   <?php checked($this->gateway_settings['debug'] ?? '', 'yes'); ?>>
                            <?php _e('Enable Debug Logging', 'coinleywp'); ?>
                        </label>
                        <p class="description"><?php _e('Log Coinley events and API requests for troubleshooting', 'coinleywp'); ?></p>
                    </div>
                </div>

                <div class="form-actions">
                    <button type="submit" class="button button-primary">
                        <span class="dashicons dashicons-saved"></span>
                        <?php _e('Save Payment Settings', 'coinleywp'); ?>
                    </button>
                </div>
            </form>
        </div>

        <?php endif; ?>

        <!-- Webhook Configuration -->
        <div class="settings-section">
            <div class="section-header">
                <h2><?php _e('Webhook Configuration', 'coinleywp'); ?></h2>
                <p><?php _e('Configure webhook settings for payment notifications', 'coinleywp'); ?></p>
            </div>

            <div class="webhook-info">
                <div class="webhook-item">
                    <label><?php _e('Webhook URL:', 'coinleywp'); ?></label>
                    <code class="webhook-url"><?php echo esc_url(home_url('/wc-api/coinleywp')); ?></code>
                    <button class="button-link copy-webhook" data-url="<?php echo esc_attr(home_url('/wc-api/coinleywp')); ?>">
                        <span class="dashicons dashicons-admin-page"></span>
                    </button>
                </div>

                <div class="webhook-item">
                    <label><?php _e('Webhook Secret:', 'coinleywp'); ?></label>
                    <code class="webhook-secret" id="webhook-secret-display">
                        <?php 
                        $webhook_secret = $this->gateway_settings['webhook_secret'] ?? 'Not set';
                        if ($webhook_secret !== 'Not set') {
                            echo esc_html('••••••••••••••••••••••••••••••••' . substr($webhook_secret, -4));
                        } else {
                            echo esc_html($webhook_secret);
                        }
                        ?>
                    </code>
                    <button class="button" id="show-webhook-secret" type="button" style="margin-left: 8px;">
                        <span class="dashicons dashicons-visibility"></span>
                        <?php _e('Show', 'coinleywp'); ?>
                    </button>
                    <button class="button" id="regenerate-webhook-secret">
                        <span class="dashicons dashicons-update"></span>
                        <?php _e('Regenerate', 'coinleywp'); ?>
                    </button>
                </div>
            </div>

            <div class="webhook-instructions">
                <h4><?php _e('Setup Instructions:', 'coinleywp'); ?></h4>
                <ol>
                    <li><?php _e('Copy the webhook URL above', 'coinleywp'); ?></li>
                    <li><?php _e('Log in to your Coinley merchant dashboard', 'coinleywp'); ?></li>
                    <li><?php _e('Navigate to Settings > Webhooks', 'coinleywp'); ?></li>
                    <li><?php _e('Add the webhook URL and secret', 'coinleywp'); ?></li>
                    <li><?php _e('Enable webhook notifications for payment events', 'coinleywp'); ?></li>
                </ol>
            </div>
        </div>

        <div class="settings-section">
            <div class="section-header">
                <h2><?php _e('🔐 Wallet Configuration (Read-Only)', 'coinleywp'); ?></h2>
                <p><?php _e('View your configured wallet addresses below. Wallets are managed in your Coinley Dashboard and support ALL available blockchain networks.', 'coinleywp'); ?></p>
                <div class="security-notice" style="background: #dbeafe; border-left-color: #3b82f6; color: #1e3a8a; margin-top: 16px;">
                    <strong><?php _e('📌 Important:', 'coinleywp'); ?></strong>
                    <?php _e('To add, remove, or modify wallet addresses, please use the "Manage Wallets in Coinley Dashboard" button below. Changes will automatically sync to your WooCommerce store.', 'coinleywp'); ?>
                </div>
            </div>
            <div class="form-grid">
                <?php if (!empty($merchant_wallets)): ?>
                    <?php foreach ($merchant_wallets as $wallet): ?>
                        <div class="form-group">
                            <label>
                                <?php if (!empty($wallet['networkLogo'])): ?>
                                    <img src="https://talented-mercy-production.up.railway.app<?php echo esc_attr($wallet['networkLogo']); ?>"
                                         alt="<?php echo esc_attr($wallet['networkName']); ?>"
                                         style="width: 20px; height: 20px; margin-right: 5px; vertical-align: middle;">
                                <?php endif; ?>
                                <?php echo esc_html($wallet['networkName']); ?>
                            </label>
                            <?php if (empty($wallet['walletAddress'])): ?>
                                <input type="text" class="wallet-input" value="" readonly placeholder="No wallet configured" style="background-color: #f9f9f9;" />
                                <p class="description" style="color: #999;">Network Type: <?php echo esc_html($wallet['networkType']); ?> • Not configured</p>
                            <?php else: ?>
                                <div style="display: flex; align-items: center; gap: 5px;">
                                    <input type="text" class="wallet-input" value="<?php echo esc_attr($wallet['walletAddress']); ?>" readonly style="flex: 1;" />
                                    <button type="button" class="button button-small copy-wallet-address" data-address="<?php echo esc_attr($wallet['walletAddress']); ?>" title="Copy address">
                                        <span class="dashicons dashicons-admin-page"></span>
                                    </button>
                                </div>
                                <p class="description">Network Type: <?php echo esc_html($wallet['networkType']); ?> • ✓ Configured</p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No wallet information available. Please check your API credentials.</p>
                <?php endif; ?>
            </div>
            <div class="form-actions">
                <a href="https://coinleymerchant.vercel.app/wallet-addresses" target="_blank" class="button button-primary">
                    <span class="dashicons dashicons-external"></span>
                    Manage Wallets in Coinley Dashboard
                </a>
                <button type="button" class="button" id="refresh-wallets-btn">
                    <span class="dashicons dashicons-update"></span>
                    Refresh Wallets
                </button>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Test connection functionality
    const testConnectionBtn = document.getElementById('test-connection');
    if (testConnectionBtn) {
        testConnectionBtn.addEventListener('click', function() {
            testApiConnection();
        });
    }

    // Copy webhook URL
    const copyWebhookBtn = document.querySelector('.copy-webhook');
    if (copyWebhookBtn) {
        copyWebhookBtn.addEventListener('click', function() {
            const url = this.dataset.url;
            navigator.clipboard.writeText(url).then(function() {
                copyWebhookBtn.innerHTML = '<span class="dashicons dashicons-yes"></span>';
                setTimeout(function() {
                    copyWebhookBtn.innerHTML = '<span class="dashicons dashicons-admin-page"></span>';
                }, 2000);
            });
        });
    }

    // Show/Hide API Key functionality
    const showApiKeyBtn = document.getElementById('show-api-key');
    const apiKeyInput = document.getElementById('api_key');
    let apiKeyVisible = false;
    const originalApiKey = '<?php echo esc_js($this->gateway_settings['api_key'] ?? ''); ?>';
    
    if (showApiKeyBtn && apiKeyInput) {
        showApiKeyBtn.addEventListener('click', function() {
            if (!apiKeyVisible) {
                // Show full API key
                apiKeyInput.value = originalApiKey;
                showApiKeyBtn.innerHTML = '<span class="dashicons dashicons-hidden"></span> <?php _e('Hide', 'coinleywp'); ?>';
                apiKeyVisible = true;
            } else {
                // Hide API key (show masked version)
                apiKeyInput.value = '••••••••••••••••••••••••••••••••' + originalApiKey.slice(-4);
                showApiKeyBtn.innerHTML = '<span class="dashicons dashicons-visibility"></span> <?php _e('Show', 'coinleywp'); ?>';
                apiKeyVisible = false;
            }
        });
    }

    // Show/Hide API Secret functionality
    const showApiSecretBtn = document.getElementById('show-api-secret');
    const apiSecretInput = document.getElementById('api_secret');
    let apiSecretVisible = false;
    const originalApiSecret = '<?php echo esc_js($this->gateway_settings['api_secret'] ?? ''); ?>';
    
    if (showApiSecretBtn && apiSecretInput) {
        showApiSecretBtn.addEventListener('click', function() {
            if (!apiSecretVisible) {
                // Show full API secret
                apiSecretInput.value = originalApiSecret;
                showApiSecretBtn.innerHTML = '<span class="dashicons dashicons-hidden"></span> <?php _e('Hide', 'coinleywp'); ?>';
                apiSecretVisible = true;
            } else {
                // Hide API secret (show masked version)
                apiSecretInput.value = '••••••••••••••••••••••••••••••••' + originalApiSecret.slice(-4);
                showApiSecretBtn.innerHTML = '<span class="dashicons dashicons-visibility"></span> <?php _e('Show', 'coinleywp'); ?>';
                apiSecretVisible = false;
            }
        });
    }

    // Show/Hide webhook secret
    const showWebhookBtn = document.getElementById('show-webhook-secret');
    const webhookSecretDisplay = document.getElementById('webhook-secret-display');
    let webhookSecretVisible = false;
    const originalWebhookSecret = '<?php echo esc_js($this->gateway_settings['webhook_secret'] ?? 'Not set'); ?>';
    
    if (showWebhookBtn && webhookSecretDisplay) {
        showWebhookBtn.addEventListener('click', function() {
            if (!webhookSecretVisible) {
                // Show full secret
                webhookSecretDisplay.textContent = originalWebhookSecret;
                showWebhookBtn.innerHTML = '<span class="dashicons dashicons-hidden"></span> <?php _e('Hide', 'coinleywp'); ?>';
                webhookSecretVisible = true;
            } else {
                // Hide secret (show masked version)
                if (originalWebhookSecret !== 'Not set') {
                    webhookSecretDisplay.textContent = '••••••••••••••••••••••••••••••••' + originalWebhookSecret.slice(-4);
                } else {
                    webhookSecretDisplay.textContent = originalWebhookSecret;
                }
                showWebhookBtn.innerHTML = '<span class="dashicons dashicons-visibility"></span> <?php _e('Show', 'coinleywp'); ?>';
                webhookSecretVisible = false;
            }
        });
    }

    // Regenerate webhook secret with confirmation
    const regenerateBtn = document.getElementById('regenerate-webhook-secret');
    if (regenerateBtn) {
        regenerateBtn.addEventListener('click', function() {
            if (confirm('<?php _e('Are you sure you want to regenerate the webhook secret? You will need to update it in your Coinley dashboard.', 'coinleywp'); ?>')) {
                regenerateWebhookSecret();
            }
        });
    }



    function testApiConnection() {
        testConnectionBtn.disabled = true;
        testConnectionBtn.innerHTML = '<span class="spinner is-active"></span> <?php _e('Testing...', 'coinleywp'); ?>';

        jQuery.post(coinleywp_admin.ajax_url, {
            action: 'coinleywp_test_connection',
            nonce: coinleywp_admin.nonce
        }, function(response) {
            testConnectionBtn.disabled = false;
            testConnectionBtn.innerHTML = '<span class="dashicons dashicons-admin-tools"></span> <?php _e('Test Connection', 'coinleywp'); ?>';
            
            if (response.success) {
                showNotice('success', '<?php _e('API connection successful!', 'coinleywp'); ?>');
            } else {
                showNotice('error', '<?php _e('API connection failed: ', 'coinleywp'); ?>' + response.data);
            }
        });
    }

    function regenerateWebhookSecret() {
        regenerateBtn.disabled = true;
        regenerateBtn.innerHTML = '<span class="spinner is-active"></span> <?php _e('Generating...', 'coinleywp'); ?>';

        jQuery.post(coinleywp_admin.ajax_url, {
            action: 'coinleywp_regenerate_webhook_secret',
            nonce: coinleywp_admin.nonce
        }, function(response) {
            regenerateBtn.disabled = false;
            regenerateBtn.innerHTML = '<span class="dashicons dashicons-update"></span> <?php _e('Regenerate', 'coinleywp'); ?>';
            
            if (response.success) {
                const newSecret = response.data.secret;
                // Update the original secret reference
                originalWebhookSecret = newSecret;
                
                // Update display based on current visibility state
                if (webhookSecretVisible) {
                    webhookSecretDisplay.textContent = newSecret;
                } else {
                    webhookSecretDisplay.textContent = '••••••••••••••••••••••••••••••••' + newSecret.slice(-4);
                }
                
                showNotice('success', '<?php _e('Webhook secret regenerated successfully!', 'coinleywp'); ?>');
            } else {
                showNotice('error', '<?php _e('Failed to regenerate webhook secret', 'coinleywp'); ?>');
            }
        });
    }



    /* 
    // Wallet address management - COMMENTED OUT
    const walletForm = document.getElementById('coinleywp-wallet-form');
    const validateBtn = document.getElementById('validate-addresses');
    const clearBtn = document.getElementById('clear-addresses');
    const walletInputs = document.querySelectorAll('.wallet-input');
    const validationStatus = document.getElementById('wallet-validation');

    // Wallet validation patterns
    const walletPatterns = {
        ethereum: /^0x[a-fA-F0-9]{40}$/,
        bsc: /^0x[a-fA-F0-9]{40}$/,
        tron: /^T[a-zA-Z0-9]{33}$/,
        algorand: /^[A-Z2-7]{58}$/,
        solana: /^[1-9A-HJ-NP-Za-km-z]{32,44}$/
    };

    // Real-time wallet validation
    walletInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            validateWalletAddress(this);
        });

        input.addEventListener('blur', function() {
            validateWalletAddress(this);
        });
    });

    // Wallet form submission
    if (walletForm) {
        walletForm.addEventListener('submit', function(e) {
            e.preventDefault();
            updateWalletAddresses();
        });
    }

    // Validate addresses button
    if (validateBtn) {
        validateBtn.addEventListener('click', function() {
            validateAllAddresses();
        });
    }

    // Clear addresses button
    if (clearBtn) {
        clearBtn.addEventListener('click', function() {
            if (confirm('<?php _e('Are you sure you want to clear all wallet addresses?', 'coinleywp'); ?>')) {
                clearAllAddresses();
            }
        });
    }

    function validateWalletAddress(input) {
        const network = input.dataset.network;
        const address = input.value.trim();
        const pattern = walletPatterns[network];

        // Remove existing validation classes
        input.classList.remove('valid', 'invalid');

        if (address === '') {
            return true; // Empty is valid (optional)
        }

        if (pattern && pattern.test(address)) {
            input.classList.add('valid');
            return true;
        } else {
            input.classList.add('invalid');
            return false;
        }
    }

    function validateAllAddresses() {
        let allValid = true;
        const validationResults = {};

        walletInputs.forEach(function(input) {
            const network = input.dataset.network;
            const address = input.value.trim();
            const isValid = validateWalletAddress(input);
            
            if (address === '') {
                validationResults[network] = 'empty';
            } else {
                validationResults[network] = isValid ? 'valid' : 'invalid';
                if (!isValid) allValid = false;
            }
        });

        updateValidationDisplay(validationResults);
        validationStatus.classList.remove('hidden');

        if (allValid) {
            showNotice('success', '<?php _e('All wallet addresses are valid!', 'coinleywp'); ?>');
        } else {
            showNotice('error', '<?php _e('Some wallet addresses have validation errors. Please check and correct them.', 'coinleywp'); ?>');
        }

        return allValid;
    }

    function updateValidationDisplay(results) {
        Object.keys(results).forEach(function(network) {
            const item = validationStatus.querySelector(`[data-network="${network}"] .validation-result`);
            const status = results[network];
            
            item.className = `validation-result ${status}`;
            
            switch(status) {
                case 'valid':
                    item.textContent = '<?php _e('Valid', 'coinleywp'); ?>';
                    break;
                case 'invalid':
                    item.textContent = '<?php _e('Invalid', 'coinleywp'); ?>';
                    break;
                case 'empty':
                    item.textContent = '<?php _e('Not Set', 'coinleywp'); ?>';
                    break;
            }
        });
    }

    function updateWalletAddresses() {
        // Validate all addresses first
        if (!validateAllAddresses()) {
            showNotice('error', '<?php _e('Please fix validation errors before saving.', 'coinleywp'); ?>');
            return;
        }

        const saveBtn = document.getElementById('save-wallet-addresses');
        const wallets = {};

        // Collect wallet addresses
        walletInputs.forEach(function(input) {
            const network = input.dataset.network;
            const address = input.value.trim();
            if (address !== '') {
                wallets[network] = address;
            }
        });

        if (Object.keys(wallets).length === 0) {
            showNotice('error', '<?php _e('Please enter at least one wallet address.', 'coinleywp'); ?>');
            return;
        }

        saveBtn.disabled = true;
        saveBtn.innerHTML = '<span class="spinner is-active"></span> <?php _e('Updating...', 'coinleywp'); ?>';

        jQuery.post(coinleywp_admin.ajax_url, {
            action: 'coinleywp_update_wallet_addresses',
            nonce: jQuery('#coinleywp_wallet_nonce').val(),
            wallets: JSON.stringify(wallets)
        }, function(response) {
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<span class="dashicons dashicons-saved"></span> <?php _e('Update Wallet Addresses', 'coinleywp'); ?>';
            
            if (response.success) {
                showNotice('success', '<?php _e('Wallet addresses updated successfully!', 'coinleywp'); ?>');
            } else {
                showNotice('error', '<?php _e('Failed to update wallet addresses: ', 'coinleywp'); ?>' + (response.data || 'Unknown error'));
            }
        }).fail(function() {
            saveBtn.disabled = false;
            saveBtn.innerHTML = '<span class="dashicons dashicons-saved"></span> <?php _e('Update Wallet Addresses', 'coinleywp'); ?>';
            showNotice('error', '<?php _e('Network error occurred while updating wallet addresses.', 'coinleywp'); ?>');
        });
    }

    function clearAllAddresses() {
        walletInputs.forEach(function(input) {
            input.value = '';
            input.classList.remove('valid', 'invalid');
        });
        
        validationStatus.classList.add('hidden');
        showNotice('success', '<?php _e('All wallet addresses cleared.', 'coinleywp'); ?>');
    }
    */

    // Copy wallet address functionality for new wallet section
    document.querySelectorAll('.copy-wallet-address').forEach(function(btn) {
        btn.addEventListener('click', function() {
            const address = this.dataset.address;
            const button = this;
            
            // Create temporary input
            const tempInput = document.createElement('input');
            tempInput.value = address;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            
            // Visual feedback
            const originalIcon = button.querySelector('.dashicons');
            const originalText = button.innerHTML;
            button.innerHTML = '<span class="dashicons dashicons-yes"></span>';
            button.style.background = '#46b450';
            button.style.color = '#fff';
            
            setTimeout(function() {
                button.innerHTML = originalText;
                button.style.background = '';
                button.style.color = '';
            }, 2000);
        });
    });
    
    // Refresh wallets functionality for new button
    const refreshWalletsBtn = document.getElementById('refresh-wallets-btn');
    if (refreshWalletsBtn) {
        refreshWalletsBtn.addEventListener('click', function() {
            const button = this;
            button.disabled = true;
            
            const spinner = button.querySelector('.dashicons');
            spinner.classList.add('spin');
            
            jQuery.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'coinleywp_refresh_wallets',
                    nonce: '<?php echo esc_js(wp_create_nonce('coinleywp_refresh_wallets')); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        showNotice('error', 'Failed to refresh wallets: ' + (response.data || 'Unknown error'));
                    }
                },
                error: function() {
                    showNotice('error', 'Failed to refresh wallets. Please try again.');
                },
                complete: function() {
                    spinner.classList.remove('spin');
                    button.disabled = false;
                }
            });
        });
    }

    function showNotice(type, message) {
        const notice = document.createElement('div');
        notice.className = `notice notice-${type} is-dismissible`;
        notice.innerHTML = `<p>${message}</p>`;
        
        const wrap = document.querySelector('.wrap');
        wrap.insertBefore(notice, wrap.firstChild);
        
        setTimeout(function() {
            notice.remove();
        }, 5000);
    }
});
</script> 