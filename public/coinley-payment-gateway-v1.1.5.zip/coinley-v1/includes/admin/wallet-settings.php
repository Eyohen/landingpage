<?php
/**
 * Coinley Wallet Settings Page
 *
 * Allows merchants to configure their wallet addresses for all supported networks
 * without leaving WordPress/WooCommerce
 *
 * @package CoinleyWP
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Get gateway settings for API credentials
$gateway_settings = get_option('woocommerce_coinleywp_settings', array());
$api_url = isset($gateway_settings['api_url']) && !empty($gateway_settings['api_url'])
    ? $gateway_settings['api_url']
    : 'https://hub.coinley.io/api';
$api_key = isset($gateway_settings['api_key']) ? $gateway_settings['api_key'] : '';
$api_secret = isset($gateway_settings['api_secret']) ? $gateway_settings['api_secret'] : '';

// Supported networks configuration
$networks = array(
    'ethereum' => array(
        'name' => 'Ethereum',
        'icon' => '⟠',
        'type' => 'evm',
        'tokens' => array('USDT', 'USDC')
    ),
    'bsc' => array(
        'name' => 'BSC (Binance Smart Chain)',
        'icon' => '⬡',
        'type' => 'evm',
        'tokens' => array('USDT', 'USDC')
    ),
    'polygon' => array(
        'name' => 'Polygon',
        'icon' => '⬢',
        'type' => 'evm',
        'tokens' => array('USDT', 'USDC')
    ),
    'arbitrum' => array(
        'name' => 'Arbitrum',
        'icon' => '◆',
        'type' => 'evm',
        'tokens' => array('USDT', 'USDC')
    ),
    'optimism' => array(
        'name' => 'Optimism',
        'icon' => '🔴',
        'type' => 'evm',
        'tokens' => array('USDT', 'USDC')
    ),
    'avalanche' => array(
        'name' => 'Avalanche',
        'icon' => '❄️',
        'type' => 'evm',
        'tokens' => array('USDT', 'USDC')
    ),
    'celo' => array(
        'name' => 'Celo',
        'icon' => '💚',
        'type' => 'evm',
        'tokens' => array('USDT', 'USDC')
    ),
    'base' => array(
        'name' => 'Base',
        'icon' => '🔵',
        'type' => 'evm',
        'tokens' => array('USDT', 'USDC')
    )
);

// Enqueue styles and scripts
wp_enqueue_style(
    'coinley-wallet-settings',
    plugin_dir_url(dirname(__FILE__)) . '../assets/css/wallet-settings.css',
    array(),
    '1.0.0'
);

wp_enqueue_script(
    'coinley-wallet-settings',
    plugin_dir_url(dirname(__FILE__)) . '../assets/js/wallet-settings.js',
    array('jquery'),
    '1.0.0',
    true
);

// Localize script with API data
wp_localize_script('coinley-wallet-settings', 'coinleyWalletSettings', array(
    'ajax_url' => admin_url('admin-ajax.php'),
    'nonce' => wp_create_nonce('coinley_wallet_settings_nonce'),
    'api_url' => $api_url,
    'api_key' => $api_key,
    'api_secret' => $api_secret,
    'networks' => $networks
));
?>

<div class="wrap coinley-settings-wrap">
    <h1><?php echo esc_html__('Coinley Wallet Settings', 'coinleywp'); ?></h1>

    <div class="coinley-settings-notice"></div>

    <div class="coinley-settings-container">
        <div class="coinley-settings-header">
            <h2><?php echo esc_html__('Receive Wallet Addresses', 'coinleywp'); ?></h2>
            <p class="description">
                <?php echo esc_html__('Configure the wallet addresses where you want to receive cryptocurrency payments on each network.', 'coinleywp'); ?>
            </p>
        </div>

        <div id="coinley-loading" class="coinley-loading">
            <div class="coinley-spinner"></div>
            <p><?php echo esc_html__('Loading wallet addresses...', 'coinleywp'); ?></p>
        </div>

        <form id="coinley-wallets-form" class="coinley-wallets-form" style="display: none;">
            <div class="coinley-wallets-grid">
                <?php foreach ($networks as $network_key => $network): ?>
                    <div class="coinley-wallet-card" data-network="<?php echo esc_attr($network_key); ?>">
                        <div class="coinley-wallet-header">
                            <span class="coinley-network-icon"><?php echo esc_html($network['icon']); ?></span>
                            <div class="coinley-network-info">
                                <h3><?php echo esc_html($network['name']); ?></h3>
                                <span class="coinley-network-type"><?php echo esc_html(strtoupper($network['type'])); ?></span>
                            </div>
                        </div>

                        <div class="coinley-wallet-body">
                            <label for="wallet_<?php echo esc_attr($network_key); ?>">
                                <?php echo esc_html__('Wallet Address', 'coinleywp'); ?>
                                <span class="required">*</span>
                            </label>

                            <input
                                type="text"
                                id="wallet_<?php echo esc_attr($network_key); ?>"
                                name="wallets[<?php echo esc_attr($network_key); ?>]"
                                class="coinley-wallet-input"
                                placeholder="<?php echo esc_attr($network['type'] === 'evm' ? '0x...' : 'Enter wallet address'); ?>"
                                data-network-type="<?php echo esc_attr($network['type']); ?>"
                            />

                            <span class="coinley-validation-message"></span>

                            <div class="coinley-supported-tokens">
                                <strong><?php echo esc_html__('Supported Tokens:', 'coinleywp'); ?></strong>
                                <span><?php echo esc_html(implode(', ', $network['tokens'])); ?></span>
                            </div>
                        </div>

                        <div class="coinley-wallet-status">
                            <span class="status-icon"></span>
                            <span class="status-text"><?php echo esc_html__('Not configured', 'coinleywp'); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="coinley-form-actions">
                <button type="submit" class="button button-primary button-large" id="coinley-save-wallets">
                    <span class="dashicons dashicons-saved"></span>
                    <?php echo esc_html__('Save All Wallet Addresses', 'coinleywp'); ?>
                </button>

                <button type="button" class="button button-secondary" id="coinley-validate-all">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <?php echo esc_html__('Validate All Addresses', 'coinleywp'); ?>
                </button>
            </div>
        </form>

        <div class="coinley-settings-info">
            <h3><?php echo esc_html__('Important Information', 'coinleywp'); ?></h3>
            <ul>
                <li><?php echo esc_html__('⚠️ Double-check wallet addresses before saving. Incorrect addresses may result in permanent loss of funds.', 'coinleywp'); ?></li>
                <li><?php echo esc_html__('✅ All addresses are validated for correct format before saving.', 'coinleywp'); ?></li>
                <li><?php echo esc_html__('🔒 You must configure at least one network to accept crypto payments.', 'coinleywp'); ?></li>
                <li><?php echo esc_html__('💡 The same wallet address can be used across multiple EVM-compatible networks.', 'coinleywp'); ?></li>
                <li><?php echo esc_html__('⚡ Settings are synced with Coinley servers automatically.', 'coinleywp'); ?></li>
            </ul>
        </div>
    </div>
</div>
