<?php
/**
 * Coinley WP Order Confirmation
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/coinley/order-confirmation.php.
 *
 * @package CoinleyWP
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

defined( 'ABSPATH' ) || exit;

// Get order data
$order_id = $order->get_id();
$payment_id = $order->get_meta( '_coinley_payment_id' );
$customer_name = $order->get_billing_first_name();
$total = $order->get_formatted_order_total();
$currency = $order->get_currency();
$date = $order->get_date_created()->date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ) );
$payment_method = $order->get_payment_method_title();

// Get additional Coinley payment details
$transaction_hash = $order->get_meta('_coinleywp_transaction_hash');
$payment_pending = $order->get_meta('_coinleywp_payment_pending');
?>

<div class="coinley-order-confirmation">
    <div class="coinley-confirmation-header">
        <img src="<?php echo esc_url(COINLEYWP_PLUGIN_URL . 'assets/images/coinley-logo.svg'); ?>" alt="Coinley" class="coinley-logo">
        
        <?php if ($payment_pending) : ?>
            <div class="coinley-payment-pending-notice">
                <h2><?php esc_html_e('Payment Pending', 'coinleywp'); ?></h2>
                <p><?php esc_html_e('Your order has been received, but the payment is still pending. Please complete your payment to process your order.', 'coinleywp'); ?></p>
                <p><button class="coinley-order-pay-button button"><?php esc_html_e('Complete Payment', 'coinleywp'); ?></button></p>
            </div>
        <?php else : ?>
            <div class="coinley-payment-complete-notice">
                <h2><?php esc_html_e('Payment Complete', 'coinleywp'); ?></h2>
                <p><?php esc_html_e('Thank you for your payment. Your transaction has been completed successfully.', 'coinleywp'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="coinley-order-details">
        <h3><?php esc_html_e('Order Details', 'coinleywp'); ?></h3>
        
        <div class="coinley-order-info-grid">
            <div class="coinley-order-info-item">
                <span class="coinley-label"><?php esc_html_e('Order Number', 'coinleywp'); ?>:</span>
                <span class="coinley-value"><?php echo esc_html($order->get_order_number()); ?></span>
            </div>
            
            <div class="coinley-order-info-item">
                <span class="coinley-label"><?php esc_html_e('Date', 'coinleywp'); ?>:</span>
                <span class="coinley-value"><?php echo esc_html(wc_format_datetime($order->get_date_created())); ?></span>
            </div>
            
            <div class="coinley-order-info-item">
                <span class="coinley-label"><?php esc_html_e('Total', 'coinleywp'); ?>:</span>
                <span class="coinley-value"><?php echo wp_kses_post($order->get_formatted_order_total()); ?></span>
            </div>
            
            <div class="coinley-order-info-item">
                <span class="coinley-label"><?php esc_html_e('Payment Method', 'coinleywp'); ?>:</span>
                <span class="coinley-value"><?php esc_html_e('Cryptocurrency (Coinley)', 'coinleywp'); ?></span>
            </div>
            
            <?php if ($currency) : ?>
                <div class="coinley-order-info-item">
                    <span class="coinley-label"><?php esc_html_e('Cryptocurrency', 'coinleywp'); ?>:</span>
                    <span class="coinley-value"><?php echo esc_html($currency); ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($payment_id && !$payment_pending) : ?>
                <div class="coinley-order-info-item">
                    <span class="coinley-label"><?php esc_html_e('Payment ID', 'coinleywp'); ?>:</span>
                    <span class="coinley-value"><?php echo esc_html($payment_id); ?></span>
                </div>
            <?php endif; ?>
            
            <?php if ($transaction_hash && !$payment_pending) : ?>
                <div class="coinley-order-info-item coinley-transaction-hash">
                    <span class="coinley-label"><?php esc_html_e('Transaction Hash', 'coinleywp'); ?>:</span>
                    <div class="coinley-hash-wrapper">
                        <span class="coinley-value"><?php echo esc_html($transaction_hash); ?></span>
                        <button type="button" class="coinley-btn-copy" data-clipboard-text="<?php echo esc_attr($transaction_hash); ?>">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M13.3333 6H7.33333C6.59695 6 6 6.59695 6 7.33333V13.3333C6 14.0697 6.59695 14.6667 7.33333 14.6667H13.3333C14.0697 14.6667 14.6667 14.0697 14.6667 13.3333V7.33333C14.6667 6.59695 14.0697 6 13.3333 6Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M3.33366 10.0001H2.66699C2.31337 10.0001 1.97423 9.8597 1.72418 9.60965C1.47413 9.35961 1.33366 9.02047 1.33366 8.66683V2.66683C1.33366 2.3132 1.47413 1.97407 1.72418 1.72402C1.97423 1.47397 2.31337 1.3335 2.66699 1.3335H8.66699C9.02062 1.3335 9.35975 1.47397 9.6098 1.72402C9.85985 1.97407 10.0003 2.3132 10.0003 2.66683V3.3335" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <?php if (!$payment_pending) : ?>
        <div class="coinley-next-steps">
            <h3><?php esc_html_e('Next Steps', 'coinleywp'); ?></h3>
            <ul class="coinley-steps-list">
                <li>
                    <div class="coinley-step-icon">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M16.6667 5L7.5 14.1667L3.33337 10" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <div class="coinley-step-content">
                        <h4><?php esc_html_e('Order Processing', 'coinleywp'); ?></h4>
                        <p><?php esc_html_e('Your order is now being processed.', 'coinleywp'); ?></p>
                    </div>
                </li>
                <li>
                    <div class="coinley-step-icon">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10 1.66663V18.3333M10 1.66663L5 6.66663M10 1.66663L15 6.66663" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <div class="coinley-step-content">
                        <h4><?php esc_html_e('Shipping & Fulfillment', 'coinleywp'); ?></h4>
                        <p><?php esc_html_e('You will receive an email when your order ships.', 'coinleywp'); ?></p>
                    </div>
                </li>
                <li>
                    <div class="coinley-step-icon">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9.99999 18.3333C14.6024 18.3333 18.3333 14.6024 18.3333 10C18.3333 5.39763 14.6024 1.66667 9.99999 1.66667C5.39762 1.66667 1.66666 5.39763 1.66666 10C1.66666 14.6024 5.39762 18.3333 9.99999 18.3333Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M10 5V10L13.3333 11.6667" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </div>
                    <div class="coinley-step-content">
                        <h4><?php esc_html_e('Delivery', 'coinleywp'); ?></h4>
                        <p><?php esc_html_e('Your items will be delivered according to the shipping method selected.', 'coinleywp'); ?></p>
                    </div>
                </li>
            </ul>
        </div>
    <?php endif; ?>
    
    <div class="coinley-confirmation-footer">
        <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>" class="coinley-btn-secondary"><?php esc_html_e('Continue Shopping', 'coinleywp'); ?></a>
        <a href="<?php echo esc_url(wc_get_account_endpoint_url('orders')); ?>" class="coinley-btn-primary"><?php esc_html_e('View Your Orders', 'coinleywp'); ?></a>
    </div>
</div>

<style>
    .coinley-order-confirmation {
        max-width: 800px;
        margin: 0 auto;
        padding: 30px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    
    .coinley-confirmation-header {
        text-align: center;
        margin-bottom: 30px;
    }
    
    .coinley-logo {
        max-width: 180px;
        margin-bottom: 20px;
    }
    
    .coinley-payment-complete-notice h2,
    .coinley-payment-pending-notice h2 {
        font-size: 24px;
        margin-bottom: 15px;
    }
    
    .coinley-payment-pending-notice {
        background-color: #fff9e6;
        border: 1px solid #f0e0a2;
        border-radius: 6px;
        padding: 15px;
        margin-bottom: 20px;
    }
    
    .coinley-payment-complete-notice {
        background-color: #edfdf5;
        border: 1px solid #a2e0c3;
        border-radius: 6px;
        padding: 15px;
        margin-bottom: 20px;
    }
    
    .coinley-order-details h3,
    .coinley-next-steps h3 {
        font-size: 18px;
        margin-bottom: 15px;
        padding-bottom: 10px;
        border-bottom: 1px solid #e5e7eb;
    }
    
    .coinley-order-info-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 15px;
        margin-bottom: 30px;
    }
    
    .coinley-order-info-item {
        display: flex;
        flex-direction: column;
    }
    
    .coinley-transaction-hash {
        grid-column: span 2;
    }
    
    .coinley-label {
        font-weight: 600;
        margin-bottom: 5px;
        color: #6b7280;
    }
    
    .coinley-value {
        font-size: 16px;
        word-break: break-all;
    }
    
    .coinley-hash-wrapper {
        display: flex;
        align-items: center;
        word-break: break-all;
    }
    
    .coinley-hash-wrapper .coinley-value {
        flex-grow: 1;
        font-family: monospace;
        font-size: 14px;
    }
    
    .coinley-btn-copy {
        background: none;
        border: none;
        color: #6b7280;
        cursor: pointer;
        padding: 4px;
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-left: 8px;
    }
    
    .coinley-btn-copy:hover {
        background-color: #e5e7eb;
    }
    
    .coinley-steps-list {
        list-style: none;
        padding: 0;
        margin: 0 0 30px 0;
    }
    
    .coinley-steps-list li {
        display: flex;
        margin-bottom: 20px;
    }
    
    .coinley-steps-list li:last-child {
        margin-bottom: 0;
    }
    
    .coinley-step-icon {
        background-color: #edf2ff;
        color: #2563eb;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 15px;
        flex-shrink: 0;
    }
    
    .coinley-step-content {
        flex-grow: 1;
    }
    
    .coinley-step-content h4 {
        font-size: 16px;
        margin: 0 0 5px 0;
    }
    
    .coinley-step-content p {
        margin: 0;
        color: #6b7280;
    }
    
    .coinley-confirmation-footer {
        display: flex;
        justify-content: flex-end;
        gap: 15px;
        margin-top: 30px;
    }
    
    .coinley-btn-primary,
    .coinley-btn-secondary {
        display: inline-block;
        padding: 10px 20px;
        border-radius: 6px;
        font-weight: 500;
        text-decoration: none;
        text-align: center;
    }
    
    .coinley-btn-primary {
        background-color: #2563eb;
        color: #fff;
        border: 1px solid #2563eb;
    }
    
    .coinley-btn-primary:hover {
        background-color: #1d4ed8;
        color: #fff;
    }
    
    .coinley-btn-secondary {
        background-color: #fff;
        color: #111827;
        border: 1px solid #e5e7eb;
    }
    
    .coinley-btn-secondary:hover {
        background-color: #f9fafb;
        color: #111827;
    }
    
    @media (max-width: 640px) {
        .coinley-order-confirmation {
            padding: 20px;
        }
        
        .coinley-order-info-grid {
            grid-template-columns: 1fr;
        }
        
        .coinley-transaction-hash {
            grid-column: span 1;
        }
        
        .coinley-confirmation-footer {
            flex-direction: column;
        }
        
        .coinley-btn-primary,
        .coinley-btn-secondary {
            width: 100%;
        }
    }
</style>

<script>
    jQuery(document).ready(function($) {
        // Initialize ClipboardJS for copy buttons
        if (typeof ClipboardJS !== 'undefined') {
            new ClipboardJS('.coinley-btn-copy');
        }
        
        // Trigger payment modal if payment is pending
        $('.coinley-order-pay-button').on('click', function(e) {
            e.preventDefault();
            $('#coinley-payment-modal').show();
            $('body').addClass('coinley-modal-open');
            return false;
        });
    });
</script> 
</style> 