<?php
/**
 * Coinley Payment Modal Template - Refactored for CoinleyVanilla SDK
 *
 * This template now uses the CoinleyVanilla SDK for simplified payment processing.
 * The SDK is loaded in the gateway class payment_scripts method.
 *
 * @package CoinleyWP
 */

defined('ABSPATH') || exit;
?>

<!-- Simplified modal for CoinleyVanilla SDK integration -->
<div id="coinley-payment-modal" class="coinley-modal" style="display: none;">
    <div class="coinley-modal-overlay"></div>
    <div class="coinley-modal-container">
        <div class="coinley-modal-header">
            <img src="<?php echo esc_url(COINLEYWP_PLUGIN_URL . 'assets/images/coinley-logo.svg'); ?>" alt="Coinley" class="coinley-logo">
            <button type="button" class="coinley-modal-close" aria-label="<?php esc_attr_e('Close', 'coinleywp'); ?>">×</button>
        </div>
        
        <!-- Simplified content - CoinleyVanilla SDK handles the payment UI -->
        <div class="coinley-modal-content">
            <h2><?php esc_html_e('Processing Payment', 'coinleywp'); ?></h2>
            <p><?php esc_html_e('Please wait while we initialize the payment system...', 'coinleywp'); ?></p>
        </div>

        <!-- Loading Overlay -->
        <div class="coinley-loading-overlay" style="display: none;">
            <div class="coinley-spinner"></div>
            <p class="coinley-loading-text"><?php esc_html_e('Initializing payment...', 'coinleywp'); ?></p>
        </div>
    </div>
</div>

<!-- Note: The CoinleyVanilla SDK will handle all payment UI and modals -->
<script>
// Ensure CoinleyVanilla SDK is loaded before our payment modal script
document.addEventListener('DOMContentLoaded', function() {
    if (typeof CoinleyVanilla === 'undefined') {
        console.warn('⚠️ CoinleyVanilla SDK not loaded. Payment functionality may not work.');
    }
});
</script><?php

// Remove all the old complex modal steps since CoinleyVanilla SDK handles this
// The old template had steps for: select, wallet, confirm, success
// These are now handled by the CoinleyVanilla SDK's built-in modal
?>