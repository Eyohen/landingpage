<?php
/**
 * Template Loader for Coinley WP
 *
 * @class       CoinleyWP_Template_Loader
 * @version     1.0.0
 * @package     CoinleyWP
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Template loader class.
 */
class CoinleyWP_Template_Loader {

    /**
     * Prefix for filter names.
     *
     * @var string
     */
    private $filter_prefix = 'coinleywp';

    /**
     * Directory name where templates are stored.
     *
     * @var string
     */
    private $template_directory = 'coinley';

    /**
     * Get template.
     *
     * Search for the template and include it.
     *
     * @param string $template_name Template name.
     * @param array  $args          Args passed to template.
     * @param string $template_path Template path (default: '').
     * @param string $default_path  Default path (default: '').
     */
    public function get_template( $template_name, $args = array(), $template_path = '', $default_path = '' ) {
        if ( ! empty( $args ) && is_array( $args ) ) {
            extract( $args );
        }

        $located = $this->locate_template( $template_name, $template_path, $default_path );

        if ( ! file_exists( $located ) ) {
            /* translators: %s template */
            _doing_it_wrong( __FUNCTION__, sprintf( __( '%s does not exist.', 'coinleywp' ), '<code>' . $located . '</code>' ), '1.0.0' );
            return;
        }

        // Allow 3rd party plugin filter template file from their plugin.
        $located = apply_filters( $this->filter_prefix . '_get_template', $located, $template_name, $args, $template_path, $default_path );

        if ( $located ) {
            do_action( $this->filter_prefix . '_before_template_part', $template_name, $template_path, $located, $args );
            include $located;
            do_action( $this->filter_prefix . '_after_template_part', $template_name, $template_path, $located, $args );
        }
    }

    /**
     * Locate template.
     *
     * @param string $template_name Template name.
     * @param string $template_path Template path (default: '').
     * @param string $default_path  Default path (default: '').
     * @return string
     */
    public function locate_template( $template_name, $template_path = '', $default_path = '' ) {
        if ( ! $template_path ) {
            $template_path = $this->template_directory;
        }

        if ( ! $default_path ) {
            $default_path = COINLEYWP_PLUGIN_DIR . 'includes/templates/';
        }

        // Look within passed path within the theme - this is priority.
        $template = locate_template(
            array(
                trailingslashit( $template_path ) . $template_name,
                $template_name,
            )
        );

        // Get default template.
        if ( ! $template ) {
            $template = trailingslashit( $default_path ) . $template_name;
        }

        // Return what we found.
        return apply_filters( $this->filter_prefix . '_locate_template', $template, $template_name, $template_path );
    }
} 