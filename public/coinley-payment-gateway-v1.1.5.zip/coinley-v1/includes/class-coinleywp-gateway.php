<?php
/**
 * Coinley Payment Gateway.
 *
 * Provides a Cryptocurrency Payment Gateway for WooCommerce.
 *
 * @class       CoinleyWP_Gateway
 * @extends     WC_Payment_Gateway
 * @version     1.0.0
 * @package     CoinleyWP
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * CoinleyWP_Gateway Class.
 */
class CoinleyWP_Gateway extends WC_Payment_Gateway {

    /**
     * Test mode flag
     *
     * @var bool
     */
    protected $testmode;

    /**
     * API key
     *
     * @var string
     */
    protected $api_key;

    /**
     * API secret
     *
     * @var string
     */
    protected $api_secret;

    /**
     * Debug mode flag
     *
     * @var bool
     */
    protected $debug;

    /**
     * Show currency selector flag
     *
     * @var bool
     */
    protected $show_currency_selector;

    /**
     * API instance
     *
     * @var CoinleyWP_API
     */
    protected $api;

    /**
     * Payment timeout in seconds
     *
     * @var string
     */
    protected $payment_timeout;

    /**
     * Ethereum wallet address
     *
     * @var string
     */
    protected $ethereum_wallet;

    /**
     * BSC wallet address
     *
     * @var string
     */
    protected $bsc_wallet;

    /**
     * Polygon wallet address
     *
     * @var string
     */
    protected $polygon_wallet;

    /**
     * Solana wallet address
     *
     * @var string
     */
    protected $solana_wallet;

    /**
     * TRON wallet address
     *
     * @var string
     */
    protected $tron_wallet;

    /**
     * Algorand wallet address
     *
     * @var string
     */
    protected $algorand_wallet;

    /**
     * Fee charged to (customer or merchant)
     *
     * @var string
     */
    protected $fee_charged_to;

    /**
     * Current fee percentage
     *
     * @var float
     */
    protected $current_fee_percentage;

    /**
     * Constructor for the gateway.
     */
    public function __construct() {
        $this->id                 = 'coinleywp';
        $this->icon              = $this->get_icon_url();
        $this->has_fields        = true;
        $this->method_title      = __('Coinley', 'coinleywp');
        $this->method_description = __('Accept cryptocurrency payments through Coinley.', 'coinleywp');
        $this->supports          = array(
            'products',
            'refunds',
        );

        // Load the settings
        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables
        $this->title        = $this->get_option('title');
        $this->description  = $this->get_option('description');
        $this->enabled      = $this->get_option('enabled');
        $this->testmode     = 'yes' === $this->get_option('testmode');
        $this->debug        = 'yes' === $this->get_option('debug');
        $this->api_key      = $this->get_option('api_key');
        $this->api_secret   = $this->get_option('api_secret');
        $this->payment_timeout = $this->get_option('payment_timeout', '300'); // Default 5 minutes
        
        // Wallet addresses
        $this->ethereum_wallet = $this->get_option('ethereum_wallet');
        $this->bsc_wallet = $this->get_option('bsc_wallet');
        $this->polygon_wallet = $this->get_option('polygon_wallet');
        $this->solana_wallet = $this->get_option('solana_wallet');
        $this->tron_wallet = $this->get_option('tron_wallet');
        $this->algorand_wallet = $this->get_option('algorand_wallet');
        
        // Fee configuration
        $this->fee_charged_to = $this->get_option('fee_charged_to', 'customer');
        $this->current_fee_percentage = floatval($this->get_option('current_fee_percentage', 0.0175));

        // Initialize API if the class exists
        if (class_exists('CoinleyWP_API')) {
            $this->api = new CoinleyWP_API($this->api_key, $this->api_secret, $this->testmode, $this->debug);
        } else {
            // Include the API class if not already included
            require_once COINLEYWP_PLUGIN_DIR . 'includes/class-coinleywp-api.php';
            $this->api = new CoinleyWP_API($this->api_key, $this->api_secret, $this->testmode, $this->debug);
        }

        // Fetch fee settings from API if credentials are set
        if ($this->api_key && $this->api_secret) {
            $this->refresh_fee_settings();
        }
        
        // Debug current fee value
        if ($this->debug) {
            error_log('CoinleyWP: Current fee percentage: ' . $this->current_fee_percentage);
        }

        // Actions
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_api_coinleywp', array($this, 'webhook_handler'));
        add_action('wp_enqueue_scripts', array($this, 'payment_scripts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        add_action('admin_init', array($this, 'maybe_refresh_fee_settings'));
        
        // Payment description filter
        add_filter('woocommerce_gateway_description', array($this, 'enhance_payment_description'), 10, 2);
        
        // Save cryptocurrency preference
        add_action('woocommerce_checkout_update_order_meta', array($this, 'save_preferred_cryptocurrency'));
        
        // AJAX action for order updates after payment
        add_action('wp_ajax_coinleywp_update_order', array($this, 'update_order_after_payment'));
        add_action('wp_ajax_nopriv_coinleywp_update_order', array($this, 'update_order_after_payment'));
        
        // Removed old wallet connection AJAX actions - now using CoinleyVanilla SDK
        
        // AJAX action for testing currency conversion
        add_action('wp_ajax_coinleywp_test_conversion', array($this, 'test_currency_conversion'));
        
        // Removed old Coinley API AJAX actions - now using CoinleyVanilla SDK
    }
    
    /**
     * Display payment fields on checkout.
     */
    public function payment_fields() {
        // Show description only, no form fields (DePay style)
        if ($this->description) {
            echo wpautop(wp_kses_post($this->description));
        }

        if ($this->testmode) {
            echo '<div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 10px; margin: 10px 0; border-radius: 4px; color: #856404;">';
            echo '<strong>' . __('TEST MODE ENABLED', 'coinleywp') . '</strong> - ' . __('Use test cryptocurrencies only', 'coinleywp');
            echo '</div>';
        }
    }
    
    /**
     * Get a list of available cryptocurrencies.
     *
     * @return array
     */
    private function get_available_cryptocurrencies() {
        // In a real implementation, this would be fetched from the API
        return array(
            'btc'  => __( 'Bitcoin (BTC)', 'coinleywp' ),
            'eth'  => __( 'Ethereum (ETH)', 'coinleywp' ),
            'usdt' => __( 'Tether (USDT)', 'coinleywp' ),
            'usdc' => __( 'USD Coin (USDC)', 'coinleywp' ),
            'bnb'  => __( 'Binance Coin (BNB)', 'coinleywp' ),
            'xrp'  => __( 'Ripple (XRP)', 'coinleywp' ),
            'sol'  => __( 'Solana (SOL)', 'coinleywp' ),
            'ada'  => __( 'Cardano (ADA)', 'coinleywp' ),
            'doge' => __( 'Dogecoin (DOGE)', 'coinleywp' ),
        );
    }
    
    /**
     * Save preferred cryptocurrency to order meta.
     *
     * @param int $order_id Order ID.
     */
    public function save_preferred_cryptocurrency( $order_id ) {
        if ( isset( $_POST['coinleywp_preferred_crypto'] ) && ! empty( $_POST['coinleywp_preferred_crypto'] ) ) {
            $crypto = sanitize_text_field( $_POST['coinleywp_preferred_crypto'] );
            update_post_meta( $order_id, '_coinley_preferred_crypto', $crypto );
        }
    }
    
    /**
     * Get the payment icon URL.
     * 
     * @return string
     */
    private function get_icon_url() {
        $svg_logo = COINLEYWP_PLUGIN_URL . 'assets/images/coinley-logo.svg';
        $png_icon = COINLEYWP_PLUGIN_URL . 'assets/images/coinley-icon.png';
        
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
        
        // If it's an older IE browser, use PNG
        if (preg_match('/MSIE\s[1-8]\./', $user_agent)) {
            return apply_filters('coinleywp_icon', $png_icon);
        }
        
        // For all other browsers, use SVG logo
        return apply_filters('coinleywp_icon', $svg_logo);
    }
    
    /**
     * Enqueue payment scripts.
     */
    public function payment_scripts() {
        if ( ! is_checkout() || 'no' === $this->enabled ) {
            return;
        }
        
        wp_enqueue_style( 'coinleywp-checkout-styles', COINLEYWP_PLUGIN_URL . 'assets/css/checkout.css', array(), COINLEYWP_VERSION );
        
        // Removed old wallet connect CSS - CoinleyVanilla SDK provides its own styles

        // Removed Solana Web3 library - CoinleyVanilla SDK handles all blockchain interactions
        
        // Enqueue CoinleyVanilla SDK from CDN (production)
        // Primary: jsdelivr CDN
        wp_enqueue_script(
            'coinley-vanilla-sdk',
            'https://cdn.jsdelivr.net/npm/coinley-test@latest/dist/vanilla/coinley-vanilla.umd.js',
            array(),
            COINLEYWP_VERSION,
            true
        );

        // Add fallback script inline in case CDN fails
        add_action('wp_footer', function() {
            ?>
            <script>
            // Fallback: Load from unpkg if jsdelivr fails
            if (typeof CoinleyVanilla === 'undefined') {
                console.warn('⚠️ CoinleyVanilla SDK not loaded from jsdelivr, trying unpkg fallback...');
                var script = document.createElement('script');
                script.src = 'https://unpkg.com/coinley-test@latest/dist/vanilla/coinley-vanilla.umd.js';
                script.async = false;
                document.head.appendChild(script);
            }
            </script>
            <?php
        }, 5);

        // Enqueue Bricolage Grotesque font (required for SDK modal)
        wp_enqueue_style(
            'coinley-bricolage-font',
            'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,200..800&display=swap',
            array(),
            null
        );

        // Enqueue CoinleyVanilla SDK styles
        wp_enqueue_style(
            'coinley-vanilla-styles',
            'https://cdn.jsdelivr.net/npm/coinley-test@latest/dist/vanilla/style.css',
            array('coinley-bricolage-font'),
            COINLEYWP_VERSION
        );

        // Enqueue refactored payment modal script for CoinleyVanilla SDK integration (high priority)
        wp_enqueue_script(
            'coinleywp-payment-modal',
            COINLEYWP_PLUGIN_URL . 'assets/js/payment-modal.js',
            array('jquery', 'coinley-vanilla-sdk'),
            COINLEYWP_VERSION,
            true
        );
        
        // Old wallet connect script removed - using CoinleyVanilla SDK
        
        // Prepare payment data with currency conversion
        $payment_data = array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('coinleywp_nonce'),
            'checkout_url' => wc_get_checkout_url(),
            'use_react_modals' => false,
            'site_name' => get_bloginfo('name'),
            'site_url' => get_site_url(),
            'merchant_wallets' => $this->get_merchant_wallets(),
            'fee_charged_to' => $this->fee_charged_to,
            'current_fee_percentage' => $this->current_fee_percentage,
            'payment_timeout' => $this->payment_timeout * 1000 // Convert seconds to milliseconds for JavaScript
        );

        // Add currency conversion info if on checkout page and cart exists
        if (WC()->cart && !WC()->cart->is_empty()) {
            $cart_total = WC()->cart->get_total('');
            $currency = get_woocommerce_currency();
            
            // Convert cart total if not USD
            if ($currency !== 'USD') {
                $conversion_result = $this->convert_to_usd($cart_total, $currency);
                
                if (!is_wp_error($conversion_result)) {
                    $payment_data['currency_conversion'] = array(
                        'original_amount' => $conversion_result['original_amount'],
                        'original_currency' => $conversion_result['original_currency'],
                        'converted_amount' => $conversion_result['converted_amount'],
                        'converted_currency' => $conversion_result['converted_currency'],
                        'exchange_rate' => $conversion_result['exchange_rate'],
                        'conversion_info' => $conversion_result['conversion_info']
                    );
                    
                    // Log the conversion for debugging
                    error_log('CoinleyWP Frontend Conversion: ' . $conversion_result['conversion_info']);
                }
            }
        }

        // Removed old wallet connect localization - no longer needed with CoinleyVanilla SDK

        // Prepare CoinleyVanilla SDK configuration for payment modal
        // Uses merchant's configured API credentials from settings
        $coinley_params = array(
            // Coinley API credentials from plugin settings
            'apiKey' => $this->api_key,
            'apiSecret' => $this->api_secret,
            'apiUrl' => 'https://talented-mercy-production.up.railway.app',  // Production API endpoint (SDK adds /api/ automatically)

            // WordPress-specific parameters
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('coinleywp_nonce'),
            'merchantName' => get_bloginfo('name'),
            'merchantWallets' => $this->get_merchant_wallets(),  // Network-specific wallets from backend
            'callbackUrl' => home_url('/wp-json/coinleywp/v1/webhook'),
            'debug' => $this->debug,  // Use debug setting from admin
        );

        // Add order-specific data if on checkout
        if (is_checkout() && WC()->cart && !WC()->cart->is_empty()) {
            $cart_total = WC()->cart->get_total('edit');
            $currency = get_woocommerce_currency();
            
            // Convert to USD if needed
            if ($currency !== 'USD') {
                $conversion_result = $this->convert_to_usd($cart_total, $currency);
                if (!is_wp_error($conversion_result)) {
                    $coinley_params['total'] = $conversion_result['converted_amount'];
                    $coinley_params['currency'] = 'USD';
                } else {
                    $coinley_params['total'] = $cart_total;
                    $coinley_params['currency'] = $currency;
                }
            } else {
                $coinley_params['total'] = $cart_total;
                $coinley_params['currency'] = $currency;
            }
            
            $coinley_params['orderReceivedUrl'] = $this->get_return_url(wc_get_order());
        }

        wp_localize_script('coinleywp-payment-modal', 'coinleyParams', $coinley_params);
    }

    /**
     * Enqueue admin scripts for gateway settings
     */
    public function admin_enqueue_scripts($hook) {
        // Only load on gateway settings page
        if ($hook === 'woocommerce_page_wc-settings' && isset($_GET['section']) && $_GET['section'] === 'coinleywp') {
            // Enqueue admin JavaScript
            wp_enqueue_script(
                'coinleywp-admin',
                COINLEYWP_PLUGIN_URL . 'assets/js/admin.js',
                array('jquery'),
                COINLEYWP_VERSION,
                true
            );

            // Get current conversion rate for display
            $current_rate = '';
            $store_currency = get_woocommerce_currency();
            if ($store_currency !== 'USD') {
                $conversion_result = $this->convert_to_usd(1000, $store_currency);
                if (!is_wp_error($conversion_result) && isset($conversion_result['conversion_info'])) {
                    $current_rate = $conversion_result['conversion_info'];
                } else {
                    $current_rate = sprintf('Unable to fetch current rate for %s → USD. Click "Refresh Rate" to try again.', $store_currency);
                }
            } else {
                $current_rate = 'No conversion needed - your store already uses USD';
            }
            
            // Localize script with proper nonce and AJAX URL
            wp_localize_script('coinleywp-admin', 'coinleywp_admin', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('coinleywp_admin_nonce'),
                'current_conversion_rate' => $current_rate,
                'store_currency' => $store_currency,
                'strings' => array(
                    'loading' => __('Loading...', 'coinleywp'),
                    'error' => __('An error occurred', 'coinleywp'),
                    'success' => __('Success', 'coinleywp'),
                    'saving' => __('Saving...', 'coinleywp'),
                    'validating' => __('Validating...', 'coinleywp'),
                    'refreshing' => __('Refreshing...', 'coinleywp'),
                    'wallets_updated' => __('Wallets updated successfully', 'coinleywp'),
                    'refresh_failed' => __('Failed to refresh data', 'coinleywp'),
                    'credential_warning' => __('API credentials may be invalid', 'coinleywp'),
                    'credential_warning_desc' => __('Please check your API credentials', 'coinleywp'),
                    'refresh_credentials' => __('Refresh Credentials', 'coinleywp')
                )
            ));
        }
    }
    
    /**
     * Enhance payment method description with benefits list.
     * 
     * @param string $description Gateway description.
     * @param string $payment_id Payment method ID.
     * @return string
     */
    public function enhance_payment_description( $description, $payment_id ) {
        if ( $payment_id !== $this->id ) {
            return $description;
        }
        
        // Add benefits list and security badge
        $enhanced_description = $description;
        $enhanced_description .= '<ul class="coinleywp-benefits">';
        $enhanced_description .= '<li>' . __( 'Low transaction fees - save up to 80% on payment costs', 'coinleywp' ) . '</li>';
        $enhanced_description .= '<li>' . __( 'Instant settlements - no more waiting for days', 'coinleywp' ) . '</li>';
        $enhanced_description .= '<li>' . __( 'No chargebacks - fraud protection for merchants', 'coinleywp' ) . '</li>';
        $enhanced_description .= '<li>' . __( 'Global payments - accept payments from anywhere', 'coinleywp' ) . '</li>';
        $enhanced_description .= '</ul>';
        
        $enhanced_description .= '<div class="coinleywp-security">';
        $enhanced_description .= '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">';
        $enhanced_description .= '<path d="M8 1L2 3V8C2 11.3137 4.68629 14 8 14C11.3137 14 14 11.3137 14 8V3L8 1Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>';
        $enhanced_description .= '<path d="M6 8L7 9L10 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>';
        $enhanced_description .= '</svg>';
        $enhanced_description .= __( 'Secured by advanced blockchain technology and encryption', 'coinleywp' );
        $enhanced_description .= '</div>';
        
        return $enhanced_description;
    }

    /**
     * Initialize Gateway Settings Form Fields.
     */
    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'       => __('Enable/Disable', 'coinleywp'),
                'label'       => __('Enable Coinley Payment', 'coinleywp'),
                'type'        => 'checkbox',
                'description' => '',
                'default'     => 'yes'
            ),
            'title' => array(
                'title'       => __('Title', 'coinleywp'),
                'type'        => 'text',
                'description' => __('This controls the title which the user sees during checkout.', 'coinleywp'),
                'default'     => __('Pay with Cryptocurrency', 'coinleywp'),
                'desc_tip'    => true,
            ),
            'description' => array(
                'title'       => __('Description', 'coinleywp'),
                'type'        => 'textarea',
                'description' => __('This controls the description which the user sees during checkout.', 'coinleywp'),
                'default'     => __('Pay securely using cryptocurrency through Coinley.', 'coinleywp'),
                'desc_tip'    => true,
            ),
            'merchant_email' => array(
                'title'       => __('Merchant Email', 'coinleywp'),
                'type'        => 'email',
                'description' => __('Enter your Coinley merchant email address.', 'coinleywp'),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'merchant_password' => array(
                'title'       => __('Merchant Password', 'coinleywp'),
                'type'        => 'password',
                'description' => __('Enter your Coinley merchant password.', 'coinleywp'),
                'default'     => '',
                'desc_tip'    => true,
            ),
            'api_key' => array(
                'title'       => __('API Key', 'coinleywp'),
                'type'        => 'text',
                'description' => __('Your Coinley API key. This is automatically populated after login and cannot be edited directly.', 'coinleywp'),
                'default'     => '',
                'desc_tip'    => true,
                'custom_attributes' => array(
                    'readonly' => 'readonly',
                    'style' => 'background-color: #f8fafc; color: #64748b;'
                ),
            ),
            'api_secret' => array(
                'title'       => __('API Secret', 'coinleywp'),
                'type'        => 'text',
                'description' => __('Your Coinley API secret. This is automatically populated after login and cannot be edited directly.', 'coinleywp'),
                'default'     => '',
                'desc_tip'    => true,
                'custom_attributes' => array(
                    'readonly' => 'readonly',
                    'style' => 'background-color: #f8fafc; color: #64748b;'
                ),
            ),
            'testmode' => array(
                'title'       => __('Test mode', 'coinleywp'),
                'label'       => __('Enable Test Mode', 'coinleywp'),
                'type'        => 'checkbox',
                'description' => __('Place the payment gateway in test mode.', 'coinleywp'),
                'default'     => 'yes',
                'desc_tip'    => true,
            ),
            'debug' => array(
                'title'       => __('Debug log', 'coinleywp'),
                'type'        => 'checkbox',
                'label'       => __('Enable logging', 'coinleywp'),
                'default'     => 'no',
                'description' => __('Log Coinley events, such as API requests.', 'coinleywp'),
            ),
            'payment_timeout' => array(
                'title'       => __('Payment Timeout', 'coinleywp'),
                'type'        => 'number',
                'description' => __('Time in seconds before payment modal times out. Default is 300 seconds (5 minutes).', 'coinleywp'),
                'default'     => '300',
                'desc_tip'    => true,
                'custom_attributes' => array(
                    'min' => '60',
                    'max' => '1800',
                    'step' => '30'
                )
            ),
            'webhook_secret' => array(
                'title'       => __('Webhook Secret', 'coinleywp'),
                'type'        => 'text',
                'description' => __('Your webhook secret for verifying payment notifications. This is automatically generated and cannot be edited directly.', 'coinleywp'),
                'default'     => wp_generate_password(32, false),
                'desc_tip'    => true,
                'custom_attributes' => array(
                    'readonly' => 'readonly',
                    'style' => 'background-color: #f8fafc; color: #64748b;'
                ),
            ),
            'callback_url' => array(
                'title'       => __('Callback URL', 'coinleywp'),
                'type'        => 'text',
                'description' => __('The URL where Coinley will send payment notifications. This will be automatically set.', 'coinleywp'),
                'default'     => home_url('/wc-api/coinleywp'),
                'desc_tip'    => true,
                'custom_attributes' => array(
                    'readonly' => 'readonly'
                )
            ),

            'currency_section_title' => array(
                'title' => __('💱 Currency Conversion', 'coinleywp'),
                'type'  => 'title',
                'description' => __('<strong>Automatic Currency Conversion:</strong> If your store uses a currency other than USD, payments will be automatically converted to USD using free, real-time exchange rates from Fawaz Ahmed\'s Currency API.', 'coinleywp'),
            ),
            'currency_converter' => array(
                'title'       => __('Currency Converter', 'coinleywp'),
                'type'        => 'button',
                'description' => sprintf(
                    __('Preview currency conversion from %s to USD with real-time rates. Click to refresh with latest rates. <br><br><strong>💡 How it works:</strong><br>• If your store uses USD, no conversion is needed<br>• Other currencies are automatically converted to USD during checkout<br>• Exchange rates are cached for 1 hour to improve performance<br>• The rate is fetched automatically when you load this page<br><br><em>ℹ️ Uses free currency rates from <a href="https://github.com/fawazahmed0/exchange-api" target="_blank">Fawaz Ahmed\'s API</a> - no API key required! <br>❓ <strong>Need help?</strong> This tool is for testing only - your store will work even if this test fails.</em>', 'coinleywp'),
                    get_woocommerce_currency()
                ),
                'default'     => __('Refresh Rate', 'coinleywp'),
                'class'       => 'button-secondary',
                'custom_attributes' => array(
                    'onclick' => 'coinleywp_test_conversion(); return false;'
                )
            ),
            
            'conversion_rate_display' => array(
                'title'       => __('Current Conversion Rate', 'coinleywp'),
                'type'        => 'text',
                'description' => __('This field shows the current conversion rate and updates automatically when you load the page. Click "Refresh Rate" above to get the latest rate.', 'coinleywp'),
                'default'     => '', // This will be populated by JavaScript
                'custom_attributes' => array(
                    'readonly' => 'readonly',
                    'style' => 'background-color: #f9f9f9; cursor: not-allowed; font-family: monospace; font-size: 14px;'
                )
            ),

            'fee_section_title' => array(
                'title' => __('💰 Fee Configuration', 'coinleywp'),
                'type'  => 'title',
                'description' => __('<strong>Fee Settings:</strong> You can only choose who pays the transaction fees. The fee percentage is set by Coinley admin and cannot be changed by merchants.', 'coinleywp'),
            ),
            'fee_charged_to' => array(
                'title'       => __('Fee Charged To', 'coinleywp'),
                'type'        => 'select',
                'description' => __('Select who pays the transaction fees. This setting will be updated in your Coinley merchant account when you save.', 'coinleywp'),
                'default'     => 'customer',
                'desc_tip'    => true,
                'options'     => array(
                    'customer' => __('Customer (Customer pays original amount + fee)', 'coinleywp'),
                    'merchant' => __('Merchant (Customer pays original amount, merchant receives amount - fee)', 'coinleywp'),
                ),
            ),
            'current_fee_info' => array(
                'title'       => __('Current Fee Percentage', 'coinleywp'),
                'type'        => 'text',
                'description' => __('Your current fee percentage as set by Coinley admin. This is read-only and automatically updated when you login.', 'coinleywp'),
                'default'     => number_format(($this->current_fee_percentage ?? 0.0175) * 100, 2) . '%',
                'desc_tip'    => true,
                'custom_attributes' => array(
                    'readonly' => 'readonly',
                    'style' => 'background-color: #f9f9f9; color: #333; font-weight: bold;'
                )
            ),
        );
    }

    /**
     * Override get_option to ensure current_fee_info always shows the current value
     */
    public function get_option($key, $empty_value = null) {
        if ($key === 'current_fee_info') {
            return number_format($this->current_fee_percentage * 100, 2) . '%';
        }
        return parent::get_option($key, $empty_value);
    }

    /**
     * Process merchant login and save API credentials
     */
    public function process_merchant_login() {
        if (!isset($_POST['woocommerce_coinleywp_merchant_email']) || !isset($_POST['woocommerce_coinleywp_merchant_password'])) {
            return;
        }

        $email = sanitize_email($_POST['woocommerce_coinleywp_merchant_email']);
        $password = $_POST['woocommerce_coinleywp_merchant_password'];

        if (empty($email) || empty($password)) {
            WC_Admin_Settings::add_error(__('Please provide both email and password.', 'coinleywp'));
            return;
        }

        try {
            // Use the enhanced API login method
            $response = $this->api->login_merchant($email, $password);

            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }

            if (!isset($response['token']) || !isset($response['merchant'])) {
                throw new Exception(__('Invalid response from Coinley API. Please check your credentials.', 'coinleywp'));
            }

            $merchant = $response['merchant'];

            // Save API credentials and merchant info
            $this->settings['api_key'] = $merchant['apiKey'] ?? '';
            $this->settings['api_secret'] = $merchant['apiSecret'] ?? '';
            $this->settings['webhook_secret'] = $merchant['webhookSecret'] ?? wp_generate_password(32, false);
            $this->settings['merchant_id'] = $merchant['id'] ?? '';
            $this->settings['merchant_status'] = $merchant['status'] ?? 'active';
            $this->settings['merchant_verified'] = $merchant['verified'] ?? false;
            $this->settings['custom_fee_percentage'] = $merchant['customFeePercentage'] ?? 0.0175;
            $this->settings['fee_charged_to'] = $merchant['feeChargedTo'] ?? 'customer';
            
            // Update fee display field (read-only, just for information)
            $fee_percentage = number_format(($merchant['customFeePercentage'] ?? 0.0175) * 100, 2);
            $this->settings['current_fee_info'] = sprintf(
                __('%s%% (set by Coinley admin)', 'coinleywp'),
                $fee_percentage
            );
            
            // Save the updated settings to persist the fee information
            update_option('woocommerce_coinleywp_settings', $this->settings);

            // Clear password field for security
            $_POST['woocommerce_coinleywp_merchant_password'] = '';

            // Reinitialize API with new credentials
            $this->api = new CoinleyWP_API(
                $this->settings['api_key'],
                $this->settings['api_secret'],
                $this->testmode,
                $this->debug
            );

            // Try to fetch merchant dashboard data to verify connection
            $dashboard_data = $this->api->get_merchant_dashboard();
            if (!is_wp_error($dashboard_data)) {
                WC_Admin_Settings::add_message(
                    sprintf(
                        __('Successfully connected to Coinley! Welcome, %s. Your account status: %s', 'coinleywp'),
                        $merchant['businessName'] ?? $merchant['firstName'] . ' ' . $merchant['lastName'] ?? 'Merchant',
                        ucfirst($merchant['status'] ?? 'active')
                    )
                );
                
                if (!($merchant['verified'] ?? false)) {
                    WC_Admin_Settings::add_message(
                        __('Please verify your email address to unlock all features.', 'coinleywp')
                    );
                }
            } else {
                WC_Admin_Settings::add_message(__('Connected to Coinley, but unable to fetch dashboard data. Please check your API credentials.', 'coinleywp'));
            }

        } catch (Exception $e) {
            error_log('CoinleyWP Login Error: ' . $e->getMessage());
            WC_Admin_Settings::add_error(
                sprintf(
                    __('Failed to connect to Coinley: %s', 'coinleywp'),
                    $e->getMessage()
                )
            );
        }
    }

    /**
     * Verify API connection
     */
    public function test_api_connection() {
        if (!$this->api || empty($this->api_key) || empty($this->api_secret)) {
            return new WP_Error('no_credentials', __('API credentials not configured', 'coinleywp'));
        }

        try {
            // Test with a simple dashboard request
            $response = $this->api->get_merchant_dashboard();
            
            if (is_wp_error($response)) {
                return $response;
            }

            return array(
                'success' => true,
                'message' => __('API connection successful', 'coinleywp'),
                'merchant_data' => $response['merchant'] ?? null
            );

        } catch (Exception $e) {
            return new WP_Error('connection_failed', $e->getMessage());
        }
    }

    /**
     * Create payment using enhanced API method
     */
    public function create_payment_with_network($amount, $currency, $network, $customer_email, $metadata = array()) {
        if (!$this->api) {
            return new WP_Error('no_api', __('API not configured', 'coinleywp'));
        }

        try {
            return $this->api->create_payment_enhanced($amount, $currency, $network, $customer_email, $metadata);
        } catch (Exception $e) {
            error_log('CoinleyWP Payment Creation Error: ' . $e->getMessage());
            return new WP_Error('payment_creation_failed', $e->getMessage());
        }
    }

    /**
     * Process payment using enhanced API method
     */
    public function process_payment_with_details($payment_id, $transaction_hash, $network = null, $sender_address = null) {
        if (!$this->api) {
            return new WP_Error('no_api', __('API not configured', 'coinleywp'));
        }

        try {
            return $this->api->process_payment_enhanced($payment_id, $transaction_hash, $network, $sender_address);
        } catch (Exception $e) {
            error_log('CoinleyWP Payment Processing Error: ' . $e->getMessage());
            return new WP_Error('payment_processing_failed', $e->getMessage());
        }
    }

    /**
     * Admin Panel Options
     */
    public function admin_options() {
        // Process merchant login if credentials are submitted
        $this->process_merchant_login();

        // Add custom JavaScript for masking credentials
        $this->add_credential_masking_script();

        // Add notification container for enhanced notifications
        echo '<div id="coinleywp-notification-container" style="margin-bottom: 20px;"></div>';

        // Display settings
        parent::admin_options();
        
        // Display wallet sync status if API is configured
        $this->display_wallet_sync_status();
    }
    
    /**
     * Add JavaScript to mask API credentials on page load
     */
    private function add_credential_masking_script() {
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            // Enhanced notification system (similar to onboarding)
            window.showNotification = function(type, title, message, actions) {
                jQuery('#coinleywp-notification-container').empty();
                var iconMap = {
                    'success': '✓',
                    'error': '⚠',
                    'warning': '!',
                    'info': 'ℹ'
                };
                var notification = jQuery(`
                    <div class="coinleywp-enhanced-notification ${type}">
                        <div class="coinleywp-enhanced-notification-header">
                            <div class="coinleywp-enhanced-notification-icon">${iconMap[type] || 'ℹ'}</div>
                            <div class="coinleywp-enhanced-notification-content">
                                <div class="coinleywp-enhanced-notification-title">${title}</div>
                                <div class="coinleywp-enhanced-notification-message">${message}</div>
                            </div>
                        </div>
                        ${actions ? `<div class="coinleywp-enhanced-notification-actions">${actions}</div>` : ''}
                        <button class="coinleywp-enhanced-notification-close">&times;</button>
                    </div>
                `);
                jQuery('#coinleywp-notification-container').append(notification);
                
                // Auto-hide success notifications after 5 seconds
                if (type === 'success') {
                    setTimeout(function() {
                        notification.fadeOut(300, function() {
                            jQuery(this).remove();
                        });
                    }, 5000);
                }
            }
            
            // Handle notification close
            jQuery(document).on('click', '.coinleywp-enhanced-notification-close', function() {
                jQuery(this).closest('.coinleywp-enhanced-notification').fadeOut(300, function() {
                    jQuery(this).remove();
                });
            });
            
            // Store original values
            var originalApiKey = $('#woocommerce_coinleywp_api_key').val();
            var originalApiSecret = $('#woocommerce_coinleywp_api_secret').val();
            
            // Mask API key
            if (originalApiKey && originalApiKey.length > 4) {
                $('#woocommerce_coinleywp_api_key').val('••••••••••••••••••••••••••••••••' + originalApiKey.slice(-4));
                $('#woocommerce_coinleywp_api_key').data('original', originalApiKey);
                
                // Add show/hide button for API key
                var apiKeyField = $('#woocommerce_coinleywp_api_key').closest('td');
                if (apiKeyField.find('.show-hide-credential').length === 0) {
                    apiKeyField.append('<button type="button" class="button show-hide-credential" data-field="api_key" style="margin-left: 10px;"><span class="dashicons dashicons-visibility"></span> Show</button>');
                }
            }
            
            // Mask API secret
            if (originalApiSecret && originalApiSecret.length > 4) {
                $('#woocommerce_coinleywp_api_secret').val('••••••••••••••••••••••••••••••••' + originalApiSecret.slice(-4));
                $('#woocommerce_coinleywp_api_secret').data('original', originalApiSecret);
                
                // Add show/hide button for API secret
                var apiSecretField = $('#woocommerce_coinleywp_api_secret').closest('td');
                if (apiSecretField.find('.show-hide-credential').length === 0) {
                    apiSecretField.append('<button type="button" class="button show-hide-credential" data-field="api_secret" style="margin-left: 10px;"><span class="dashicons dashicons-visibility"></span> Show</button>');
                }
            }
            
            // Handle show/hide button clicks
            $(document).on('click', '.show-hide-credential', function(e) {
                e.preventDefault();
                var button = $(this);
                var field = button.data('field');
                var input = $('#woocommerce_coinleywp_' + field);
                var isShowing = button.hasClass('showing');
                
                if (!isShowing) {
                    // Show original value
                    input.val(input.data('original'));
                    button.html('<span class="dashicons dashicons-hidden"></span> Hide');
                    button.addClass('showing');
                } else {
                    // Hide value (mask it)
                    var original = input.data('original');
                    if (original && original.length > 4) {
                        input.val('••••••••••••••••••••••••••••••••' + original.slice(-4));
                    }
                    button.html('<span class="dashicons dashicons-visibility"></span> Show');
                    button.removeClass('showing');
                }
            });
            
            // Prevent form submission with masked values
            $('form').on('submit', function() {
                $('.show-hide-credential').each(function() {
                    var button = $(this);
                    var field = button.data('field');
                    var input = $('#woocommerce_coinleywp_' + field);
                    var original = input.data('original');
                    
                    // Restore original value before submission
                    if (original) {
                        input.val(original);
                    }
                });
            });
        });
        </script>
        <style>
        .show-hide-credential {
            font-size: 12px !important;
            padding: 4px 8px !important;
            height: auto !important;
        }
        .show-hide-credential .dashicons {
            font-size: 16px;
            width: 16px;
            height: 16px;
            vertical-align: middle;
        }
        </style>
        <?php
    }

    /**
     * Display wallet synchronization status
     */
    private function display_wallet_sync_status() {
        if (empty($this->api_key) || empty($this->api_secret)) {
            return;
        }
        
        echo '<div class="coinley-wallet-sync-status" style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #7C3AED;">';
        echo '<h4 style="margin: 0 0 10px 0; color: #7C3AED;"><span class="dashicons dashicons-admin-network" style="margin-right: 5px;"></span>' . __('Wallet Synchronization Status', 'coinleywp') . '</h4>';
        
        try {
            $wallet_addresses = $this->get_merchant_wallets();
            
            if (empty($wallet_addresses)) {
                echo '<p style="color: #d63638; margin: 0;"><span class="dashicons dashicons-warning" style="margin-right: 5px;"></span>';
                echo __('No wallet addresses configured. Please add wallet addresses in your Coinley dashboard.', 'coinleywp');
                echo '</p>';
            } else {
                echo '<p style="color: #00a32a; margin: 0 0 10px 0;"><span class="dashicons dashicons-yes-alt" style="margin-right: 5px;"></span>';
                echo __('Active wallet addresses from Coinley:', 'coinleywp');
                echo '</p>';
                
                echo '<div style="display: grid; gap: 10px;">';
                
                // Define network display order
                $network_order = array('ethereum', 'bsc', 'solana', 'tron', 'algorand');
                
                // Display wallets in order
                foreach ($network_order as $network) {
                    if (!isset($wallet_addresses[$network])) {
                        continue;
                    }
                    
                    $wallet_data = $wallet_addresses[$network];
                    $address = '';
                    $network_name = '';
                    $tokens = array();
                    
                    // Extract data based on structure
                    if (is_string($wallet_data)) {
                        $address = $wallet_data;
                        $network_name = ucfirst($network);
                    } elseif (is_array($wallet_data)) {
                        $address = $wallet_data['address'] ?? '';
                        $network_name = $wallet_data['networkName'] ?? ucfirst($network);
                        $tokens = $wallet_data['supportedTokens'] ?? array();
                    }
                    
                    if (empty($address)) continue;
                    
                    // Create short address for display
                    $short_address = strlen($address) > 20 ? 
                        substr($address, 0, 10) . '...' . substr($address, -8) : 
                        $address;
                    
                    // Network icons
                    $network_icons = array(
                        'ethereum' => '⟠',
                        'bsc' => '🔶',
                        'solana' => '◉',
                        'tron' => '🔷',
                        'algorand' => '🔵'
                    );
                    
                    $icon = $network_icons[$network] ?? '●';
                    
                    echo '<div style="display: flex; align-items: center; padding: 8px; background: white; border: 1px solid #e2e8f0; border-radius: 6px;">';
                    echo '<span style="font-size: 20px; margin-right: 10px;">' . $icon . '</span>';
                    echo '<div style="flex: 1;">';
                    echo '<strong style="color: #1e293b; display: block; margin-bottom: 2px;">' . esc_html($network_name) . '</strong>';
                    echo '<code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-size: 12px; color: #475569;" title="' . esc_attr($address) . '">' . esc_html($short_address) . '</code>';
                    
                    if (!empty($tokens)) {
                        echo '<div style="margin-top: 4px;">';
                        echo '<span style="font-size: 11px; color: #64748b;">Supported tokens: </span>';
                        foreach ($tokens as $token) {
                            echo '<span style="display: inline-block; background: #7C3AED; color: white; padding: 2px 6px; border-radius: 3px; font-size: 10px; margin-left: 4px;">' . esc_html($token) . '</span>';
                        }
                        echo '</div>';
                    }
                    
                    echo '</div>';
                    echo '</div>';
                }
                
                // Display any additional networks not in the standard order
                foreach ($wallet_addresses as $network => $wallet_data) {
                    if (in_array($network, $network_order)) {
                        continue; // Already displayed
                    }
                    
                    $address = is_string($wallet_data) ? $wallet_data : ($wallet_data['address'] ?? '');
                    if (empty($address)) continue;
                    
                    $short_address = strlen($address) > 20 ? 
                        substr($address, 0, 10) . '...' . substr($address, -8) : 
                        $address;
                    
                    echo '<div style="display: flex; align-items: center; padding: 8px; background: white; border: 1px solid #e2e8f0; border-radius: 6px;">';
                    echo '<span style="font-size: 20px; margin-right: 10px;">●</span>';
                    echo '<div style="flex: 1;">';
                    echo '<strong style="color: #1e293b; display: block; margin-bottom: 2px;">' . esc_html(ucfirst($network)) . '</strong>';
                    echo '<code style="background: #f1f5f9; padding: 4px 8px; border-radius: 4px; font-size: 12px; color: #475569;" title="' . esc_attr($address) . '">' . esc_html($short_address) . '</code>';
                    echo '</div>';
                    echo '</div>';
                }
                
                echo '</div>';
                
                // Show sync info
                echo '<div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #e2e8f0;">';
                echo '<p style="margin: 0; font-size: 12px; color: #64748b;">';
                echo '<span class="dashicons dashicons-info" style="font-size: 14px; margin-right: 4px;"></span>';
                echo __('These addresses are automatically synced to your Coinley dashboard. You can also add addresses manually in the settings above.', 'coinleywp');
                echo '</p>';
                echo '</div>';
            }
            
        } catch (Exception $e) {
            echo '<p style="color: #d63638; margin: 0;"><span class="dashicons dashicons-warning" style="margin-right: 5px;"></span>';
            echo sprintf(__('Error checking wallet sync status: %s', 'coinleywp'), $e->getMessage());
            echo '</p>';
        }
        
        echo '</div>';
    }

    /**
     * Process the payment and return the result.
     *
     * @param int $order_id Order ID.
     * @return array
     */
    public function process_payment($order_id) {
        $order = wc_get_order($order_id);

        if (!$order) {
            error_log('CoinleyWP Error - Order not found for ID: ' . $order_id);
            wc_add_notice(__('Order not found. Please try again.', 'coinleywp'), 'error');
            return array('result' => 'failure');
        }

        // Convert order amount to USD if needed
        $order_total = $order->get_total();
        $order_currency = $order->get_currency();
        
        $conversion_result = $this->convert_to_usd($order_total, $order_currency);
        
        if (is_wp_error($conversion_result)) {
            error_log('CoinleyWP Currency Conversion Error: ' . $conversion_result->get_error_message());
            wc_add_notice(__('Currency conversion failed. Please try again.', 'coinleywp'), 'error');
            return array('result' => 'failure');
        }

        // Mark as pending payment (awaiting crypto payment via modal)
        $order->update_status('pending', __('Awaiting cryptocurrency payment via Coinley', 'coinleywp'));
        
        // Save payment pending status and conversion data
        $order->update_meta_data('_coinleywp_payment_pending', true);
        $order->update_meta_data('_coinleywp_original_amount', $conversion_result['original_amount']);
        $order->update_meta_data('_coinleywp_original_currency', $conversion_result['original_currency']);
        $order->update_meta_data('_coinleywp_converted_amount', $conversion_result['converted_amount']);
        $order->update_meta_data('_coinleywp_converted_currency', $conversion_result['converted_currency']);
        $order->update_meta_data('_coinleywp_exchange_rate', $conversion_result['exchange_rate']);
        
        // Add conversion note if conversion happened
        if ($conversion_result['conversion_info']) {
            $order->add_order_note(
                sprintf(
                    __('Payment amount converted: %s', 'coinleywp'),
                    $conversion_result['conversion_info']
                )
            );
        }
        
        $order->save();
        
        // DON'T reduce stock or empty cart yet - wait for actual payment
        // This will be done after successful payment via AJAX
        
        // For WooCommerce Blocks, we need to handle this differently
        if ($this->is_blocks_checkout()) {
            // Return success for blocks, the JavaScript will handle the modal
            $response = array(
                'result' => 'success',
                'redirect' => false,
                'messages' => array(),
                'coinleywp_order_data' => array(
                    'order_id' => $order_id,
                    'order_key' => $order->get_order_key(),
                    'order_total' => $conversion_result['converted_amount'],
                    'original_total' => $conversion_result['original_amount'],
                    'original_currency' => $conversion_result['original_currency'],
                    'converted_currency' => $conversion_result['converted_currency'],
                    'conversion_info' => $conversion_result['conversion_info']
                )
            );
            
            // Add inline JavaScript to trigger the modal
            add_action('wp_footer', function() use ($order_id, $order, $conversion_result) {
                ?>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    console.log('CoinleyWP: Triggering blocks checkout response event');
                    window.dispatchEvent(new CustomEvent('coinleywp_blocks_checkout_response', {
                        detail: {
                            order_id: <?php echo json_encode($order_id); ?>,
                            order_key: <?php echo json_encode($order->get_order_key()); ?>,
                            order_total: <?php echo json_encode($conversion_result['converted_amount']); ?>,
                            original_total: <?php echo json_encode($conversion_result['original_amount']); ?>,
                            original_currency: <?php echo json_encode($conversion_result['original_currency']); ?>,
                            converted_currency: <?php echo json_encode($conversion_result['converted_currency']); ?>,
                            conversion_info: <?php echo json_encode($conversion_result['conversion_info']); ?>
                        }
                    }));
                });
                </script>
                <?php
            });
        } else {
            // Classic checkout handling
            $response = array(
                'result' => 'success',
                'redirect' => false,
                'coinleywp_show_modal' => true,
                'order_data' => array(
                    'order_id' => $order_id,
                    'order_key' => $order->get_order_key(),
                    'order_total' => $conversion_result['converted_amount'],
                    'original_total' => $conversion_result['original_amount'],
                    'original_currency' => $conversion_result['original_currency'],
                    'converted_currency' => $conversion_result['converted_currency'],
                    'conversion_info' => $conversion_result['conversion_info']
                )
            );
        }
        
        // Debug logging
        error_log('CoinleyWP Payment Response: ' . json_encode($response));
        
        return $response;
    }

    /**
     * Validate that wallet addresses are configured before enabling gateway
     */
    public function validate_fields() {
        $is_valid = true;

        // Check if at least one wallet is configured when enabling the gateway
        if (isset($_POST['woocommerce_' . $this->id . '_enabled']) &&
            $_POST['woocommerce_' . $this->id . '_enabled'] === '1') {

            // Check if there are wallets configured via API/Dashboard
            $api_wallets = $this->get_merchant_wallets();
            if (empty($api_wallets) || !is_array($api_wallets)) {
                $is_valid = false;
                WC_Admin_Settings::add_error(
                    __('You must configure at least one valid wallet address before enabling the Coinley payment gateway. Please configure wallets in your Coinley Dashboard at: https://coinleymerchant.vercel.app/wallet-addresses', 'coinleywp')
                );
            }
        }

        return $is_valid;
    }

    /**
     * Process admin options and sync fee settings with API
     */
    public function process_admin_options() {
        // First validate the input data
        if (!$this->validate_fields()) {
            return false;
        }

        // Save the options
        $saved = parent::process_admin_options();

        if ($saved) {
            // Check if we have API credentials
            $api_key = $this->get_option('api_key');
            $api_secret = $this->get_option('api_secret');

            if (!empty($api_key) && !empty($api_secret)) {
                // Sync fee settings with API
                $this->sync_fee_settings_to_api();

                // Clear wallet cache to fetch fresh data
                delete_transient('coinleywp_merchant_wallets');

                WC_Admin_Settings::add_message(
                    __('Settings saved successfully! Wallet addresses are managed in your Coinley Dashboard.', 'coinleywp')
                );
            } else {
                WC_Admin_Settings::add_message(
                    __('Settings saved locally. Add API credentials to connect with Coinley.', 'coinleywp')
                );
            }
        }

        return $saved;
    }

    /**
     * Sync wallet addresses to Coinley API before saving locally
     */
    private function sync_wallet_addresses_to_api_before_save() {
        $api_key = $this->get_field_value('api_key', $this->form_fields['api_key']);
        $api_secret = $this->get_field_value('api_secret', $this->form_fields['api_secret']);
        $testmode = $this->get_field_value('testmode', $this->form_fields['testmode']) === 'yes';
        $debug = $this->get_field_value('debug', $this->form_fields['debug']) === 'yes';
        
        if (empty($api_key) || empty($api_secret)) {
            return true; // Allow save without API sync
        }
        
        // Initialize API
        if (!class_exists('CoinleyWP_API')) {
            require_once COINLEYWP_PLUGIN_DIR . 'includes/class-coinleywp-api.php';
        }
        $api = new CoinleyWP_API($api_key, $api_secret, $testmode, $debug);
        
        // Collect wallet addresses from form
        $wallets_to_update = array();
        $wallet_fields = array(
            'ethereum_wallet' => array('network' => 'ethereum', 'tokens' => ['USDT', 'USDC', 'DAI']),
            'bsc_wallet' => array('network' => 'bsc', 'tokens' => ['USDT', 'USDC']),
            'tron_wallet' => array('network' => 'tron', 'tokens' => ['USDT', 'USDC']),
            'algorand_wallet' => array('network' => 'algorand', 'tokens' => ['USDT', 'USDC']),
            'solana_wallet' => array('network' => 'solana', 'tokens' => ['USDT', 'USDC'])
        );
        
        foreach ($wallet_fields as $field => $config) {
            $address = $this->get_field_value($field, $this->form_fields[$field]);
            if (!empty($address) && $this->validate_wallet_address($address, $field)) {
                $wallets_to_update[] = array(
                    'networkShortName' => $config['network'],
                    'walletAddress' => $address,
                    'supportedTokens' => $config['tokens']
                );
            }
        }
        
        // If no wallets to update, still allow save
        if (empty($wallets_to_update)) {
            return true;
        }
        
        try {
            // Prepare the update payload
            $update_payload = array('wallets' => $wallets_to_update);
            
            error_log('CoinleyWP: Updating wallets with payload: ' . json_encode($update_payload));
            
            $response = $api->update_merchant_wallets($update_payload);
            
            if (is_wp_error($response)) {
                error_log('CoinleyWP: Wallet update failed: ' . $response->get_error_message());
                WC_Admin_Settings::add_error(
                    sprintf(__('Failed to sync wallet addresses to Coinley: %s', 'coinleywp'), $response->get_error_message())
                );
                return false;
            }
            
            // Clear the wallet cache so fresh data is fetched
            delete_transient('coinleywp_merchant_wallets');
            
            error_log('CoinleyWP: Wallets updated successfully');
            return true;
            
        } catch (Exception $e) {
            error_log('CoinleyWP: Exception updating wallets: ' . $e->getMessage());
            WC_Admin_Settings::add_error(
                sprintf(__('Failed to sync wallet addresses: %s', 'coinleywp'), $e->getMessage())
            );
            return false;
        }
    }

    /**
     * Sync wallet addresses to Coinley API (legacy method - now unused)
     */
    private function sync_wallet_addresses_to_api() {
        // This method is now unused - keeping for backward compatibility
        // The new flow syncs before saving in sync_wallet_addresses_to_api_before_save()
        return;
    }

    /**
     * Sync fee settings to Coinley API
     */
    private function sync_fee_settings_to_api() {
        // Only sync if API is configured
        if (empty($this->api_key) || empty($this->api_secret) || !$this->api) {
            return;
        }
        
        // Get the fee_charged_to setting that was just saved
        $fee_charged_to = $this->get_option('fee_charged_to', 'customer');
        
        try {
            // Update merchant profile with fee setting
            $profile_data = array(
                'feeChargedTo' => $fee_charged_to
            );
            
            $response = $this->api->update_merchant_profile($profile_data);
            
            if (is_wp_error($response)) {
                error_log('CoinleyWP: Failed to sync fee settings to API: ' . $response->get_error_message());
                WC_Admin_Settings::add_message(__('Settings saved locally, but failed to sync fee settings to Coinley API. Your local settings will be used.', 'coinleywp'));
            } else {
                error_log('CoinleyWP: Fee settings synced successfully to API');
            }
            
        } catch (Exception $e) {
            error_log('CoinleyWP: Exception syncing fee settings to API: ' . $e->getMessage());
        }
    }

    /**
     * Check if the gateway is available for use
     */
    public function is_available() {
        if ('yes' !== $this->enabled) {
            return false;
        }

        // Check if API credentials are set
        if (empty($this->api_key) || empty($this->api_secret)) {
            return false;
        }

        // Check if at least one wallet address is configured via API/Dashboard
        $api_wallets = $this->get_merchant_wallets();
        if (empty($api_wallets) || !is_array($api_wallets)) {
            return false;
        }

        return true;
    }

    /**
     * Validate wallet address format based on network type
     *
     * @param string $address Wallet address to validate
     * @param string $wallet_type Type of wallet (ethereum_wallet, bsc_wallet, tron_wallet, algorand_wallet, solana_wallet)
     * @return bool
     */
    private function validate_wallet_address($address, $wallet_type) {
        if (empty($address)) {
            return false;
        }

        switch ($wallet_type) {
            case 'ethereum_wallet':
            case 'bsc_wallet':
                // Ethereum-compatible addresses (0x + 40 hex characters)
                return preg_match('/^0x[a-fA-F0-9]{40}$/', $address);
                
            case 'tron_wallet':
                // TRON addresses (T + 33 Base58 characters)
                return preg_match('/^T[a-zA-Z0-9]{33}$/', $address);
                
            case 'algorand_wallet':
                // Algorand addresses (58 Base32 characters)
                return preg_match('/^[A-Z2-7]{58}$/', $address);
                
            case 'solana_wallet':
                // Solana addresses (Base58 encoded, 32-44 characters)
                return preg_match('/^[1-9A-HJ-NP-Za-km-z]{32,44}$/', $address);
                
            default:
                return false;
        }
    }

    /**
     * Get configured wallet addresses for display/usage
     *
     * @return array Array of configured wallet addresses
     */
    public function get_configured_wallets() {
        $wallets = array();
        $wallet_fields = array(
            'ethereum_wallet' => __('Ethereum', 'coinleywp'),
            'bsc_wallet' => __('Binance Smart Chain', 'coinleywp'),
            'tron_wallet' => __('TRON', 'coinleywp'),
            'algorand_wallet' => __('Algorand', 'coinleywp'),
            'solana_wallet' => __('Solana', 'coinleywp')
        );

        foreach ($wallet_fields as $field => $name) {
            $address = $this->get_option($field);
            if (!empty($address) && $this->validate_wallet_address($address, $field)) {
                $wallets[$field] = array(
                    'name' => $name,
                    'address' => $address
                );
            }
        }

        return $wallets;
    }

    /**
     * Get merchant wallet addresses (API first, local cache fallback)
     */
    public function get_merchant_wallets() {
        $cached_wallets = get_transient('coinleywp_merchant_wallets');
        
        if ($cached_wallets !== false) {
            return $cached_wallets;
        }
        
        $api = $this->get_api_instance();
        if ($api) {
            try {
                $response = $api->get_merchant_wallets();
                
                if (!is_wp_error($response)) {
                    $formatted_wallets = $this->format_api_wallet_response($response);
                    
                    if (!empty($formatted_wallets)) {
                        // Simplify for JavaScript usage - only include configured wallets
                        $simple_wallets = array();
                        foreach ($formatted_wallets as $network => $data) {
                            if (is_array($data) && isset($data['address']) && !empty($data['address'])) {
                                $simple_wallets[$network] = $data['address'];
                            } elseif (is_string($data) && !empty($data)) {
                                $simple_wallets[$network] = $data;
                            }
                        }
                        
                        // Cache for 5 minutes
                        set_transient('coinleywp_merchant_wallets', $simple_wallets, 5 * MINUTE_IN_SECONDS);
                        
                        // Also save the full data for admin display
                        update_option('coinleywp_merchant_wallets_full', $formatted_wallets);
                        
                        return $simple_wallets;
                    }
                }
            } catch (Exception $e) {
                error_log('CoinleyWP: Exception fetching wallets: ' . $e->getMessage());
            }
        }
        
        // Fallback to cached wallets
        $cached = get_option('coinleywp_merchant_wallets_full', array());
        $simple_wallets = array();
        
        foreach ($cached as $network => $data) {
            if (is_array($data) && isset($data['address']) && !empty($data['address'])) {
                $simple_wallets[$network] = $data['address'];
            } elseif (is_string($data) && !empty($data)) {
                $simple_wallets[$network] = $data;
            }
        }
        
        return $simple_wallets;
    }
    /**
     * Format API wallet response to expected format
     */
    private function format_api_wallet_response($response) {
        $formatted_wallets = array();
        
        // Debug log the raw response
        error_log('CoinleyWP: Raw wallet API response structure: ' . json_encode(array_keys($response)));
        
        // Handle the actual API response format
        if (isset($response['success']) && $response['success'] === true && isset($response['wallets']) && is_array($response['wallets'])) {
            $wallets_data = $response['wallets'];
            
            // Process each wallet entry
            foreach ($wallets_data as $wallet) {
                // Skip if no network short name
                if (!isset($wallet['networkShortName'])) {
                    continue;
                }
                
                $network = $this->normalize_network_name($wallet['networkShortName']);
                $wallet_address = $wallet['walletAddress'] ?? '';
                
                // Store wallet data including unconfigured wallets
                $formatted_wallets[$network] = array(
                    'address' => $wallet_address,
                    'networkName' => $wallet['networkName'] ?? ucfirst($network),
                    'networkType' => $wallet['networkType'] ?? $network,
                    'networkId' => $wallet['networkId'] ?? null,
                    'networkLogo' => $wallet['networkLogo'] ?? '',
                    'isConfigured' => $wallet['isConfigured'] ?? !empty($wallet_address),
                    'supportedTokens' => array()
                );
                
                // Handle both string and object wallet addresses for backward compatibility
                if (is_array($wallet_address) && isset($wallet_address['address'])) {
                    $formatted_wallets[$network]['address'] = $wallet_address['address'];
                    $formatted_wallets[$network]['supportedTokens'] = $wallet_address['supportedTokens'] ?? array();
                    $formatted_wallets[$network]['isConfigured'] = !empty($wallet_address['address']);
                }
            }
        }
        
        error_log('CoinleyWP: Formatted wallets: ' . json_encode($formatted_wallets));
        
        return $formatted_wallets;
    }
    

    /**
     * Normalize network name to expected format
     */
    private function normalize_network_name($network_name) {
        $network_mapping = array(
            'ethereum' => 'ethereum',
            'bsc' => 'bsc', 
            'tron' => 'tron',
            'algorand' => 'algorand',
            'solana' => 'solana',
            'sepolia' => 'sepolia',
            // Handle alternative names
            'eth' => 'ethereum',
            'bnb' => 'bsc',
            'trx' => 'tron'
        );
        
        $normalized = strtolower(trim($network_name));
        return $network_mapping[$normalized] ?? $normalized;
    }

    /**
     * Get API instance if available
     */
    private function get_api_instance() {
        $api_key = $this->get_option('api_key');
        $api_secret = $this->get_option('api_secret');
        
        if (empty($api_key) || empty($api_secret)) {
            return null;
        }
        
        if (!class_exists('CoinleyWP_API')) {
            require_once plugin_dir_path(__FILE__) . 'class-coinleywp-api.php';
        }
        
        return new CoinleyWP_API(
            $api_key,
            $api_secret,
            $this->get_option('testmode') === 'yes',
            $this->get_option('debug') === 'yes'
        );
    }

    /**
     * Check if we're using WooCommerce Blocks checkout
     */
    private function is_blocks_checkout() {
        return isset($_POST['payment_method']) && 
               $_POST['payment_method'] === 'coinleywp' && 
               (isset($_POST['payment_data']) || 
                strpos($_SERVER['REQUEST_URI'], 'store/checkout') !== false ||
                (function_exists('wc_has_block_in_page') && wc_has_block_in_page(null, 'woocommerce/checkout')));
    }




    /**
     * Process a refund if supported.
     *
     * @param int    $order_id Order ID.
     * @param float  $amount Refund amount.
     * @param string $reason Refund reason.
     * @return bool|WP_Error
     */
    public function process_refund( $order_id, $amount = null, $reason = '' ) {
        $order = wc_get_order( $order_id );

        if ( ! $order ) {
            return new WP_Error( 'invalid_order', __( 'Invalid order ID.', 'coinleywp' ) );
        }

        $payment_id = $order->get_meta( '_coinley_payment_id' );

        if ( ! $payment_id ) {
            return new WP_Error( 'invalid_payment', __( 'Cannot refund as no payment ID was found.', 'coinleywp' ) );
        }

        $refund = $this->api->refund_payment(
            $payment_id,
            array(
                'amount' => $amount,
                'reason' => $reason,
            )
        );

        if ( is_wp_error( $refund ) ) {
            return $refund;
        }

        return true;
    }

    /**
     * Handle webhook requests.
     */
    public function webhook_handler() {
        // Get the request body.
        $request_body = file_get_contents( 'php://input' );
        $data = json_decode( $request_body, true );

        if ( ! $data || ! isset( $data['event'] ) || ! isset( $data['data'] ) ) {
            status_header( 400 );
            exit( 'Invalid webhook data' );
        }

        // Verify webhook signature.
        if ( ! $this->api->verify_webhook_signature( $request_body, $_SERVER['HTTP_COINLEY_SIGNATURE'] ) ) {
            status_header( 403 );
            exit( 'Invalid signature' );
        }

        $event = $data['event'];
        $payment_data = $data['data'];
        
        // Get the order.
        $order_id = $payment_data['metadata']['order_id'];
        $order = wc_get_order( $order_id );

        if ( ! $order ) {
            status_header( 404 );
            exit( 'Order not found' );
        }

        // Handle different event types.
        switch ( $event ) {
            case 'payment.succeeded':
                $order->payment_complete( $payment_data['id'] );
                $order->add_order_note( __( 'Coinley payment complete.', 'coinleywp' ) );
                break;
                
            case 'payment.failed':
                $order->update_status( 'failed', __( 'Coinley payment failed.', 'coinleywp' ) );
                break;
                
            case 'payment.refunded':
                if ( ! $order->has_status( 'refunded' ) ) {
                    $order->update_status( 'refunded', __( 'Coinley payment refunded.', 'coinleywp' ) );
                }
                break;
        }

        status_header( 200 );
        exit( 'Webhook processed' );
    }

    /**
     * Handle AJAX request to create WooCommerce Blocks order after successful payment.
     */
    public function handle_blocks_order_creation() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_nonce')) {
            wp_send_json_error('Invalid security token');
            exit;
        }
        
        // Extract payment data from flattened POST parameters
        $payment_data = array(
            'transaction_hash' => isset($_POST['transaction_hash']) ? sanitize_text_field($_POST['transaction_hash']) : '',
            'currency' => isset($_POST['currency']) ? sanitize_text_field($_POST['currency']) : '',
            'network' => isset($_POST['network']) ? sanitize_text_field($_POST['network']) : '',
            'amount' => isset($_POST['amount']) ? sanitize_text_field($_POST['amount']) : '',
            'order_total' => isset($_POST['order_total']) ? sanitize_text_field($_POST['order_total']) : '',
            'temporary_id' => isset($_POST['temporary_id']) ? sanitize_text_field($_POST['temporary_id']) : ''
        );
        
        // Parse JSON data
        $billing_data = isset($_POST['billing_data']) ? json_decode(stripslashes($_POST['billing_data']), true) : array();
        $shipping_data = isset($_POST['shipping_data']) ? json_decode(stripslashes($_POST['shipping_data']), true) : array();
        $cart_data = isset($_POST['cart_data']) ? json_decode(stripslashes($_POST['cart_data']), true) : array();
        
        // Fallback for billing/shipping data if JSON parsing failed
        if (!is_array($billing_data)) $billing_data = array();
        if (!is_array($shipping_data)) $shipping_data = array();
        if (!is_array($cart_data)) $cart_data = array();
        
        // Debug: Log essential payment info
        error_log('CoinleyWP: Creating order - TX Hash: ' . $payment_data['transaction_hash'] . ', Amount: $' . $payment_data['order_total'] . ', Currency: ' . $payment_data['currency']);
        $start_time = microtime(true);
        
        if (empty($payment_data['transaction_hash'])) {
            error_log('CoinleyWP: Missing transaction_hash in payment_data');
            wp_send_json_error('Missing transaction hash in payment data');
            exit;
        }
        
        try {
            // Create a new WooCommerce order
            $order = wc_create_order();
            
            if (is_wp_error($order)) {
                throw new Exception('Failed to create order: ' . $order->get_error_message());
            }
            
            // Add cart items to the order
            $this->add_cart_items_to_order($order);
            
            // Set billing address
            if (!empty($billing_data)) {
                $order->set_address($billing_data, 'billing');
            }
            
            // Set shipping address
            if (!empty($shipping_data)) {
                $order->set_address($shipping_data, 'shipping');
            }
            
            // Set payment method
            $order->set_payment_method('coinleywp');
            $order->set_payment_method_title($this->title);
            
            // Calculate totals
            $order->calculate_totals();
            
            // Update order meta with payment details
            $order->update_meta_data('_coinleywp_transaction_hash', $payment_data['transaction_hash']);
            $order->update_meta_data('_coinleywp_currency', $payment_data['currency']);
            $order->update_meta_data('_coinleywp_network', $payment_data['network']);
            $order->update_meta_data('_coinleywp_amount', $payment_data['amount']);
            
            // Add order note
            $order->add_order_note(
                sprintf(
                    __('Cryptocurrency payment completed via Coinley Blocks. Currency: %1$s, Network: %2$s, Transaction Hash: %3$s', 'coinleywp'),
                    $payment_data['currency'],
                    $payment_data['network'],
                    $payment_data['transaction_hash']
                )
            );
            
            // Mark as completed and paid (this also saves the order)
            $order->payment_complete($payment_data['transaction_hash']);
            
            // Crypto payments are instant - mark as completed immediately
            $order->update_status('completed', __('Cryptocurrency payment completed instantly via Coinley', 'coinleywp'));
            
            // Debug logging
            error_log('CoinleyWP: Order created with ID: ' . $order->get_id() . ', Status: ' . $order->get_status());
            
            // Reduce stock levels
            wc_reduce_stock_levels($order->get_id());
            
            // Clear the cart
            if (WC()->cart) {
                WC()->cart->empty_cart();
            }
            
            // Performance logging
            $end_time = microtime(true);
            $execution_time = round($end_time - $start_time, 2);
            error_log("CoinleyWP: Order #{$order->get_id()} created successfully in {$execution_time} seconds");
            
            wp_send_json_success(array(
                'message' => 'Order created successfully',
                'order_id' => $order->get_id(),
                'redirect_url' => $order->get_checkout_order_received_url(),
                'execution_time' => $execution_time
            ));
            
        } catch (Exception $e) {
            error_log('CoinleyWP Blocks Order Creation Error: ' . $e->getMessage());
            wp_send_json_error('Order creation failed: ' . $e->getMessage());
        }
        
        exit;
    }

    /**
     * Add cart items to order for blocks checkout
     */
    private function add_cart_items_to_order($order) {
        if (!WC()->cart || WC()->cart->is_empty()) {
            return;
        }
        
        foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
            $product = $cart_item['data'];
            $quantity = $cart_item['quantity'];
            
            // Add item to order
            $item_id = $order->add_product(
                $product,
                $quantity,
                array(
                    'variation' => isset($cart_item['variation']) ? $cart_item['variation'] : array(),
                    'totals' => array(
                        'subtotal' => $cart_item['line_subtotal'],
                        'subtotal_tax' => $cart_item['line_subtotal_tax'],
                        'total' => $cart_item['line_total'],
                        'tax' => $cart_item['line_tax'],
                        'tax_data' => $cart_item['line_tax_data']
                    )
                )
            );
        }
        
        // Add fees
        foreach (WC()->cart->get_fees() as $fee) {
            $order->add_fee($fee);
        }
        
        // Add shipping
        foreach (WC()->cart->get_shipping_packages() as $package_key => $package) {
            if (isset($package['rates'])) {
                foreach ($package['rates'] as $rate) {
                    $order->add_shipping($rate);
                }
            }
        }
        
        // Add coupons
        foreach (WC()->cart->get_applied_coupons() as $coupon_code) {
            $coupon = new WC_Coupon($coupon_code);
            $order->apply_coupon($coupon);
        }
    }

    /**
     * Convert currency amount to USD using Fawaz Ahmed's free currency API
     *
     * @param float $amount Amount to convert
     * @param string $from_currency Source currency code
     * @return array|WP_Error Conversion result or error
     */
    private function convert_to_usd($amount, $from_currency) {
        // If already USD, no conversion needed
        if ($from_currency === 'USD') {
            return [
                'original_amount' => $amount,
                'original_currency' => $from_currency,
                'converted_amount' => $amount,
                'converted_currency' => 'USD',
                'exchange_rate' => 1.0,
                'conversion_info' => null
            ];
        }

        // Check cache first (cache for 1 hour)
        $cache_key = 'coinleywp_rate_' . strtolower($from_currency) . '_usd';
        $cached_rate = get_transient($cache_key);
        
        if ($cached_rate !== false) {
            $converted_amount = $amount / $cached_rate;
            return [
                'original_amount' => $amount,
                'original_currency' => $from_currency,
                'converted_amount' => round($converted_amount, 2),
                'converted_currency' => 'USD',
                'exchange_rate' => (1 / $cached_rate),
                'conversion_info' => sprintf(
                    '%s %s → $%s USD (Rate: 1 USD = %s %s)',
                    number_format($amount, 2),
                    $from_currency,
                    number_format($converted_amount, 2),
                    number_format($cached_rate, 4),
                    $from_currency
                )
            ];
        }

        // Fetch fresh rates from Fawaz Ahmed's API
        $api_url = 'https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json';
        
        $response = wp_remote_get($api_url, [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'CoinleyWP/1.0'
            ]
        ]);

        if (is_wp_error($response)) {
            error_log('CoinleyWP: Currency API request failed - ' . $response->get_error_message());
            return new WP_Error('api_error', 'Currency conversion service unavailable');
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!$data || !isset($data['usd'])) {
            error_log('CoinleyWP: Invalid currency API response');
            return new WP_Error('invalid_response', 'Invalid currency data received');
        }

        $currency_key = strtolower($from_currency);
        if (!isset($data['usd'][$currency_key])) {
            error_log('CoinleyWP: Currency not found - ' . $from_currency);
            return new WP_Error('currency_not_found', 'Currency not supported: ' . $from_currency);
        }

        $rate = $data['usd'][$currency_key]; // How many units of from_currency = 1 USD
        $converted_amount = $amount / $rate;

        // Cache the rate for 1 hour
        set_transient($cache_key, $rate, HOUR_IN_SECONDS);

        // Log successful conversion
        error_log(sprintf(
            'CoinleyWP: Currency conversion - %s %s → $%s USD (Rate: 1 USD = %s %s)',
            $amount,
            $from_currency,
            round($converted_amount, 2),
            $rate,
            $from_currency
        ));

        return [
            'original_amount' => $amount,
            'original_currency' => $from_currency,
            'converted_amount' => round($converted_amount, 2),
            'converted_currency' => 'USD',
            'exchange_rate' => (1 / $rate),
                         'conversion_info' => sprintf(
                 '%s %s → $%s USD (Rate: 1 USD = %s %s)',
                 number_format($amount, 2),
                 $from_currency,
                 number_format($converted_amount, 2),
                 number_format($rate, 4),
                 $from_currency
             )
         ];
     }

    /**
     * Handle AJAX request to test currency conversion
     */
    public function test_currency_conversion() {
        try {
            // Check nonce - try both WooCommerce settings nonce and admin nonce
            $nonce_valid = false;
            if (isset($_POST['nonce'])) {
                $nonce_valid = wp_verify_nonce($_POST['nonce'], 'woocommerce-settings') || 
                              wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce');
            }
            
            if (!$nonce_valid) {
                wp_send_json_error('Invalid security token. Please refresh the page and try again.');
                return;
            }
            
            if (!current_user_can('manage_woocommerce')) {
                wp_send_json_error('Insufficient permissions to perform this action.');
                return;
            }
            
            $test_amount = 1000; // Test with 1000 units of store currency
            $store_currency = get_woocommerce_currency();
            
            // Validate store currency
            if (empty($store_currency)) {
                wp_send_json_error('Store currency is not configured. Please check your WooCommerce settings.');
                return;
            }
            
            $start_time = microtime(true);
            $conversion_result = $this->convert_to_usd($test_amount, $store_currency);
            $end_time = microtime(true);
            
            $response_time = round(($end_time - $start_time) * 1000, 2);
            
            if (is_wp_error($conversion_result)) {
                $error_message = $conversion_result->get_error_message();
                
                // Provide more helpful error messages
                if (strpos($error_message, 'HTTP request failed') !== false) {
                    $error_message = 'Unable to connect to currency exchange service. Please check your internet connection or try again later.';
                } elseif (strpos($error_message, 'Invalid response') !== false) {
                    $error_message = 'Currency exchange service returned invalid data. This may be a temporary issue.';
                }
                
                wp_send_json_error($error_message);
                return;
            }
            
            // Ensure conversion_result is properly formatted
            if (!is_array($conversion_result)) {
                wp_send_json_error('Invalid conversion result format. Please try again.');
                return;
            }
            
            $message = 'Currency conversion is working perfectly!';
            if ($store_currency === 'USD') {
                $message = 'Your store already uses USD - no conversion needed!';
            }
            
            // Safe fallback for conversion info
            $conversion_info = '';
            if (isset($conversion_result['conversion_info']) && !empty($conversion_result['conversion_info'])) {
                $conversion_info = $conversion_result['conversion_info'];
            } else {
                $conversion_info = sprintf('%s %s = %s USD (1:1 ratio)', 
                    number_format($test_amount, 2), 
                    $store_currency, 
                    number_format($test_amount, 2)
                );
            }
            
            wp_send_json_success([
                'message' => $message,
                'conversion_info' => $conversion_info,
                'response_time' => $response_time . 'ms',
                'api_source' => 'Fawaz Ahmed\'s Currency API (Free)',
                'cache_status' => get_transient('coinleywp_rate_' . strtolower($store_currency) . '_usd') ? 'Used cached rate' : 'Fetched fresh rate'
            ]);
            
        } catch (Exception $e) {
            error_log('CoinleyWP Currency Conversion Error: ' . $e->getMessage());
            wp_send_json_error('An unexpected error occurred during currency conversion. Please try again or contact support if the issue persists.');
        }
    }

    /**
     * Handle updating fee settings via AJAX
     * REMOVED: Fee settings are now handled through standard admin settings save
     */

    /**
     * Old AJAX handlers removed - CoinleyVanilla SDK handles all payment processing
     * The following methods were removed as they're no longer needed:
     * - handle_payment_processing()
     * - handle_wallet_connection()  
     * - handle_payment_cancellation()
     * - handle_create_coinley_payment()
     * - handle_process_coinley_payment()
     */


    /**
     * Maybe refresh fee settings on admin pages
     */
    public function maybe_refresh_fee_settings() {
        // Only refresh on WooCommerce settings pages
        if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'wc-settings' && 
            isset($_GET['tab']) && $_GET['tab'] === 'checkout' && 
            isset($_GET['section']) && $_GET['section'] === 'coinleywp') {
            
            if ($this->api_key && $this->api_secret) {
                $this->refresh_fee_settings();
            }
        }
    }

    /**
     * Refresh fee settings from the API using the same endpoint as admin dashboard
     */
    private function refresh_fee_settings() {
        try {
            if ($this->debug) {
                error_log('CoinleyWP: Attempting to refresh fee settings from merchant dashboard...');
            }
            
            // Use the same API call as admin dashboard
            $response = $this->api->get_comprehensive_merchant_data();
            
            if ($this->debug) {
                error_log('CoinleyWP: Comprehensive merchant data response: ' . print_r($response, true));
            }
            
            if (!is_wp_error($response) && isset($response['merchant'])) {
                $merchant = $response['merchant'];
                
                // Get fee percentage from merchant data (same as dashboard)
                $fee_percentage = floatval($merchant['customFeePercentage'] ?? 0.0175);
                $fee_charged_to = $merchant['feeChargedTo'] ?? 'customer';
                
                // Update instance variables
                $this->current_fee_percentage = $fee_percentage;
                $this->fee_charged_to = $fee_charged_to;
                
                // Update the settings in WP options
                $this->update_option('current_fee_percentage', $this->current_fee_percentage);
                $this->update_option('fee_charged_to', $this->fee_charged_to);
                
                if ($this->debug) {
                    error_log('CoinleyWP: Fee settings updated from comprehensive merchant data - Percentage: ' . $this->current_fee_percentage . ', Charged to: ' . $this->fee_charged_to);
                }
            } else {
                if ($this->debug) {
                    if (is_wp_error($response)) {
                        error_log('CoinleyWP: Comprehensive merchant data API error: ' . $response->get_error_message());
                    } else {
                        error_log('CoinleyWP: Comprehensive merchant data response missing merchant data');
                    }
                }
            }
        } catch (Exception $e) {
            if ($this->debug) {
                error_log('CoinleyWP: Failed to refresh fee settings: ' . $e->getMessage());
                wc_get_logger()->debug(
                    'Failed to refresh fee settings: ' . $e->getMessage(),
                    array('source' => 'coinleywp')
                );
            }
        }
    }
} 