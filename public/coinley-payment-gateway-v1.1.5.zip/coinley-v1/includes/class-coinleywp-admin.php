<?php
/**
 * Coinley WP Admin Class
 * 
 * Handles admin interface, settings, and transaction management
 */

if (!defined('ABSPATH')) {
    exit;
}

class CoinleyWP_Admin {
    
    /**
     * API instance
     */
    private $api;
    
    /**
     * Gateway settings
     */
    private $gateway_settings;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->gateway_settings = get_option('woocommerce_coinleywp_settings', array());
        
        // Initialize API if credentials are available
        if (!empty($this->gateway_settings['api_key']) && !empty($this->gateway_settings['api_secret'])) {
            require_once COINLEYWP_PLUGIN_DIR . 'includes/class-coinleywp-api.php';
            $testmode = isset($this->gateway_settings['testmode']) && $this->gateway_settings['testmode'] === 'yes';
            $debug = isset($this->gateway_settings['debug']) && $this->gateway_settings['debug'] === 'yes';
            $this->api = new CoinleyWP_API(
                $this->gateway_settings['api_key'],
                $this->gateway_settings['api_secret'],
                $testmode,
                $debug
            );
        }
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_coinleywp_fetch_transactions', array($this, 'ajax_fetch_transactions'));
        add_action('wp_ajax_coinleywp_get_transaction_details', array($this, 'ajax_get_transaction_details'));
        add_action('wp_ajax_coinleywp_fetch_dashboard_data', array($this, 'ajax_fetch_dashboard_data'));
        add_action('wp_ajax_coinleywp_update_merchant_settings', array($this, 'ajax_update_merchant_settings'));
        add_action('wp_ajax_coinleywp_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_coinleywp_regenerate_webhook_secret', array($this, 'ajax_regenerate_webhook_secret'));
        add_action('wp_ajax_coinleywp_save_network_settings', array($this, 'ajax_save_network_settings'));
        add_action('wp_ajax_coinleywp_update_wallet_addresses', array($this, 'ajax_update_wallet_addresses'));
        add_action('wp_ajax_coinleywp_check_credentials', array($this, 'ajax_check_credentials'));
        add_action('wp_ajax_coinleywp_refresh_credentials', array($this, 'ajax_refresh_credentials'));
        add_action('wp_ajax_coinleywp_clear_credentials', array($this, 'ajax_clear_credentials'));
        add_action('wp_ajax_coinleywp_refresh_wallets', array($this, 'ajax_refresh_wallets'));
        add_action('wp_ajax_coinleywp_fetch_wallets', array($this, 'ajax_fetch_wallets'));
        add_action('wp_ajax_coinleywp_save_wallets', array($this, 'ajax_save_wallets'));

        // Add validation for settings update
        add_filter('pre_update_option_woocommerce_coinleywp_settings', array($this, 'validate_settings_update'), 10, 2);
    }
    
    /**
     * Get menu icon for WordPress admin sidebar
     */
    private function get_menu_icon() {
        // Option 1: Custom SVG icon (currently active)
        $svg = '<svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="10" cy="10" r="8" stroke="currentColor" stroke-width="1.5" fill="none"/>
            <path d="M7 8h6M7 10h6M7 12h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            <circle cx="10" cy="6" r="1.5" fill="currentColor"/>
        </svg>';
        
        return 'data:image/svg+xml;base64,' . base64_encode($svg);
        
        // Option 2: WordPress Dashicon (uncomment to use instead)
        // return 'dashicons-money-alt';
    }

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main menu page
        add_menu_page(
            __('Coinley', 'coinleywp'),
            __('Coinley', 'coinleywp'),
            'manage_options',
            'coinley',
            array($this, 'dashboard_page'),
            $this->get_menu_icon(),
            56
        );
        
        // Dashboard submenu
        add_submenu_page(
            'coinley',
            __('Dashboard', 'coinleywp'),
            __('Dashboard', 'coinleywp'),
            'manage_options',
            'coinley',
            array($this, 'dashboard_page')
        );
        
        // Transactions submenu
        add_submenu_page(
            'coinley',
            __('Transactions', 'coinleywp'),
            __('Transactions', 'coinleywp'),
            'manage_options',
            'coinley-transactions',
            array($this, 'transactions_page')
        );

        // Wallet Settings submenu
        add_submenu_page(
            'coinley',
            __('Wallet Settings', 'coinleywp'),
            __('Settings', 'coinleywp'),
            'manage_options',
            'coinley-wallet-settings',
            array($this, 'wallet_settings_page')
        );
        
        /* 
        // Analytics submenu - REMOVED - Keep menu simple with just Dashboard and Transactions
        add_submenu_page(
            'coinley',
            __('Analytics', 'coinleywp'),
            __('Analytics', 'coinleywp'),
            'manage_options',
            'coinley-analytics',
            array($this, 'analytics_page')
        );
        */

        // Add onboarding page (hidden from menu)
        add_submenu_page(
            null, // No parent menu - hidden page
            __('Coinley Onboarding', 'coinleywp'),
            __('Onboarding', 'coinleywp'),
            'manage_options',
            'coinley-onboarding',
            array($this, 'onboarding_page')
        );
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        // Load on our admin pages and WooCommerce settings pages
        $load_styles = false;
        
        // Load on Coinley admin pages
        if (strpos($hook, 'coinley') !== false) {
            $load_styles = true;
        }
        
        // Load on WooCommerce settings pages (for wallet configuration styling)
        if (strpos($hook, 'woocommerce_page_wc-settings') !== false || 
            (isset($_GET['page']) && $_GET['page'] === 'wc-settings')) {
            $load_styles = true;
        }
        
        if (!$load_styles) {
            return;
        }
        
        // Enqueue enhanced admin styles with cache busting
        wp_enqueue_style(
            'coinleywp-admin-enhanced',
            COINLEYWP_PLUGIN_URL . 'assets/css/admin-enhanced.css',
            array(),
            COINLEYWP_VERSION . '-' . time()
        );
        
        // Add Bricolage Grotesque font
        wp_enqueue_style(
            'bricolage-grotesque-font',
            'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,200..800&display=swap',
            array(),
            COINLEYWP_VERSION
        );
        
        // Enqueue admin JavaScript
        wp_enqueue_script(
            'coinleywp-admin',
            COINLEYWP_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            COINLEYWP_VERSION . '-' . time(),
            true
        );
        
        // Localize script with proper nonce and AJAX URL
        wp_localize_script('coinleywp-admin', 'coinleywp_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('coinleywp_admin_nonce'),
            'is_configured' => !empty($this->gateway_settings['api_key']) && !empty($this->gateway_settings['api_secret']),
            'strings' => array(
                'loading' => __('Loading...', 'coinleywp'),
                'saving' => __('Saving...', 'coinleywp'),
                'validating' => __('Validating...', 'coinleywp'),
                'refreshing' => __('Refreshing credentials...', 'coinleywp'),
                'error' => __('Error', 'coinleywp'),
                'success' => __('Success', 'coinleywp'),
                'confirm_delete' => __('Are you sure you want to delete this item?', 'coinleywp'),
                'connection_test_success' => __('API connection successful!', 'coinleywp'),
                'connection_test_failed' => __('API connection failed', 'coinleywp'),
                'settings_saved' => __('Settings saved successfully', 'coinleywp'),
                'settings_save_failed' => __('Failed to save settings', 'coinleywp'),
                'wallets_updated' => __('Wallet addresses updated successfully!', 'coinleywp'),
                'wallets_update_failed' => __('Failed to update wallet addresses', 'coinleywp'),
                'credential_warning' => __('API Credentials Need Refresh', 'coinleywp'),
                'credential_warning_desc' => __('Your API credentials may have expired. Click the button below to refresh them.', 'coinleywp'),
                'refresh_credentials' => __('Refresh Credentials', 'coinleywp'),
                'refresh_failed' => __('Failed to refresh credentials. Please try logging in again.', 'coinleywp')
            )
        ));
    }
    
    /**
     * Dashboard page
     */
    public function dashboard_page() {
        $merchant_data = $this->get_merchant_dashboard_data();
        $stats = $this->get_payment_stats();
        $recent_transactions = $this->get_recent_transactions(5);
        
        include COINLEYWP_PLUGIN_DIR . 'includes/admin/dashboard.php';
    }
    
    /**
     * Transactions page
     */
    public function transactions_page() {
        include COINLEYWP_PLUGIN_DIR . 'includes/admin/transactions.php';
    }

    /**
     * Wallet settings page
     */
    public function wallet_settings_page() {
        require_once COINLEYWP_PLUGIN_DIR . 'includes/admin/wallet-settings.php';
    }
    
    // Settings page - REMOVED - Use WooCommerce > Settings > Payments > Coinley instead
    /*
    public function settings_page() {
        include COINLEYWP_PLUGIN_DIR . 'includes/admin/settings.php';
    }
    */
    
    // Analytics page - REMOVED - Keep menu simple with just Dashboard and Transactions
    /*
    public function analytics_page() {
        $stats = $this->get_payment_stats();
        include COINLEYWP_PLUGIN_DIR . 'includes/admin/analytics.php';
    }
    */
    
    /**
     * Onboarding page.
     */
    public function onboarding_page() {
        ?>
        <div class="wrap coinleywp-onboarding">
            <!-- Enhanced Notification Container -->
            <div id="coinleywp-notification-container"></div>
            
            <div class="coinleywp-onboarding-container">
                <div class="coinleywp-onboarding-header">
                    <img src="<?php echo COINLEYWP_PLUGIN_URL . 'assets/images/coinley-logo.svg'; ?>" alt="Coinley" class="coinleywp-logo">
                    <h1><?php _e('Welcome to Coinley!', 'coinleywp'); ?></h1>
                    <p><?php _e('Connect your Coinley merchant account to start accepting cryptocurrency payments', 'coinleywp'); ?></p>
                </div>

                <div class="coinleywp-onboarding-tabs">
                    <button class="tab-button active" data-tab="login"><?php _e('Log In', 'coinleywp'); ?></button>
                    <button class="tab-button" data-tab="register"><?php _e('Sign Up', 'coinleywp'); ?></button>
                </div>

                <div class="coinleywp-onboarding-content">
                    <!-- Login Tab -->
                    <div id="login-tab" class="tab-content active">
                        <form id="coinley-login-form" class="onboarding-form">
                            <h2><?php _e('Log In to Your Coinley Account', 'coinleywp'); ?></h2>
                            <p><?php _e('Enter your existing Coinley merchant credentials', 'coinleywp'); ?></p>
                            
                            <div class="form-group">
                                <label for="login-email"><?php _e('Email Address', 'coinleywp'); ?></label>
                                <input type="email" id="login-email" name="email" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="login-password"><?php _e('Password', 'coinleywp'); ?></label>
                                <input type="password" id="login-password" name="password" required>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="button button-primary button-large">
                                    <span class="button-text"><?php _e('Connect Account', 'coinleywp'); ?></span>
                                    <span class="spinner"></span>
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Register Tab -->
                    <div id="register-tab" class="tab-content">
                        <form id="coinley-register-form" class="onboarding-form">
                            <h2><?php _e('Create a New Coinley Account', 'coinleywp'); ?></h2>
                            <p><?php _e('Sign up for a new Coinley merchant account to start accepting payments', 'coinleywp'); ?></p>
                            
                            <div class="form-group">
                                <label for="register-email"><?php _e('Email Address', 'coinleywp'); ?></label>
                                <input type="email" id="register-email" name="email" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="register-password"><?php _e('Password', 'coinleywp'); ?></label>
                                <input type="password" id="register-password" name="password" required minlength="8">
                                <small><?php _e('Minimum 8 characters', 'coinleywp'); ?></small>
                            </div>
                            
                            <div class="business-info">
                                <h3><?php _e('Business Information', 'coinleywp'); ?></h3>
                                <div class="form-group">
                                    <label><?php _e('Business Name', 'coinleywp'); ?></label>
                                    <input type="text" value="<?php echo esc_attr(get_bloginfo('name')); ?>" readonly>
                                    <small><?php _e('Automatically detected from your WordPress site', 'coinleywp'); ?></small>
                                </div>
                                
                                <div class="form-group">
                                    <label><?php _e('Website URL', 'coinleywp'); ?></label>
                                    <input type="url" value="<?php echo esc_attr(get_site_url()); ?>" readonly>
                                    <small><?php _e('Your WordPress site URL', 'coinleywp'); ?></small>
                                </div>
                            </div>
                            
                            <div class="form-actions">
                                <button type="submit" class="button button-primary button-large">
                                    <span class="button-text"><?php _e('Create Account & Connect', 'coinleywp'); ?></span>
                                    <span class="spinner"></span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="coinleywp-onboarding-info">
                    <div class="info-card">
                        <h4>📧 <?php _e('Email Verification Required', 'coinleywp'); ?></h4>
                        <p><?php _e('After registration, you\'ll receive a verification email. You can continue with the setup, but some features may be limited until you verify your email address.', 'coinleywp'); ?></p>
                    </div>
                    <div class="info-card">
                        <h4>🔐 <?php _e('Secure API Integration', 'coinleywp'); ?></h4>
                        <p><?php _e('Your API credentials will be automatically configured in WooCommerce settings after successful authentication.', 'coinleywp'); ?></p>
                    </div>
                </div>

                <div class="coinleywp-onboarding-benefits">
                    <h3><?php _e('Why Choose Coinley?', 'coinleywp'); ?></h3>
                    <div class="benefits-grid">
                        <div class="benefit-item">
                            <span class="dashicons dashicons-money-alt"></span>
                            <h4><?php _e('Low Fees', 'coinleywp'); ?></h4>
                            <p><?php _e('Save up to 80% on transaction fees compared to traditional payment processors', 'coinleywp'); ?></p>
                        </div>
                        <div class="benefit-item">
                            <span class="dashicons dashicons-clock"></span>
                            <h4><?php _e('Instant Settlement', 'coinleywp'); ?></h4>
                            <p><?php _e('Receive payments instantly without waiting for bank processing', 'coinleywp'); ?></p>
                        </div>
                        <div class="benefit-item">
                            <span class="dashicons dashicons-shield"></span>
                            <h4><?php _e('No Chargebacks', 'coinleywp'); ?></h4>
                            <p><?php _e('Cryptocurrency payments are final and irreversible', 'coinleywp'); ?></p>
                        </div>
                        <div class="benefit-item">
                            <span class="dashicons dashicons-admin-site"></span>
                            <h4><?php _e('Global Reach', 'coinleywp'); ?></h4>
                            <p><?php _e('Accept payments from customers anywhere in the world', 'coinleywp'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="coinleywp-onboarding-footer">
                    <p><?php _e('Need help?', 'coinleywp'); ?> <a href="https://coinley.io/support" target="_blank"><?php _e('Contact Support', 'coinleywp'); ?></a></p>
                    <p><a href="<?php echo admin_url('admin.php?page=wc-settings&tab=checkout&section=coinleywp'); ?>"><?php _e('Skip and set up manually', 'coinleywp'); ?></a></p>
                </div>
            </div>
        </div>

        <style>
        .coinleywp-onboarding {
            margin: 0;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }

        .coinleywp-onboarding-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .coinleywp-onboarding-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .coinleywp-logo {
            height: 60px;
            margin-bottom: 20px;
        }

        .coinleywp-onboarding-header h1 {
            font-size: 2.5em;
            margin: 0 0 10px 0;
            color: #333;
        }

        .coinleywp-onboarding-header p {
            font-size: 1.2em;
            color: #666;
            margin: 0;
        }

        .coinleywp-onboarding-tabs {
            display: flex;
            margin-bottom: 30px;
            border-bottom: 1px solid #ddd;
        }

        .tab-button {
            background: none;
            border: none;
            padding: 15px 30px;
            font-size: 16px;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: all 0.3s ease;
        }

        .tab-button.active {
            border-bottom-color: #667eea;
            color: #667eea;
            font-weight: 600;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .onboarding-form {
            max-width: 500px;
            margin: 0 auto;
        }

        .onboarding-form h2 {
            text-align: center;
            color: #333;
            margin-bottom: 10px;
        }

        .onboarding-form > p {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }

        .form-group small {
            display: block;
            margin-top: 5px;
            color: #666;
            font-size: 14px;
        }

        .business-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 6px;
            margin: 20px 0;
        }

        .business-info h3 {
            margin: 0 0 15px 0;
            color: #333;
        }

        .form-actions {
            text-align: center;
            margin-top: 30px;
        }

        .button-large {
            padding: 15px 30px;
            font-size: 16px;
            position: relative;
        }

        .button .spinner {
            display: none;
            margin-left: 10px;
        }

        .button.loading .button-text {
            opacity: 0.7;
        }

        .button.loading .spinner {
            display: inline-block;
        }

        .coinleywp-onboarding-info {
            margin: 30px 0;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .info-card {
            background: #f0f7ff;
            border: 1px solid #d6e9ff;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
        }

        .info-card h4 {
            margin: 0 0 10px 0;
            color: #333;
            font-size: 16px;
        }

        .info-card p {
            margin: 0;
            color: #666;
            font-size: 14px;
            line-height: 1.5;
        }

        .coinleywp-onboarding-benefits {
            margin-top: 50px;
            padding-top: 30px;
            border-top: 1px solid #eee;
        }

        .coinleywp-onboarding-benefits h3 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
        }

        .benefit-item {
            text-align: center;
            padding: 20px;
        }

        .benefit-item .dashicons {
            font-size: 40px;
            color: #667eea;
            margin-bottom: 10px;
        }

        .benefit-item h4 {
            margin: 0 0 10px 0;
            color: #333;
        }

        .benefit-item p {
            margin: 0;
            color: #666;
            font-size: 14px;
            line-height: 1.4;
        }

        .coinleywp-onboarding-footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .coinleywp-onboarding-footer p {
            margin: 10px 0;
            color: #666;
        }

        .coinleywp-onboarding-footer a {
            color: #667eea;
            text-decoration: none;
        }

        .coinleywp-onboarding-footer a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .coinleywp-onboarding-container {
                padding: 20px;
                margin: 10px;
            }
            
            .coinleywp-onboarding-info {
                grid-template-columns: 1fr;
            }
            
            .benefits-grid {
                grid-template-columns: 1fr;
            }
        }
        </style>

        <script>
        jQuery(document).ready(function($) {
            // Enhanced notification system
            function showNotification(type, title, message, actions) {
                // Remove existing notifications
                $('#coinleywp-notification-container').empty();
                
                var iconMap = {
                    'success': '✓',
                    'error': '⚠',
                    'warning': '!',
                    'info': 'ℹ'
                };
                
                var notification = $(`
                    <div class="coinleywp-enhanced-notification ${type}">
                        <div class="coinleywp-enhanced-notification-header">
                            <div class="coinleywp-enhanced-notification-icon">${iconMap[type] || 'ℹ'}</div>
                            <div class="coinleywp-enhanced-notification-content">
                                <div class="coinleywp-enhanced-notification-title">${title}</div>
                                <div class="coinleywp-enhanced-notification-message">${message}</div>
                            </div>
                        </div>
                        ${actions ? `<div class="coinleywp-enhanced-notification-actions">${actions}</div>` : ''}
                        <button class="coinleywp-enhanced-notification-close">&times;</button>
                    </div>
                `);
                
                $('#coinleywp-notification-container').append(notification);
                
                // Add close button event handler
                notification.find('.coinleywp-enhanced-notification-close').on('click', function() {
                    notification.addClass('slide-out').delay(300).queue(function(){
                        $(this).remove();
                    });
                });
                
                // Auto-dismiss after 8 seconds for non-error notifications
                if (type !== 'error') {
                    setTimeout(function() {
                        notification.addClass('slide-out').delay(300).queue(function(){
                            $(this).remove();
                        });
                    }, 8000);
                }
            }
            
            // Tab switching
            $('.tab-button').click(function() {
                var tab = $(this).data('tab');
                
                $('.tab-button').removeClass('active');
                $('.tab-content').removeClass('active');
                
                $(this).addClass('active');
                $('#' + tab + '-tab').addClass('active');
                
                // Clear any existing notifications when switching tabs
                $('#coinleywp-notification-container').empty();
            });

            // Form submissions
            $('#coinley-login-form').submit(function(e) {
                e.preventDefault();
                submitForm('login');
            });

            $('#coinley-register-form').submit(function(e) {
                e.preventDefault();
                submitForm('register');
            });

            function submitForm(actionType) {
                var form = $('#coinley-' + actionType + '-form');
                var button = form.find('button[type="submit"]');
                var email = form.find('input[name="email"]').val();
                var password = form.find('input[name="password"]').val();

                if (!email || !password) {
                    showNotification('warning', 
                        '<?php _e('Missing Information', 'coinleywp'); ?>', 
                        '<?php _e('Please fill in all required fields to continue.', 'coinleywp'); ?>'
                    );
                    return;
                }

                button.addClass('loading').prop('disabled', true);
                
                // Show loading notification
                showNotification('info', 
                    '<?php _e('Connecting...', 'coinleywp'); ?>', 
                    actionType === 'login' ? '<?php _e('Logging into your Coinley account...', 'coinleywp'); ?>' : '<?php _e('Creating your Coinley account...', 'coinleywp'); ?>'
                );

                $.post(ajaxurl, {
                    action: 'coinleywp_complete_onboarding',
                    nonce: '<?php echo wp_create_nonce('coinleywp_onboarding'); ?>',
                    email: email,
                    password: password,
                    action_type: actionType
                }, function(response) {
                    if (response.success) {
                        if (response.data.requires_verification) {
                            // Registration successful but needs email verification
                            showNotification('warning', 
                                '<?php _e('Email Verification Required', 'coinleywp'); ?>', 
                                response.data.message + ' <?php _e('You can continue with the setup, but some features may be limited until you verify your email.', 'coinleywp'); ?>',
                                '<button class="coinleywp-enhanced-notice-btn-primary" onclick="window.location.href=\'' + response.data.redirect + '\'"><?php _e('Continue Setup', 'coinleywp'); ?></button>'
                            );
                        } else {
                            // Login successful
                            showNotification('success', 
                                '<?php _e('Successfully Connected!', 'coinleywp'); ?>', 
                                response.data.message,
                                '<button class="coinleywp-enhanced-notice-btn-primary" onclick="window.location.href=\'' + response.data.redirect + '\'"><?php _e('Continue to Settings', 'coinleywp'); ?></button>'
                            );
                        }
                        
                        // Redirect after a brief delay to show the notification
                        setTimeout(function() {
                            window.location.href = response.data.redirect;
                        }, 2000);
                    } else {
                        // Handle specific error cases
                        var errorMessage = response.data;
                        if (errorMessage.includes('not verified') || errorMessage.includes('verification')) {
                            showNotification('error', 
                                '<?php _e('Email Verification Required', 'coinleywp'); ?>', 
                                errorMessage + ' <?php _e('Please check your email and click the verification link, then try logging in again.', 'coinleywp'); ?>'
                            );
                        } else {
                            showNotification('error', 
                                '<?php _e('Connection Failed', 'coinleywp'); ?>', 
                                errorMessage
                            );
                        }
                        button.removeClass('loading').prop('disabled', false);
                    }
                }).fail(function() {
                    showNotification('error', 
                        '<?php _e('Connection Error', 'coinleywp'); ?>', 
                        '<?php _e('Unable to connect to Coinley servers. Please check your internet connection and try again.', 'coinleywp'); ?>'
                    );
                    button.removeClass('loading').prop('disabled', false);
                });
            }
        });
        </script>
        <?php
    }
    
    /**
     * Get merchant dashboard data
     */
    private function get_merchant_dashboard_data() {
        if (!$this->api) {
            return $this->get_mock_merchant_data();
        }
        
        try {
            $response = $this->api->get_comprehensive_merchant_data();
            
            if (is_wp_error($response)) {
                error_log('CoinleyWP: Dashboard API Error: ' . $response->get_error_message());
                return $this->get_mock_merchant_data();
            }
            
            // Extract merchant data from the comprehensive response
            if (isset($response['merchant'])) {
                // Try to get wallet data from the API
                $merchant_wallets = array();
                
                // First try to get from the comprehensive response
                if (isset($response['merchantWallets'])) {
                    $merchant_wallets = $response['merchantWallets'];
                } else {
                    // Fallback: try to fetch wallets separately
                    $wallets_response = $this->api->get_merchant_wallets();
                    if (!is_wp_error($wallets_response) && isset($wallets_response['wallets'])) {
                        // Format API wallet response to match expected format
                        foreach ($wallets_response['wallets'] as $wallet) {
                            if (isset($wallet['networkShortName']) && isset($wallet['walletAddress'])) {
                                $merchant_wallets[$wallet['networkShortName']] = $wallet['walletAddress'];
                            }
                        }
                    }
                }
                
                return array(
                    'id' => $response['merchant']['id'] ?? 'N/A',
                    'name' => $response['merchant']['businessName'] ?? $response['merchant']['firstName'] . ' ' . $response['merchant']['lastName'] ?? 'Merchant',
                    'email' => $response['merchant']['email'] ?? '',
                    'status' => $response['merchant']['status'] ?? 'active',
                    'verified' => $response['merchant']['verified'] ?? false,
                    'customFeePercentage' => $response['merchant']['customFeePercentage'] ?? 0.0175,
                    'feeChargedTo' => $response['merchant']['feeChargedTo'] ?? 'customer',
                    'merchantWallets' => $merchant_wallets,
                    'networks' => $response['networks'] ?? array(),
                    'tokens' => $response['tokens'] ?? array()
                );
            }
            
            return $this->get_mock_merchant_data();
        } catch (Exception $e) {
            error_log('CoinleyWP: Failed to fetch merchant dashboard data: ' . $e->getMessage());
            return $this->get_mock_merchant_data();
        }
    }
    
    /**
     * Get mock merchant data for fallback
     */
    private function get_mock_merchant_data() {
        return array(
            'id' => 'merchant_' . substr(md5($this->gateway_settings['api_key'] ?? 'demo'), 0, 8),
            'name' => 'Demo Merchant',
            'email' => 'demo@coinley.io',
            'status' => 'active',
            'verified' => true,
            'customFeePercentage' => 0.0175,
            'feeChargedTo' => 'customer',
            'merchantWallets' => array(
                'ethereum' => '0x1234567890123456789012345678901234567890',
                'bsc' => '0x0987654321098765432109876543210987654321',
                'polygon' => '0x1111111111111111111111111111111111111111',
                'solana' => 'Sol1234567890123456789012345678901234567890'
            ),
            'networks' => array(),
            'tokens' => array()
        );
    }

    /**
     * Get payment statistics for this merchant
     */
    private function get_payment_stats() {
        if (!$this->api) {
            return $this->get_mock_stats();
        }

        try {
            // Use merchant-specific stats endpoint: GET /api/payments/merchant/stats
            $response = $this->api->get_merchant_payment_stats();

            if (is_wp_error($response)) {
                error_log('CoinleyWP: Merchant Stats API Error: ' . $response->get_error_message());
                return $this->get_mock_stats();
            }

            // API returns: { success: true, stats: { totalPayments, completedPayments, pendingPayments, failedPayments, totalAmount, totalFeeAmount, averageAmount } }
            // Note: All amounts are returned as strings for decimal precision
            if (isset($response['success']) && $response['success'] && isset($response['stats'])) {
                $stats = $response['stats'];

                // Convert string amounts to floats (API returns strings for precision)
                $totalAmount = floatval($stats['totalAmount'] ?? '0');
                $totalFeeAmount = floatval($stats['totalFeeAmount'] ?? '0');
                $averageAmount = floatval($stats['averageAmount'] ?? '0');

                return array(
                    'totalPayments' => intval($stats['totalPayments'] ?? 0),
                    'completedPayments' => intval($stats['completedPayments'] ?? 0),
                    'pendingPayments' => intval($stats['pendingPayments'] ?? 0),
                    'failedPayments' => intval($stats['failedPayments'] ?? 0),
                    'totalVolume' => $totalAmount,
                    'totalFees' => $totalFeeAmount,
                    'averagePayment' => $averageAmount,
                    'byNetwork' => array(), // Not provided by this endpoint
                    'byCurrency' => array(), // Not provided by this endpoint
                    'monthly' => array() // Not provided by this endpoint
                );
            }

            return $this->get_mock_stats();
        } catch (Exception $e) {
            error_log('CoinleyWP: Failed to fetch payment stats: ' . $e->getMessage());
            return $this->get_mock_stats();
        }
    }
    
    /**
     * Helper methods for stats transformation
     */
    private function sum_stats_count($currency_stats) {
        return array_sum(array_column($currency_stats, 'count'));
    }
    
    private function get_status_count($status_stats, $status) {
        foreach ($status_stats as $stat) {
            if ($stat['status'] === $status) {
                return intval($stat['count']);
            }
        }
        return 0;
    }
    
    private function sum_stats_amount($currency_stats) {
        return array_sum(array_map('floatval', array_column($currency_stats, 'totalAmount')));
    }
    
    private function calculate_total_fees($currency_stats) {
        $total_fees = 0;
        foreach ($currency_stats as $stat) {
            $volume = floatval($stat['totalAmount'] ?? 0);
            $total_fees += $volume * 0.0175; // Assuming 1.75% fee rate
        }
        return $total_fees;
    }
    
    private function transform_network_stats($network_stats) {
        $transformed = array();
        foreach ($network_stats as $stat) {
            $network_name = strtolower($stat['network'] ?? 'unknown');
            $transformed[$network_name] = array(
                'count' => intval($stat['count'] ?? 0),
                'volume' => floatval($stat['totalAmount'] ?? 0)
            );
        }
        return $transformed;
    }
    
    private function transform_currency_stats($currency_stats) {
        $transformed = array();
        foreach ($currency_stats as $stat) {
            $currency = $stat['currency'] ?? 'UNKNOWN';
            $transformed[$currency] = array(
                'count' => intval($stat['count'] ?? 0),
                'volume' => floatval($stat['totalAmount'] ?? 0)
            );
        }
        return $transformed;
    }

    /**
     * Get recent transactions
     */
    private function get_recent_transactions($limit = 5) {
        if (!$this->api) {
            return array(); // Return empty array instead of mock data
        }

        try {
            $response = $this->api->get_merchant_payments(array(
                'limit' => $limit,
                'page' => 1
            ));

            if (is_wp_error($response)) {
                error_log('CoinleyWP: Recent Transactions API Error: ' . $response->get_error_message());
                return array(); // Return empty array instead of mock data
            }

            // API returns: { success: true, payments: [...], pagination: {...}, filters: {...} }
            if (isset($response['success']) && $response['success'] && isset($response['payments'])) {
                return $response['payments'];
            }

            return array(); // Return empty array instead of mock data
        } catch (Exception $e) {
            error_log('CoinleyWP: Failed to fetch recent transactions: ' . $e->getMessage());
            return array(); // Return empty array instead of mock data
        }
    }
    
    /**
     * Get transaction list with filters and pagination
     */
    private function get_transaction_list($args = array()) {
        if (!$this->api) {
            return $this->get_empty_transaction_list($args);
        }

        try {
            // Transform WordPress pagination to API format
            $api_args = array(
                'page' => isset($args['page']) ? intval($args['page']) : 1,
                'limit' => isset($args['limit']) ? intval($args['limit']) : 20
            );

            // Add filters
            if (!empty($args['status'])) {
                $api_args['status'] = $args['status'];
            }
            if (!empty($args['currency'])) {
                $api_args['currency'] = $args['currency'];
            }
            if (!empty($args['search'])) {
                $api_args['search'] = $args['search'];
            }
            if (!empty($args['start_date'])) {
                $api_args['startDate'] = $args['start_date'];
            }
            if (!empty($args['end_date'])) {
                $api_args['endDate'] = $args['end_date'];
            }

            $response = $this->api->get_merchant_payments($api_args);

            if (is_wp_error($response)) {
                error_log('CoinleyWP: Transaction List API Error: ' . $response->get_error_message());
                return $this->get_empty_transaction_list($args);
            }

            // API returns: { success: true, payments: [...], pagination: {...}, filters: {...} }
            if (isset($response['success']) && $response['success']) {
                return array(
                    'payments' => $response['payments'] ?? array(),
                    'pagination' => array(
                        'total' => $response['pagination']['totalItems'] ?? 0,
                        'total_pages' => $response['pagination']['totalPages'] ?? 1,
                        'current_page' => $response['pagination']['currentPage'] ?? 1,
                        'limit' => $api_args['limit'],
                        'offset' => ($api_args['page'] - 1) * $api_args['limit']
                    ),
                    'filters' => $response['filters'] ?? array()
                );
            }

            return $this->get_empty_transaction_list($args);
        } catch (Exception $e) {
            error_log('CoinleyWP: Failed to fetch transaction list: ' . $e->getMessage());
            return $this->get_empty_transaction_list($args);
        }
    }
    
    /**
     * Get empty transaction list (when no API or no data)
     */
    private function get_empty_transaction_list($args = array()) {
        $limit = $args['limit'] ?? 20;

        return array(
            'payments' => array(),
            'pagination' => array(
                'total' => 0,
                'total_pages' => 0,
                'current_page' => 1,
                'limit' => $limit,
                'offset' => 0
            ),
            'filters' => array(
                'currencies' => array('USDT', 'USDC', 'BNB', 'ETH', 'SOL'),
                'statuses' => array('pending', 'completed', 'failed')
            )
        );
    }

    /**
     * Get transaction details
     */
    private function get_transaction_details($payment_id) {
        if (!$this->api) {
            error_log('CoinleyWP: API not configured for transaction details');
            return array('error' => 'API not configured');
        }

        try {
            error_log('CoinleyWP: Fetching transaction details for payment_id: ' . $payment_id);
            $response = $this->api->get_payment($payment_id);

            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                $error_code = $response->get_error_code();
                error_log('CoinleyWP: Transaction Details API Error: ' . $error_message . ' (Code: ' . $error_code . ')');

                return array(
                    'error' => true,
                    'error_code' => $error_code,
                    'error_message' => $error_message,
                    'details' => 'The Coinley API returned an error. This may be a backend issue.'
                );
            }

            error_log('CoinleyWP: Transaction Details API Response: ' . json_encode($response));

            // API returns payment details directly, not wrapped in a 'payment' key
            if (isset($response['id'])) {
                error_log('CoinleyWP: Transaction details found with id: ' . $response['id']);
                return $response;
            }

            error_log('CoinleyWP: Transaction details response missing id field. Response keys: ' . (is_array($response) ? implode(', ', array_keys($response)) : 'not an array'));
            return array(
                'error' => true,
                'error_message' => 'Invalid API response format',
                'details' => 'The API response did not contain the expected payment data.'
            );
        } catch (Exception $e) {
            error_log('CoinleyWP: Exception fetching transaction details: ' . $e->getMessage());
            return array(
                'error' => true,
                'error_message' => 'Exception: ' . $e->getMessage()
            );
        }
    }
    
    /**
     * Get mock transaction details for fallback
     */
    private function get_mock_transaction_details($payment_id) {
        return array(
            'id' => $payment_id,
            'amount' => 100.00,
            'totalAmount' => 101.75,
            'feeAmount' => 1.75,
            'currency' => 'USDT',
            'status' => 'completed',
            'network' => 'Ethereum',
            'transactionHash' => '0x' . str_repeat('a', 64),
            'senderAddress' => '0x' . str_repeat('b', 40),
            'createdAt' => date('c'),
            'processedAt' => date('c'),
            'metadata' => array(
                'orderId' => 'ORDER_123',
                'customerEmail' => 'customer@example.com'
            )
        );
    }
    
    /**
     * AJAX: Fetch transactions
     */
    public function ajax_fetch_transactions() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Build query args from request
        $args = array(
            'page' => isset($_POST['page']) ? intval($_POST['page']) : 1,
            'limit' => isset($_POST['limit']) ? intval($_POST['limit']) : 20
        );
        
        // Add filters
        if (!empty($_POST['status'])) {
            $args['status'] = sanitize_text_field($_POST['status']);
        }
        if (!empty($_POST['currency'])) {
            $args['currency'] = sanitize_text_field($_POST['currency']);
        }
        if (!empty($_POST['network'])) {
            $args['network'] = sanitize_text_field($_POST['network']);
        }
        if (!empty($_POST['search'])) {
            $args['search'] = sanitize_text_field($_POST['search']);
        }
        if (!empty($_POST['start_date'])) {
            $args['start_date'] = sanitize_text_field($_POST['start_date']);
        }
        if (!empty($_POST['end_date'])) {
            $args['end_date'] = sanitize_text_field($_POST['end_date']);
        }
        
        $result = $this->get_transaction_list($args);
        
        if ($result) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error('Failed to fetch transactions');
        }
    }
    
    /**
     * AJAX: Get transaction details
     */
    public function ajax_get_transaction_details() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }

        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }

        $payment_id = isset($_POST['payment_id']) ? sanitize_text_field($_POST['payment_id']) : '';

        if (empty($payment_id)) {
            error_log('CoinleyWP: AJAX transaction details called without payment_id');
            wp_send_json_error('Payment ID is required');
            return;
        }

        error_log('CoinleyWP: AJAX fetching transaction details for payment_id: ' . $payment_id);
        $transaction_details = $this->get_transaction_details($payment_id);

        // Check if there's an error in the response
        if (isset($transaction_details['error'])) {
            error_log('CoinleyWP: Transaction details fetch failed with error');
            wp_send_json_error(array(
                'message' => $transaction_details['error_message'] ?? 'Failed to fetch transaction details',
                'details' => $transaction_details['details'] ?? 'Check server logs for more information',
                'error_code' => $transaction_details['error_code'] ?? 'unknown'
            ));
            return;
        }

        if ($transaction_details && isset($transaction_details['id'])) {
            error_log('CoinleyWP: Successfully fetched transaction details');
            wp_send_json_success($transaction_details);
        } else {
            error_log('CoinleyWP: Failed to fetch transaction details - invalid response');
            wp_send_json_error('Failed to fetch transaction details. The payment may not exist or there may be a backend issue.');
        }
    }
    
    /**
     * AJAX: Fetch dashboard data
     */
    public function ajax_fetch_dashboard_data() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        $merchant_data = $this->get_merchant_dashboard_data();
        $stats = $this->get_payment_stats();
        $recent_transactions = $this->get_recent_transactions(5);
        
        wp_send_json_success(array(
            'merchant' => $merchant_data,
            'stats' => $stats,
            'recent_transactions' => $recent_transactions
        ));
    }
    
    /**
     * AJAX: Update merchant settings
     */
    public function ajax_update_merchant_settings() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        if (!$this->api) {
            wp_send_json_error('API not configured');
            return;
        }
        
        // Extract settings data
        $settings_data = array();
        $allowed_fields = array('businessName', 'firstName', 'lastName', 'businessType', 'phone', 'industry', 'position', 'state', 'country', 'postal', 'city', 'address', 'website', 'feeChargedTo');
        
        foreach ($allowed_fields as $field) {
            if (isset($_POST[$field])) {
                $settings_data[$field] = sanitize_text_field($_POST[$field]);
            }
        }
        
        // Update wallets if provided
        if (isset($_POST['wallets']) && is_array($_POST['wallets'])) {
            $wallets = array();
            foreach ($_POST['wallets'] as $network => $address) {
                $wallets[sanitize_key($network)] = sanitize_text_field($address);
            }
            
            // Update wallets separately
            $wallet_response = $this->api->update_merchant_wallets($wallets);
            if (is_wp_error($wallet_response)) {
                wp_send_json_error('Failed to update wallet addresses: ' . $wallet_response->get_error_message());
                return;
            }
        }
        
        // Update profile
        if (!empty($settings_data)) {
            $response = $this->api->update_merchant_profile($settings_data);
            
            if (is_wp_error($response)) {
                wp_send_json_error('Failed to update merchant profile: ' . $response->get_error_message());
                return;
            }
        }
        
        wp_send_json_success('Settings updated successfully');
    }
    
    /**
     * AJAX: Test API connection
     */
    public function ajax_test_connection() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        if (!$this->api) {
            wp_send_json_error('API not configured');
            return;
        }
        
        try {
            $response = $this->api->get_merchant_dashboard();
            
            if (is_wp_error($response)) {
                wp_send_json_error('Connection failed: ' . $response->get_error_message());
                return;
            }
            
            $merchant_name = 'Unknown';
            if (isset($response['merchant'])) {
                $merchant = $response['merchant'];
                $merchant_name = $merchant['businessName'] ?? $merchant['firstName'] . ' ' . $merchant['lastName'] ?? 'Merchant';
            }
            
            wp_send_json_success(array(
                'message' => sprintf(__('Connection successful! Connected as: %s', 'coinleywp'), $merchant_name),
                'merchant_data' => $response['merchant'] ?? null
            ));
            
        } catch (Exception $e) {
            error_log('CoinleyWP: Test Connection Error: ' . $e->getMessage());
            wp_send_json_error('Connection test failed: ' . $e->getMessage());
        }
    }
    
    /**
     * AJAX: Regenerate webhook secret
     */
    public function ajax_regenerate_webhook_secret() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Generate new webhook secret
        $new_secret = wp_generate_password(32, false);
        
        // Update the gateway settings
        $gateway_settings = get_option('woocommerce_coinleywp_settings', array());
        $gateway_settings['webhook_secret'] = $new_secret;
        update_option('woocommerce_coinleywp_settings', $gateway_settings);
        
        wp_send_json_success(array(
            'secret' => $new_secret,
            'message' => __('Webhook secret regenerated successfully', 'coinleywp')
        ));
    }
    
    /**
     * AJAX: Save network settings
     */
    public function ajax_save_network_settings() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        $networks = isset($_POST['networks']) ? $_POST['networks'] : array();
        
        if (!is_array($networks)) {
            wp_send_json_error('Invalid network data');
            return;
        }
        
        // Sanitize network settings
        $sanitized_networks = array();
        foreach ($networks as $network => $enabled) {
            $sanitized_networks[sanitize_key($network)] = (bool) $enabled;
        }
        
        // Save to WordPress options
        update_option('coinleywp_enabled_networks', $sanitized_networks);
        
        // If API is available, try to sync with Coinley backend
        if ($this->api) {
            try {
                // This would be a custom endpoint to update network preferences
                // For now, we'll just save locally
                error_log('CoinleyWP: Network settings saved: ' . print_r($sanitized_networks, true));
            } catch (Exception $e) {
                error_log('CoinleyWP: Failed to sync network settings with API: ' . $e->getMessage());
            }
        }
        
        wp_send_json_success(array(
            'message' => __('Network settings saved successfully', 'coinleywp'),
            'networks' => $sanitized_networks
        ));
    }
    
    /**
     * AJAX: Update wallet addresses
     */
    public function ajax_update_wallet_addresses() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            $this->log('Invalid nonce in wallet update request', 'error', array('force_log' => true));
            wp_send_json_error('Invalid security token');
            return;
        }
        
        if (!$this->api) {
            $this->log('API not configured for wallet update', 'error', array('force_log' => true));
            wp_send_json_error('API not configured. Please configure your API credentials first.');
            return;
        }
        
        // Get wallet data
        $wallets = isset($_POST['wallets']) ? $_POST['wallets'] : array();
        
        if (empty($wallets)) {
            $this->log('Empty wallet data received', 'error', array('force_log' => true));
            wp_send_json_error('No wallet addresses provided');
            return;
        }

        $this->log('Processing wallet update request', 'info', array(
            'wallet_count' => count($wallets),
            'networks' => array_keys($wallets),
            'force_log' => true
        ));

        // Sanitize and format wallet addresses
        $formatted_wallets = array();
        foreach ($wallets as $network => $data) {
            $network = sanitize_key($network);
            
            // Handle both simple addresses and complex wallet data
            if (is_array($data)) {
                $formatted_wallets[$network] = array(
                    'address' => sanitize_text_field($data['address']),
                    'supportedTokens' => isset($data['supportedTokens']) ? array_map('sanitize_text_field', $data['supportedTokens']) : array()
                );
            } else {
                $address = sanitize_text_field($data);
                if (!empty($address)) {
                    $formatted_wallets[$network] = $address;
                }
            }
        }

        // First check API credentials
        $this->log('Checking API credentials before wallet update', 'debug', array('force_log' => true));
        $check_response = $this->api->ensure_valid_credentials();
        if (is_wp_error($check_response)) {
            $this->log('API credential check failed', 'error', array(
                'error' => $check_response->get_error_message(),
                'code' => $check_response->get_error_code(),
                'force_log' => true
            ));
            wp_send_json_error('API credentials check failed: ' . $check_response->get_error_message());
            return;
        }

        // Update wallets
        $this->log('Sending wallet update request', 'info', array(
            'formatted_wallet_count' => count($formatted_wallets),
            'networks' => array_keys($formatted_wallets),
            'force_log' => true
        ));
        
        $response = $this->api->update_merchant_wallets($formatted_wallets);
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            $error_code = $response->get_error_code();
            
            $this->log('Wallet update failed', 'error', array(
                'error' => $error_message,
                'code' => $error_code,
                'force_log' => true
            ));
            
            if ($error_code === 'invalid_credentials') {
                // Try to refresh credentials automatically
                $this->log('Attempting credential refresh', 'info', array('force_log' => true));
                $refresh_response = $this->api->refresh_credentials();
                if ($refresh_response) {
                    // Retry wallet update with fresh credentials
                    $this->log('Retrying wallet update after credential refresh', 'info', array('force_log' => true));
                    $response = $this->api->update_merchant_wallets($formatted_wallets);
                    if (!is_wp_error($response)) {
                        $this->log('Wallet update successful after credential refresh', 'info', array('force_log' => true));
                        wp_send_json_success('Wallet addresses updated successfully after credential refresh');
                        return;
                    }
                }
                $this->log('Credential refresh failed', 'error', array('force_log' => true));
                wp_send_json_error('Failed to update wallet addresses. Please try logging in again.');
                return;
            }
            wp_send_json_error('Failed to update wallet addresses: ' . $error_message);
            return;
        }
        
        $this->log('Wallet update completed successfully', 'info', array('force_log' => true));
        wp_send_json_success('Wallet addresses updated successfully');
    }
    
    /**
     * AJAX: Check credentials
     */
    public function ajax_check_credentials() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }

        if (!$this->api) {
            wp_send_json_error('API not configured');
            return;
        }

        try {
            // Get current wallet status
            $wallet_response = $this->api->get_merchant_wallets();
            
            if (is_wp_error($wallet_response)) {
                if ($wallet_response->get_error_code() === 'invalid_credentials') {
                    // Try to refresh credentials
                    $refresh_response = $this->api->refresh_credentials();
                    if ($refresh_response) {
                        // Retry wallet fetch with fresh credentials
                        $wallet_response = $this->api->get_merchant_wallets();
                        if (!is_wp_error($wallet_response)) {
                            wp_send_json_success($wallet_response);
                            return;
                        }
                    }
                }
                wp_send_json_error($wallet_response->get_error_message());
                return;
            }

            wp_send_json_success($wallet_response);
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * AJAX: Refresh API credentials
     */
    public function ajax_refresh_credentials() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        check_ajax_referer('coinleywp_admin_nonce', 'nonce');
        
        if (!$this->api) {
            wp_send_json_error('API not configured');
            return;
        }
        
        try {
            if ($this->api->refresh_credentials()) {
                wp_send_json_success();
            } else {
                wp_send_json_error('Failed to refresh credentials');
            }
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }
    
    /**
     * Clear stored API credentials
     */
    private function clear_stored_credentials() {
        $settings = get_option('woocommerce_coinleywp_settings', array());
        $settings['api_key'] = '';
        $settings['api_secret'] = '';
        update_option('woocommerce_coinleywp_settings', $settings);
    }

    /**
     * AJAX: Clear credentials and force relogin
     */
    public function ajax_clear_credentials() {
        // Check user capabilities
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        $this->clear_stored_credentials();
        wp_send_json_success('Credentials cleared. Please log in again.');
    }
    
    /**
     * Get mock statistics for demo purposes
     */
    private function get_mock_stats() {
        return array(
            'totalPayments' => 47,
            'completedPayments' => 43,
            'pendingPayments' => 3,
            'failedPayments' => 1,
            'totalVolume' => 15420.50,
            'totalFees' => 269.86,
            'byNetwork' => array(
                'ethereum' => array('count' => 25, 'volume' => 8500.00),
                'bsc' => array('count' => 15, 'volume' => 4200.50),
                'polygon' => array('count' => 7, 'volume' => 2720.00)
            ),
            'byCurrency' => array(
                'USDT' => array('count' => 28, 'volume' => 9800.00),
                'USDC' => array('count' => 12, 'volume' => 3620.50),
                'BNB' => array('count' => 7, 'volume' => 2000.00)
            ),
            'monthly' => array(
                array('month' => 'Jan 2024', 'count' => 15, 'totalAmount' => 1500.00),
                array('month' => 'Feb 2024', 'count' => 25, 'totalAmount' => 2800.00),
                array('month' => 'Mar 2024', 'count' => 32, 'totalAmount' => 3120.50)
            )
        );
    }
    
    /**
     * Get mock transactions for demo purposes
     */
    private function get_mock_transactions($limit = 10) {
        $currencies = array('USDT', 'USDC', 'BNB', 'ETH', 'SOL');
        $networks = array('ethereum', 'bsc', 'polygon', 'solana');
        $statuses = array('completed', 'pending', 'processing', 'failed');
        $amounts = array(50.00, 75.25, 89.99, 120.50, 150.00, 200.75, 250.00, 300.25, 450.00, 500.75, 750.00, 1000.00);
        
        $mock_transactions = array();
        
        for ($i = 1; $i <= $limit; $i++) {
            $currency = $currencies[array_rand($currencies)];
            $network = $networks[array_rand($networks)];
            $status = $statuses[array_rand($statuses)];
            $amount = $amounts[array_rand($amounts)];
            
            // Adjust network based on currency
            if ($currency === 'SOL') {
                $network = 'solana';
            } elseif ($currency === 'BNB') {
                $network = 'bsc';
            }
            
            $transaction = array(
                'id' => 'pay_' . substr(md5($i . time()), 0, 10),
                'amount' => $amount,
                'currency' => $currency,
                'network' => $network,
                'status' => $status,
                'createdAt' => date('c', strtotime("-{$i} hours")),
                'totalAmount' => $amount + ($amount * 0.0175),
                'feeAmount' => $amount * 0.0175
            );
            
            // Add transaction hash for completed/processing transactions
            if (in_array($status, array('completed', 'processing'))) {
                $transaction['transactionHash'] = '0x' . substr(md5('tx' . $i . time()), 0, 64);
                if ($status === 'completed') {
                    $transaction['processedAt'] = date('c', strtotime("-{$i} hours") + rand(300, 3600));
                    $transaction['confirmations'] = rand(12, 100);
                }
            }
            
            $mock_transactions[] = $transaction;
        }
        
        return $mock_transactions;
    }

    /**
     * Log admin interactions
     *
     * @param string $message The log message
     * @param string $level The log level (debug, info, error)
     * @param array $context Additional context
     */
    private function log($message, $level = 'debug', $context = array()) {
        // Format the log entry
        $log_entry = sprintf(
            "[%s] [%s] %s\nContext: %s\n",
            date('Y-m-d H:i:s'),
            strtoupper($level),
            $message,
            print_r($context, true)
        );
        
        // Add basic context
        $context['source'] = 'coinleywp_admin';
        $context['api_configured'] = !empty($this->api);
        
        if ($this->api) {
            $settings = get_option('woocommerce_coinleywp_settings', array());
            $context['api_key_set'] = !empty($settings['api_key']);
            $context['api_secret_set'] = !empty($settings['api_secret']);
            $context['test_mode'] = !empty($settings['testmode']);
        }
        
        // Log to WooCommerce if available
        if (function_exists('wc_get_logger')) {
            $logger = wc_get_logger();
            
            switch ($level) {
                case 'error':
                    $logger->error($message, $context);
                    break;
                case 'info':
                    $logger->info($message, $context);
                    break;
                default:
                    $logger->debug($message, $context);
            }
        }
        
        // Always log credential issues to file
        if ($level === 'error' || 
            (isset($context['force_log']) && $context['force_log']) || 
            (strpos(strtolower($message), 'credential') !== false)) {
            
            $log_file = WP_CONTENT_DIR . '/coinley-debug.log';
            error_log($log_entry . "\n", 3, $log_file);
            
            // Also log to PHP error log for errors
            if ($level === 'error') {
                error_log('CoinleyWP Admin Error: ' . $message . ' Context: ' . print_r($context, true));
            }
        }
    }
    
    /**
     * AJAX: Refresh wallets from API
     */
    public function ajax_refresh_wallets() {
        // Check user permissions
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error('Insufficient permissions');
            return;
        }
        
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'coinleywp_refresh_wallets')) {
            wp_send_json_error('Invalid security token');
            return;
        }
        
        // Get gateway instance
        $settings = get_option('woocommerce_coinleywp_settings', array());
        $gateway = new CoinleyWP_Gateway();
        
        // Clear wallet cache
        delete_transient('coinleywp_merchant_wallets');
        
        // Fetch fresh wallet data
        $wallets = $gateway->get_merchant_wallets();
        
        if (!empty($wallets)) {
            wp_send_json_success(array(
                'message' => 'Wallets refreshed successfully',
                'wallets' => $wallets
            ));
        } else {
            wp_send_json_error('Failed to refresh wallets. Please check your API credentials.');
        }
    }
    
    /**
     * Validate settings update to prevent tampering with sensitive fields
     * 
     * @param array $value New settings values
     * @param array $old_value Current settings values
     * @return array Validated settings
     */
    public function validate_settings_update($value, $old_value) {
        // If we're in the API authentication flow, allow the update
        if (isset($_POST['woocommerce_coinleywp_merchant_email']) && isset($_POST['woocommerce_coinleywp_merchant_password'])) {
            return $value;
        }
        
        // Prevent manual tampering with sensitive fields
        $protected_fields = array('api_key', 'api_secret', 'webhook_secret');
        
        foreach ($protected_fields as $field) {
            if (isset($old_value[$field]) && isset($value[$field])) {
                // If the field value has changed and we're not in authorized update context
                if ($value[$field] !== $old_value[$field]) {
                    // Check if this is an authorized update (webhook regeneration, etc.)
                    if (!$this->is_authorized_credential_update($field)) {
                        // Restore the original value
                        $value[$field] = $old_value[$field];
                        
                        // Add admin notice
                        add_action('admin_notices', function() use ($field) {
                            echo '<div class="notice notice-error"><p>';
                            printf(__('Security Notice: Direct modification of %s is not allowed. Please use the proper authentication flow.', 'coinleywp'), $field);
                            echo '</p></div>';
                        });
                    }
                }
            }
        }
        
        return $value;
    }
    
    /**
     * Check if the current request is an authorized credential update
     * 
     * @param string $field The field being updated
     * @return bool True if authorized, false otherwise
     */
    private function is_authorized_credential_update($field) {
        // Check if this is a webhook secret regeneration
        if ($field === 'webhook_secret' && isset($_POST['action']) && $_POST['action'] === 'coinleywp_regenerate_webhook_secret') {
            return wp_verify_nonce($_POST['nonce'], 'coinleywp_admin_nonce');
        }
        
        // Check if this is coming from the Coinley API authentication
        if (in_array($field, array('api_key', 'api_secret')) && defined('DOING_AJAX') && DOING_AJAX) {
            return isset($_POST['action']) && $_POST['action'] === 'coinleywp_merchant_login';
        }
        
        return false;
    }

    /**
     * AJAX: Fetch wallet addresses from Coinley API
     */
    public function ajax_fetch_wallets() {
        check_ajax_referer('coinley_wallet_settings_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('Insufficient permissions', 'coinleywp')
            ));
        }

        if (!$this->api) {
            wp_send_json_error(array(
                'message' => __('API not initialized. Please configure API credentials.', 'coinleywp')
            ));
        }

        // Use the same method as dashboard to get merchant data
        $merchant_data = $this->get_merchant_dashboard_data();

        // Extract wallet addresses
        $wallets = array();
        if (isset($merchant_data['merchantWallets']) && is_array($merchant_data['merchantWallets'])) {
            foreach ($merchant_data['merchantWallets'] as $network => $wallet_data) {
                if (is_array($wallet_data) && isset($wallet_data['address'])) {
                    $wallets[$network] = $wallet_data['address'];
                } elseif (is_array($wallet_data) && isset($wallet_data['walletAddress'])) {
                    $wallets[$network] = $wallet_data['walletAddress'];
                } elseif (is_string($wallet_data)) {
                    $wallets[$network] = $wallet_data;
                }
            }
        }

        wp_send_json_success(array(
            'wallets' => $wallets
        ));
    }

    /**
     * AJAX: Save wallet addresses to Coinley API
     */
    public function ajax_save_wallets() {
        check_ajax_referer('coinley_wallet_settings_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array(
                'message' => __('Insufficient permissions', 'coinleywp')
            ));
        }

        if (!$this->api) {
            wp_send_json_error(array(
                'message' => __('API not initialized. Please configure API credentials.', 'coinleywp')
            ));
        }

        $wallets_data = isset($_POST['wallets']) ? $_POST['wallets'] : array();

        if (empty($wallets_data)) {
            wp_send_json_error(array(
                'message' => __('No wallet addresses provided', 'coinleywp')
            ));
        }

        // Supported tokens per network (only USDT and USDC)
        $network_tokens = array(
            'ethereum' => array('USDT', 'USDC'),
            'bsc' => array('USDT', 'USDC'),
            'polygon' => array('USDT', 'USDC'),
            'arbitrum' => array('USDT', 'USDC'),
            'optimism' => array('USDT', 'USDC'),
            'avalanche' => array('USDT', 'USDC'),
            'celo' => array('USDT', 'USDC'),
            'base' => array('USDT', 'USDC')
        );

        // Validate and format wallet addresses
        $validated_wallets = array();
        foreach ($wallets_data as $network => $address) {
            $address = sanitize_text_field($address);

            if (empty($address)) {
                continue; // Skip empty addresses
            }

            // Validate EVM address format
            if (!preg_match('/^0x[a-fA-F0-9]{40}$/', $address)) {
                wp_send_json_error(array(
                    'message' => sprintf(__('Invalid wallet address format for %s network', 'coinleywp'), $network)
                ));
            }

            $tokens = isset($network_tokens[$network]) ? $network_tokens[$network] : array('USDT', 'USDC');

            $validated_wallets[] = array(
                'networkShortName' => $network,
                'walletAddress' => $address,
                'supportedTokens' => $tokens
            );
        }

        if (empty($validated_wallets)) {
            wp_send_json_error(array(
                'message' => __('At least one wallet address is required', 'coinleywp')
            ));
        }

        // Use the update_merchant_wallets API method
        $response = $this->api->update_merchant_wallets(array(
            'wallets' => $validated_wallets
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array(
                'message' => __('Failed to save wallet addresses: ', 'coinleywp') . $response->get_error_message()
            ));
        }

        wp_send_json_success(array(
            'message' => __('Wallet addresses saved successfully!', 'coinleywp'),
            'wallets' => $response['wallets'] ?? array()
        ));
    }
} 