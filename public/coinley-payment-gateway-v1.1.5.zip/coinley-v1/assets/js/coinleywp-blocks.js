const settings = window.wc.wcSettings.getSetting( 'coinleywp_data', {} );

const label = window.wp.htmlEntities.decodeEntities( settings.title ) || 'Pay with Cryptocurrency';
const { createElement, useEffect } = window.wp.element;

const Content = (props) => {
    const { eventRegistration, emitResponse } = props;
    const { onPaymentSetup, onPaymentProcessing } = eventRegistration;

    // Handle payment setup
    useEffect(() => {
        const unsubscribe = onPaymentSetup(() => {
            // No validation needed - everything happens in modal
            return {
                type: emitResponse.responseTypes.SUCCESS,
                meta: {
                    paymentMethodData: {
                        coinleywp_modal_payment: true,
                    },
                },
            };
        });

        return unsubscribe;
    }, [onPaymentSetup, emitResponse.responseTypes]);

    // Handle payment processing (this is where we trigger the modal)
    useEffect(() => {
        const unsubscribe = onPaymentProcessing(() => {
            // Create a promise that will be resolved when payment is complete
            return new Promise((resolve) => {
                // For blocks, we need to trigger CoinleyVanilla SDK directly

                // Get order total from WooCommerce blocks store
                let orderTotal = 100.00; // Default demo amount

                try {
                    // Try to get the actual total from WooCommerce blocks store
                    const store = window.wp?.data?.select('wc/store/cart');
                    if (store) {
                        const cartTotals = store.getCartTotals();
                        if (cartTotals && cartTotals.total_price) {
                            orderTotal = parseFloat((cartTotals.total_price / 100).toFixed(2)); // Convert from cents
                        }
                    }
                } catch (e) {
                    // Could not get cart total from store, using demo amount
                }

                // Use USD converted amount if available from coinleyParams
                if (window.coinleyParams && window.coinleyParams.total) {
                    orderTotal = parseFloat(window.coinleyParams.total);
                }

                // Get customer email from store if available
                let customerEmail = 'customer@example.com'; // Default
                try {
                    const store = window.wp?.data?.select('wc/store/cart');
                    const billingAddress = store?.getBillingAddress?.();
                    if (billingAddress?.email) {
                        customerEmail = billingAddress.email;
                    }
                } catch (e) {
                    // Could not get customer email, using default
                }

                // Trigger CoinleyVanilla SDK directly
                setTimeout(() => {
                    // Trigger the CoinleyVanilla integration
                    if (window.coinleyVanillaActive && typeof window.processCoinleyCheckout === 'function') {
                        window.processCoinleyCheckout(orderTotal, customerEmail, resolve, emitResponse);
                    } else {
                        // Fallback to direct SDK call if available
                        window.triggerCoinleyVanillaCheckout && window.triggerCoinleyVanillaCheckout({
                            amount: orderTotal,
                            customerEmail: customerEmail,
                            orderId: 'blocks_' + Date.now()
                        }, resolve, emitResponse);
                    }
                }, 100);

                // Note: CoinleyVanilla SDK handles all callbacks directly in processCoinleyCheckout
                // No need for custom event listeners - the resolve function is called directly

                // Fallback timeout in case something goes wrong
                setTimeout(() => {
                    resolve({
                        type: emitResponse.responseTypes.ERROR,
                        message: 'Payment process timeout. Please try again.'
                    });
                }, 300000); // 5 minute timeout

            });
        });

        return unsubscribe;
    }, [onPaymentProcessing, emitResponse.responseTypes]);

    const description = window.wp.htmlEntities.decodeEntities(settings.description || '');

    // Just show description, no form fields (DePay style)
    return createElement('div', {
        className: 'coinleywp-payment-description'
    }, [
        // Description
        description && createElement('div', {
            key: 'description',
            dangerouslySetInnerHTML: { __html: description },
            style: { margin: '10px 0', color: '#666' }
        }),

        // Test mode notice
        settings.testmode === 'yes' && createElement('div', {
            key: 'testmode',
            style: {
                background: '#fff3cd',
                border: '1px solid #ffeaa7',
                padding: '10px',
                margin: '10px 0',
                borderRadius: '4px',
                color: '#856404'
            }
        }, [
            createElement('strong', { key: 'testmode-label' }, 'TEST MODE ENABLED'),
            ' - Use test cryptocurrencies only'
        ])
    ]);
};

const Block_Gateway = {
    name: 'coinleywp',
    label: label,
    content: Object( window.wp.element.createElement )( Content, null ),
    edit: Object( window.wp.element.createElement )( Content, null ),
    canMakePayment: () => true,
    ariaLabel: label,
    supports: {
        features: settings.supports || [],
    },
};

window.wc.wcBlocksRegistry.registerPaymentMethod( Block_Gateway );
