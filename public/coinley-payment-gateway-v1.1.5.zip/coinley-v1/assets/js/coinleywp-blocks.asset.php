<?php return array(
    'dependencies' => array(
        'wc-blocks-registry',
        'wc-settings',
        'wp-element',
        'wp-html-entities',
        'wp-i18n',
        'wp-data',
        'wc-blocks-data-store',
    ),
    'version' => '1.0.0',
); 