=== Coinley Payment Gateway ===
Contributors: joshuasol
Tags: woocommerce, payment gateway, cryptocurrency, ethereum, stablecoins, crypto payments
Requires at least: 5.4
Tested up to: 6.8
Requires PHP: 7.2
Stable tag: 1.1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Accept cryptocurrency payments on your WooCommerce store with lower fees, instant settlements, and no chargebacks.

== Description ==

Coinley is an entirely new payment processor, built with blockchain technology, designed to simplify global crypto transactions for your WooCommerce store.

= Benefits for Merchants =

* **Instant Settlements**: No more waiting days for funds to clear.
* **No Chargebacks**: Eliminate fraud risk with irreversible transactions.
* **Global Accessibility**: Accept payments from anywhere in the world.
* **Simplified Integration**: Easy setup with your WooCommerce store.

= Key Features =

* **Seamless Checkout Experience**: Customers can pay with various cryptocurrencies.
* **Real-time Exchange Rates**: Always get the current market value.
* **Automatic Currency Conversion**: Settle in your preferred currency.
* **Detailed Transaction Reports**: Track all your payments in one place.
* **Responsive Design**: Works on all devices and screen sizes.
* **Developer Friendly**: Well-documented API for custom integrations.

== Installation ==

= Automatic Installation =

1. Go to your WordPress Dashboard > Plugins > Add New.
2. Search for "Coinley Payment Gateway".
3. Click "Install Now" and then "Activate".
4. Go to WooCommerce > Settings > Payments.
5. Find "Cryptocurrency Payment (Coinley)" and click "Manage".
6. Enter your API credentials and configure the settings.
7. Click "Save changes".

= Manual Installation =

1. Download the plugin ZIP file.
2. Go to your WordPress Dashboard > Plugins > Add New > Upload Plugin.
3. Upload the ZIP file and click "Install Now".
4. Activate the plugin.
5. Go to WooCommerce > Settings > Payments.
6. Find "Cryptocurrency Payment (Coinley)" and click "Manage".
7. Enter your API credentials and configure the settings.
8. Click "Save changes".

== Frequently Asked Questions ==

= Do I need a Coinley account to use this plugin? =

Yes, you need to create a merchant account at [merchant.coinley.io](https://merchant.coinley.io) to get your API credentials.

= Which cryptocurrencies are supported? =

Coinley supports stablecoins like USDT and USDC, as well as Ethereum and other major cryptocurrencies. The full list is available in your Coinley dashboard.

= Can I receive payments in my local currency? =

Yes, Coinley can automatically convert cryptocurrency payments to your preferred fiat currency.

= Is there a transaction fee? =

Coinley charges a small fee per transaction, which is significantly lower than traditional payment processors. Contact us at support@coinley.io for current rates.

= Is this plugin secure? =

Yes, the plugin uses industry-standard security practices and all transactions are processed on the blockchain, ensuring high levels of security.

= Can I test the plugin before going live? =

Yes, the plugin includes a test mode that allows you to simulate transactions without real cryptocurrency.

== Screenshots ==

1. Checkout page with Coinley payment option
2. Payment gateway settings page
3. Order confirmation with payment details
4. Customer payment interface
5. Transaction history in WooCommerce

== Changelog ==

= 1.1.3 =
* Improved: Enhanced error handling for transaction details API endpoint
* Fixed: Better error messages when API returns 500 errors
* Fixed: More descriptive error feedback when payment details cannot be fetched
* Updated: API field name corrections for merchant statistics endpoint

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.1.3 =
Improved error handling and API integration fixes for transaction details display.

= 1.0.0 =
Initial release

== Support ==

For support, please email us at support@coinley.io. 