<?php
/**
 * Plugin Name: Coinley Payment Gateway
 * Plugin URI: https://coinley.io
 * Description: An entirely new payment infrastructure, built with blockchain technology, to simplify global crypto transactions.
 * Version: 1.1.5
 * Author: Coinley
 * License: GPL-2.0+
 * Text Domain: coinley-payment-gateway
 */

// Declare compatibility with WooCommerce features
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define plugin constants
define( 'COINLEYWP_VERSION', '1.1.5' );
define( 'COINLEYWP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'COINLEYWP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'COINLEYWP_PLUGIN_FILE', __FILE__ );

// Make sure WooCommerce is active
function coinleywp_check_woocommerce() {
    if (class_exists('WooCommerce')) {
        return true;
    }
    
    if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        return true;
    }
    
    if (is_multisite()) {
        $plugins = get_site_option('active_sitewide_plugins');
        if (isset($plugins['woocommerce/woocommerce.php'])) {
            return true;
        }
    }
    
    return false;
}

/**
 * Add plugin action links.
 */
function coinleywp_plugin_action_links( $links ) {
    $plugin_links = array(
        '<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=coinleywp' ) . '">' . __( 'Settings', 'coinleywp' ) . '</a>',
    );
    return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'coinleywp_plugin_action_links' );



// Initialize the plugin
CoinleyWP::instance();

class CoinleyWP {
    
    /**
     * Plugin version.
     *
     * @var string
     */
    public $version = '1.1.3';

    /**
     * The single instance of the class.
     *
     * @var CoinleyWP
     */
    protected static $_instance = null;

    /**
     * Main CoinleyWP Instance.
     *
     * Ensures only one instance of CoinleyWP is loaded or can be loaded.
     *
     * @return CoinleyWP - Main instance
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * CoinleyWP Constructor.
     */
    public function __construct() {
        $this->define_constants();
        $this->includes();
        $this->init_hooks();
    }

    /**
     * Hook into actions and filters.
     */
    private function init_hooks() {
        add_action( 'init', array( $this, 'init' ), 0 );
        add_action( 'plugins_loaded', array( $this, 'init_gateway_class' ) );
        add_filter( 'woocommerce_payment_gateways', array( $this, 'add_gateway_class' ) );
        
        // Plugin activation/deactivation hooks
        register_activation_hook( __FILE__, array( $this, 'plugin_activation' ) );
        register_deactivation_hook( __FILE__, array( $this, 'plugin_deactivation' ) );
        
        // Admin hooks for onboarding
        add_action( 'admin_init', array( $this, 'handle_onboarding_redirect' ) );
        add_action( 'admin_notices', array( $this, 'show_onboarding_notice' ) );
        add_action( 'wp_ajax_coinleywp_dismiss_notice', array( $this, 'dismiss_onboarding_notice' ) );
        add_action( 'wp_ajax_coinleywp_complete_onboarding', array( $this, 'complete_onboarding' ) );
    }

    /**
     * Define CoinleyWP Constants.
     */
    private function define_constants() {
        $this->define( 'COINLEYWP_ABSPATH', dirname( COINLEYWP_PLUGIN_FILE ) . '/' );
        $this->define( 'COINLEYWP_PLUGIN_BASENAME', plugin_basename( COINLEYWP_PLUGIN_FILE ) );
        $this->define( 'COINLEYWP_VERSION', $this->version );
    }

    /**
     * Define constant if not already set.
     *
     * @param string $name  Constant name.
     * @param string $value Constant value.
     */
    private function define( $name, $value ) {
        if ( ! defined( $name ) ) {
            define( $name, $value );
        }
    }

    /**
     * Include required core files used in admin and on the frontend.
     */
    public function includes() {
        // Always include API class
        include_once dirname( __FILE__ ) . '/includes/class-coinleywp-api.php';
        
        // Include admin class if in admin
        if ( is_admin() ) {
            include_once dirname( __FILE__ ) . '/includes/class-coinleywp-admin.php';
        }
        
        // Include other classes that don't depend on WooCommerce
        if ( file_exists( dirname( __FILE__ ) . '/includes/class-coinleywp-template-loader.php' ) ) {
            include_once dirname( __FILE__ ) . '/includes/class-coinleywp-template-loader.php';
        }
    }

    /**
     * Init CoinleyWP when WordPress Initialises.
     */
    public function init() {
        // Before init action.
        do_action( 'before_coinleywp_init' );

        // Set up localisation.
        $this->load_plugin_textdomain();

        // Init action.
        do_action( 'coinleywp_init' );
    }

    /**
     * Load Localisation files.
     * Note: WordPress automatically loads translations for plugins hosted on WordPress.org since WP 4.6
     */
    public function load_plugin_textdomain() {
        // No longer needed - WordPress handles translations automatically for wordpress.org hosted plugins
        // Keeping this method for backwards compatibility but it does nothing
    }

    /**
     * Add the gateway to WC Available Gateways.
     * 
     * @param array $gateways All available WC gateways.
     * @return array
     */
    public function add_gateway_class( $gateways ) {
        $gateways[] = 'CoinleyWP_Gateway';
        return $gateways;
    }

    /**
     * Init the gateway class.
     */
    public function init_gateway_class() {
        if ( class_exists( 'WooCommerce' ) ) {
            // Include gateway class now that WooCommerce is loaded
            include_once dirname( __FILE__ ) . '/includes/class-coinleywp-gateway.php';
            
            // Include blocks support if available
            if ( class_exists( 'Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
                include_once dirname( __FILE__ ) . '/includes/class-coinleywp-blocks-support.php';
                add_action(
                    'woocommerce_blocks_payment_method_type_registration',
                    function( Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $payment_method_registry ) {
                        $payment_method_registry->register( new CoinleyWP_Blocks_Support() );
                    }
                );
            }
            
            // Initialize admin if needed
            if ( is_admin() ) {
                new CoinleyWP_Admin();
            }
            
            // Add checkout scripts
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_checkout_scripts' ) );
            
            // Add AJAX handlers
            add_action( 'wp_ajax_coinleywp_process_payment', array( $this, 'ajax_process_payment' ) );
            add_action( 'wp_ajax_nopriv_coinleywp_process_payment', array( $this, 'ajax_process_payment' ) );
            add_action( 'wp_ajax_coinleywp_connect_wallet', array( $this, 'ajax_connect_wallet' ) );
            add_action( 'wp_ajax_nopriv_coinleywp_connect_wallet', array( $this, 'ajax_connect_wallet' ) );
            add_action( 'wp_ajax_coinleywp_cancel_payment', array( $this, 'ajax_cancel_payment' ) );
            add_action( 'wp_ajax_nopriv_coinleywp_cancel_payment', array( $this, 'ajax_cancel_payment' ) );
            add_action( 'wp_ajax_coinleywp_create_blocks_order', array( $this, 'ajax_create_blocks_order' ) );
            add_action( 'wp_ajax_nopriv_coinleywp_create_blocks_order', array( $this, 'ajax_create_blocks_order' ) );
            
        } else {
            add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
        }
    }

    /**
     * WooCommerce fallback notice.
     */
    public function woocommerce_missing_notice() {
        /* translators: 1. URL link. */
        echo '<div class="error"><p><strong>' . sprintf( esc_html__( 'CoinleyWP requires WooCommerce to be installed and active. You can download %s here.', 'coinleywp' ), '<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>' ) . '</strong></p></div>';
    }

    /**
     * Plugin activation hook.
     */
    public function plugin_activation() {
        // Set flag for onboarding
        update_option( 'coinleywp_needs_onboarding', true );
        update_option( 'coinleywp_activation_redirect', true );
        
        // Create default settings
        $default_settings = array(
            'enabled' => 'yes',
            'title' => 'Pay with Cryptocurrency',
            'description' => 'Pay securely using cryptocurrency through Coinley.',
            'testmode' => 'yes',
            'debug' => 'no',
            'payment_timeout' => '300',
            'webhook_secret' => wp_generate_password(32, false),
            'callback_url' => home_url('/wc-api/coinleywp')
        );
        
        update_option( 'woocommerce_coinleywp_settings', $default_settings );
    }

    /**
     * Plugin deactivation hook.
     */
    public function plugin_deactivation() {
        // Clean up onboarding flags
        delete_option( 'coinleywp_needs_onboarding' );
        delete_option( 'coinleywp_activation_redirect' );
        delete_option( 'coinleywp_onboarding_dismissed' );
    }

    /**
     * Handle onboarding redirect after activation.
     */
    public function handle_onboarding_redirect() {
        if ( get_option( 'coinleywp_activation_redirect' ) ) {
            delete_option( 'coinleywp_activation_redirect' );
            
            if ( ! get_option( 'coinleywp_onboarding_dismissed' ) ) {
                wp_redirect( admin_url( 'admin.php?page=coinley-onboarding' ) );
                exit;
            }
        }
    }

    /**
     * Show onboarding notice.
     */
    public function show_onboarding_notice() {
        if ( get_option( 'coinleywp_needs_onboarding' ) && ! get_option( 'coinleywp_onboarding_dismissed' ) ) {
            $settings_url = admin_url( 'admin.php?page=wc-settings&tab=checkout&section=coinleywp' );
            $onboarding_url = admin_url( 'admin.php?page=coinley-onboarding' );
            
            echo '<div class="notice notice-info coinleywp-onboarding-notice" style="position: relative; padding: 20px; border-left: 4px solid #0073aa;">';
            echo '<h3 style="margin-top: 0;">🚀 ' . __( 'Welcome to Coinley!', 'coinleywp' ) . '</h3>';
            echo '<p>' . __( 'Thank you for installing Coinley! To start accepting cryptocurrency payments, you need to connect your Coinley merchant account.', 'coinleywp' ) . '</p>';
            echo '<p>';
            echo '<a href="' . esc_url( $onboarding_url ) . '" class="button button-primary" style="margin-right: 10px;">' . __( 'Connect Coinley Account', 'coinleywp' ) . '</a>';
            echo '<a href="' . esc_url( $settings_url ) . '" class="button">' . __( 'Manual Setup', 'coinleywp' ) . '</a>';
            echo '<button type="button" class="notice-dismiss" onclick="coinleywpDismissNotice()"><span class="screen-reader-text">' . __( 'Dismiss this notice.', 'coinleywp' ) . '</span></button>';
            echo '</p>';
            echo '</div>';
            
            // Add JavaScript for notice dismissal
            echo '<script>
            function coinleywpDismissNotice() {
                jQuery.post(ajaxurl, {
                    action: "coinleywp_dismiss_notice",
                    nonce: "' . wp_create_nonce( 'coinleywp_dismiss_notice' ) . '"
                });
                jQuery(".coinleywp-onboarding-notice").fadeOut();
            }
            </script>';
        }
    }

    /**
     * Dismiss onboarding notice.
     */
    public function dismiss_onboarding_notice() {
        if ( wp_verify_nonce( $_POST['nonce'], 'coinleywp_dismiss_notice' ) ) {
            update_option( 'coinleywp_onboarding_dismissed', true );
            wp_send_json_success();
        } else {
            wp_send_json_error( 'Invalid nonce' );
        }
    }

    /**
     * Complete onboarding process.
     */
    public function complete_onboarding() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'coinleywp_onboarding' ) ) {
            wp_send_json_error( 'Invalid nonce' );
        }

        $email = sanitize_email( $_POST['email'] );
        $password = $_POST['password'];
        $action_type = sanitize_text_field( $_POST['action_type'] ); // 'login' or 'register'

        if ( empty( $email ) || empty( $password ) ) {
            wp_send_json_error( 'Email and password are required' );
        }

        try {
            if ( $action_type === 'register' ) {
                $response = $this->register_merchant( $email, $password );
                
                // Handle registration response
                if ( $response && isset( $response['merchant'] ) ) {
                    // Registration successful - save credentials and show verification message
                    $this->save_merchant_credentials( $email, $response['merchant'] );
                    
                    $message = isset( $response['message'] ) ? $response['message'] : 'Registration successful! Please check your email to verify your account.';
                    
                    wp_send_json_success( array(
                        'message' => $message,
                        'requires_verification' => true,
                        'redirect' => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=coinleywp' )
                    ) );
                } else {
                    wp_send_json_error( 'Registration failed - invalid response' );
                }
                
            } else {
                $response = $this->login_merchant( $email, $password );
                
                // Handle login response
                if ( isset( $response['verified'] ) && $response['verified'] === false ) {
                    // Account exists but email not verified
                    $message = isset( $response['msg'] ) ? $response['msg'] : 'Email not verified. Please check your email for the verification link.';
                    wp_send_json_error( $message );
                    
                } elseif ( $response && isset( $response['merchant'] ) ) {
                    // Login successful and verified
                    $this->save_merchant_credentials( $email, $response['merchant'] );
                    
                    wp_send_json_success( array(
                        'message' => __( 'Successfully connected to Coinley!', 'coinleywp' ),
                        'redirect' => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=coinleywp' )
                    ) );
                } else {
                    wp_send_json_error( 'Login failed - invalid response' );
                }
            }
        } catch ( Exception $e ) {
            wp_send_json_error( $e->getMessage() );
        }
    }

    /**
     * Save merchant credentials to WooCommerce settings.
     */
    private function save_merchant_credentials( $email, $merchant_data ) {
        $current_settings = get_option( 'woocommerce_coinleywp_settings', array() );
        
        $updated_settings = array_merge( $current_settings, array(
            'merchant_email' => $email,
            'api_key' => $merchant_data['apiKey'],
            'api_secret' => $merchant_data['apiSecret'],
            'enabled' => 'yes'
        ) );
        
        // Save webhook secret if provided
        if ( isset( $merchant_data['webhookSecret'] ) ) {
            $updated_settings['webhook_secret'] = $merchant_data['webhookSecret'];
        }
        
        update_option( 'woocommerce_coinleywp_settings', $updated_settings );
        
        // Mark onboarding as complete
        delete_option( 'coinleywp_needs_onboarding' );
        update_option( 'coinleywp_onboarding_dismissed', true );
    }

    /**
     * Register new merchant with Coinley.
     */
    private function register_merchant( $email, $password ) {
        $response = wp_remote_post( 'https://talented-mercy-production.up.railway.app/api/merchants/register', array(
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode( array(
                'email' => $email,
                'password' => $password,
                'businessName' => get_bloginfo( 'name' ),
                'website' => get_site_url(),
                'platform' => 'woocommerce'
            ) ),
            'timeout' => 30
        ) );

        if ( is_wp_error( $response ) ) {
            throw new Exception( $response->get_error_message() );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $code = wp_remote_retrieve_response_code( $response );

        if ( $code !== 200 && $code !== 201 ) {
            throw new Exception( $body['message'] ?? 'Registration failed' );
        }

        return $body;
    }

    /**
     * Login merchant with Coinley.
     */
    private function login_merchant( $email, $password ) {
        $response = wp_remote_post( 'https://talented-mercy-production.up.railway.app/api/merchants/login', array(
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode( array(
                'email' => $email,
                'password' => $password,
            ) ),
            'timeout' => 30
        ) );

        if ( is_wp_error( $response ) ) {
            throw new Exception( $response->get_error_message() );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $code = wp_remote_retrieve_response_code( $response );

        // Handle different response scenarios
        if ( $code === 200 ) {
            // Check if response indicates unverified email
            if ( isset( $body['verified'] ) && $body['verified'] === false ) {
                // Return the response as-is for handling in complete_onboarding
                return $body;
            }
            // Normal successful login
            return $body;
        } else {
            // Error response
            $error_message = $body['message'] ?? $body['msg'] ?? 'Login failed';
            throw new Exception( $error_message );
        }
    }

    /**
     * Enqueue checkout scripts and styles.
     */
    public function enqueue_checkout_scripts() {
        // CoinleyVanilla SDK scripts are now loaded by the gateway class
        // This method is kept for backwards compatibility but no longer enqueues old scripts

        // The gateway class (class-coinleywp-gateway.php) handles:
        // - CoinleyVanilla SDK from CDN
        // - payment-modal.js
        // - All required styles
    }

    /**
     * AJAX handler for payment processing.
     */
    public function ajax_process_payment() {
        if ( class_exists( 'CoinleyWP_Gateway' ) ) {
            $gateway = new CoinleyWP_Gateway();
            $gateway->handle_payment_processing();
        } else {
            wp_send_json_error( 'Gateway class not available' );
        }
    }

    /**
     * AJAX handler for wallet connection.
     */
    public function ajax_connect_wallet() {
        if ( class_exists( 'CoinleyWP_Gateway' ) ) {
            $gateway = new CoinleyWP_Gateway();
            $gateway->handle_wallet_connection();
        } else {
            wp_send_json_error( 'Gateway class not available' );
        }
    }

    /**
     * AJAX handler for payment cancellation.
     */
    public function ajax_cancel_payment() {
        if ( class_exists( 'CoinleyWP_Gateway' ) ) {
            $gateway = new CoinleyWP_Gateway();
            $gateway->handle_payment_cancellation();
        } else {
            wp_send_json_error( 'Gateway class not available' );
        }
    }

    /**
     * AJAX handler for blocks order creation.
     */
    public function ajax_create_blocks_order() {
        if ( class_exists( 'CoinleyWP_Gateway' ) ) {
            $gateway = new CoinleyWP_Gateway();
            $gateway->handle_blocks_order_creation();
        } else {
            wp_send_json_error( 'Gateway class not available' );
        }
    }
}

/**
 * Send order emails asynchronously after payment processing.
 * This runs 5 seconds after checkout to avoid blocking the checkout response.
 */
function coinleywp_send_order_emails_handler( $order_id ) {
    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        return;
    }

    // Trigger customer processing order email
    WC()->mailer()->emails['WC_Email_Customer_Processing_Order']->trigger( $order_id );

    // Trigger new order admin email
    WC()->mailer()->emails['WC_Email_New_Order']->trigger( $order_id );
}
add_action( 'coinleywp_send_order_emails', 'coinleywp_send_order_emails_handler' );
